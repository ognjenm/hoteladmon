﻿

ALTER TABLE `rsrtcpns_coco`.`contract_information` 
CHANGE COLUMN `lessee` `lessee` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Leessee' ,
CHANGE COLUMN `owner` `owner` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Owner' ,
CHANGE COLUMN `property_location` `property_location` TINYTEXT CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Property Location' ,
CHANGE COLUMN `address_payment` `address_payment` TINYTEXT CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Address of payment' ,
CHANGE COLUMN `paydays` `paydays` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Paydays' ,
CHANGE COLUMN `forced_months` `forced_months` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Forced Months' ,
CHANGE COLUMN `end_lease` `end_lease` DATE NULL DEFAULT NULL COMMENT 'End Of The Lease' ,
CHANGE COLUMN `name_surety` `name_surety` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Name Of The Surety' ,
CHANGE COLUMN `address_surety` `address_surety` TINYTEXT CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Address Of The Surety' ,
CHANGE COLUMN `property_address_surety` `property_address_surety` TINYTEXT CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Property Address Of The Surety' ,
CHANGE COLUMN `address_public_register` `address_public_register` TINYTEXT CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Address public register where the property is registered' ,
CHANGE COLUMN `title` `title` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Title' ,
CHANGE COLUMN `content` `content` TEXT CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Content' ,
ADD COLUMN `iscompany_lessee` TINYINT(4) NULL DEFAULT NULL COMMENT 'The lesse is a company' AFTER `service_id`,
ADD COLUMN `company_lessee` VARCHAR(150) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Company Name' AFTER `iscompany_lessee`,
ADD COLUMN `rfc_lessee` VARCHAR(25) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'RFC' AFTER `company_lessee`,
ADD COLUMN `iscompany_owner` TINYINT(4) NULL DEFAULT NULL COMMENT 'The owner is company' AFTER `rfc_lessee`,
ADD COLUMN `company_owner` VARCHAR(150) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Company Name' AFTER `iscompany_owner`






ALTER TABLE `rsrtcpns_coco`.`articles` 
CHANGE COLUMN `name_article` `name_article` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Name Article' ,
CHANGE COLUMN `name_store` `name_store` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Name Store' ,
CHANGE COLUMN `name_invoice` `name_invoice` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Name Invoice' ,
CHANGE COLUMN `code` `code` VARCHAR(20) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Code' ,
CHANGE COLUMN `code_store` `code_store` VARCHAR(20) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Code Store' ,
CHANGE COLUMN `code_invoice` `code_invoice` VARCHAR(20) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Code Invoice' ,
CHANGE COLUMN `presentation` `presentation` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Presentation' ,
CHANGE COLUMN `image` `image` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Image' ,
CHANGE COLUMN `barcode` `barcode` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Barcode' 



http://losimpuestos.com.mx/ieps-impuesto/
http://losimpuestos.com.mx/ieps-2014/


ALTER TABLE `rsrtcpns_coco`.`direct_invoice` 
CHANGE COLUMN `n_invoice` `n_invoice` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Invoice' ,
CHANGE COLUMN `discount` `discount` DECIMAL(10,2) NULL DEFAULT NULL COMMENT 'Discount' ,
ADD COLUMN `discount_article` DECIMAL(10,2) NULL DEFAULT NULL COMMENT 'Discount Article' AFTER `discount`,
ADD COLUMN `vat_article` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'VAT Article' AFTER `vat`,
ADD COLUMN `retiva_article` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'Retention VAT Article' AFTER `retiva`,
ADD COLUMN `ieps_article` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'IEPS Article' AFTER `ieps`,
ADD COLUMN `retisr` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'Retention ISR' AFTER `ieps_article`,
ADD COLUMN `retisr_article` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'Retention ISR Article' AFTER `retisr`,
ADD COLUMN `other` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'Other' AFTER `retisr_article`,
ADD COLUMN `other_article` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'Other Article' AFTER `other`


ALTER TABLE `rsrtcpns_coco`.`direct_invoice` 
DROP COLUMN `other_article`,
DROP COLUMN `retisr_article`,
DROP COLUMN `ieps_article`,
DROP COLUMN `retiva_article`,
DROP COLUMN `vat_article`,
DROP COLUMN `discount_article`,
CHANGE COLUMN `n_invoice` `n_invoice` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' NULL DEFAULT NULL COMMENT 'Invoice' 

 

ALTER TABLE `rsrtcpns_coco`.`direct_invoice_items` 
CHANGE COLUMN `vat` `vat` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'VAT' ,
ADD COLUMN `ieps` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'IEPS' AFTER `vat`,
ADD COLUMN `retiva` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'Retention IVA' AFTER `ieps`,
ADD COLUMN `retisr` DECIMAL(10,2) NULL DEFAULT 0.00 COMMENT 'Retention ISR' AFTER `retiva`










 








 




 




 




	     





 










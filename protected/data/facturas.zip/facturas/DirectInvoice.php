<?php

/**
 * This is the model class for table "direct_invoice".
 *
 * The followings are the available columns in table 'direct_invoice':
 * @property integer $id
 * @property integer $petty_cash_id
 * @property string $n_invoice
 * @property string $datex
 * @property integer $isactive
 * @property integer $isinvoice
 * @property integer $provider_id
 * @property integer $user_id
 * @property string $amount
 * @property string $discount
 * @property string $discount_article
 * @property string $subtotal
 * @property string $vat
 * @property string $vat_article
 * @property string $retiva
 * @property string $retiva_article
 * @property string $ieps
 * @property string $ieps_article
 * @property string $retisr
 * @property string $retisr_article
 * @property string $other
 * @property string $other_article
 * @property string $total
 *
 * The followings are the available model relations:
 * @property DirectInvoiceItems[] $directInvoiceItems
 */
class DirectInvoice extends CActiveRecord
{

    public $article_id;
    public $discount_article;
    public $vat_article;
    public $retiva_article;
    public $ieps_article;
    public $retisr_article;
    public $other_article;

    public $discount_sum;
    public $ieps_sum;
    public $retiva_sum;
    public $retisr_sum;
    public $vat_sum;
    public $other_sum;
    public $grandTotal;
    public $totalAmount;

	public function tableName()
	{
		return 'direct_invoice';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('datex, provider_id', 'required'),
			array('petty_cash_id, isactive, isinvoice, provider_id, user_id', 'numerical', 'integerOnly'=>true),
			array('n_invoice', 'length', 'max'=>50),
			array('amount, discount, discount_article, subtotal, vat, vat_article, retiva, retiva_article, ieps, ieps_article, retisr, retisr_article, other, other_article, total', 'length', 'max'=>10),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, petty_cash_id, n_invoice, datex, isactive, isinvoice, provider_id, user_id, amount, discount, discount_article, subtotal, vat, vat_article, retiva, retiva_article, ieps, ieps_article, retisr, retisr_article, other, other_article, total', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
            'directInvoiceItems' => array(self::HAS_MANY, 'DirectInvoiceItems', 'direct_invoice_id'),
            'provider' => array(self::BELONGS_TO, 'Providers', 'provider_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
            'petty_cash_id' => Yii::t('mx','N° Summary:'),
            'n_invoice' => Yii::t('mx','Invoice'),
            'amount' => Yii::t('mx','Amount'),
            'datex' => Yii::t('mx','Date'),
            'isactive' => Yii::t('mx','Isactive'),
            'isinvoice' => Yii::t('mx','Isinvoice'),
            'provider_id' => Yii::t('mx','Provider'),
            'user_id' => Yii::t('mx','User'),
            'vat' => Yii::t('mx','IVA'),
            'vat_article' => Yii::t('mx','VAT Article'),
            'discount' => Yii::t('mx','Discount'),
            'discount_article' => Yii::t('mx','Discount Article'),
            'subtotal' => Yii::t('mx','Subtotal'),
            'retiva' => Yii::t('mx','Retention of VAT'),
            'retiva_article' => Yii::t('mx','Retention VAT Article'),
            'ieps' => Yii::t('mx','IEPS'),
			'ieps_article' => Yii::t('mx','IEPS Article'),
			'retisr' => Yii::t('mx','Retention ISR'),
			'retisr_article' => Yii::t('mx','Retention ISR Article'),
			'other' => Yii::t('mx','Other'),
			'other_article' => Yii::t('mx','Other Article'),
            'total' => Yii::t('mx','Total'),
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('petty_cash_id',$this->petty_cash_id);
		$criteria->compare('n_invoice',$this->n_invoice,true);
		$criteria->compare('datex',$this->datex,true);
		$criteria->compare('isactive',$this->isactive);
		$criteria->compare('isinvoice',$this->isinvoice);
		$criteria->compare('provider_id',$this->provider_id);
		$criteria->compare('user_id',$this->user_id);
		$criteria->compare('amount',$this->amount,true);
		$criteria->compare('discount',$this->discount,true);
		$criteria->compare('discount_article',$this->discount_article,true);
		$criteria->compare('subtotal',$this->subtotal,true);
		$criteria->compare('vat',$this->vat,true);
		$criteria->compare('vat_article',$this->vat_article,true);
		$criteria->compare('retiva',$this->retiva,true);
		$criteria->compare('retiva_article',$this->retiva_article,true);
		$criteria->compare('ieps',$this->ieps,true);
		$criteria->compare('ieps_article',$this->ieps_article,true);
		$criteria->compare('retisr',$this->retisr,true);
		$criteria->compare('retisr_article',$this->retisr_article,true);
		$criteria->compare('other',$this->other,true);
		$criteria->compare('other_article',$this->other_article,true);
		$criteria->compare('total',$this->total,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

    public function beforeSave(){

        $datex=Yii::app()->quoteUtil->ToEnglishDateFromFormatdMyyyy($this->datex);
        $this->datex=date("Y-m-d",strtotime($datex));

        return parent::beforeSave();
    }

    public function afterFind() {

        $this->datex=date("d-M-Y",strtotime($this->datex));

        return  parent::afterFind();
    }

    public function behaviors()
    {
        return array(
            'LoggableBehavior'=>
                'application.modules.auditTrail.behaviors.LoggableBehavior',
        );
    }


	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}

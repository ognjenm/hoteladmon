<?php

class DirectInvoiceController extends Controller
{

	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
            array('CrugeAccessControlFilter'), // perform access control for CRUD operations
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','index','view','delete','getArticle','sumaInvoices'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	public function actionSumaInvoices(){

        $res=array('ok'=>false,'suma'=>0);
        $ids=array();
        $suma=0;
        $display='';

        if(Yii::app()->request->isPostRequest){

            $values=$_POST['ids'];
            $ids=explode(',',$values);

            foreach($ids as $id){
                $invoice=DirectInvoice::model()->findByPk($id);
                $suma=$suma+$invoice->total;
            }

            $display='<h2><strong>$'.number_format($suma,2).'</h2></strong>';

            $res=array('ok'=>true,'suma'=>$display);

            echo CJSON::encode($res);
            Yii::app()->end();
        }

    }

    public function actionGetArticle() {

        $res =array();
        if (isset($_GET['term'])) {
            $qtxt ="SELECT name_article FROM articles WHERE name_article LIKE :word1";
            $command =Yii::app()->db->createCommand($qtxt);
            $command->bindValue(":word1", "%".$_GET['term']."%", PDO::PARAM_STR);
            $res =$command->queryColumn();
        }

        echo CJSON::encode($res);
        Yii::app()->end();

    }


    public function actionView($id)
	{
        $invoice=$this->loadModel($id);
        $expide=Providers::model()->findByPk($invoice->provider_id);
        $indice=1;
        $billTo=Settings::model()->findByPk($indice);
        $itemsIvoice=DirectInvoiceItems::model()->findAll(array(
            'condition'=>'direct_invoice_id=:directInvoiceId',
            'params'=>array('directInvoiceId'=>$invoice->id)
        ));

		$this->render('view',array(
			'invoice'=>$invoice,
            'expide'=>$expide,
            'billTo'=>$billTo,
            'itemsIvoice'=>$itemsIvoice
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
        Yii::import('ext.jqrelcopy.JQRelcopy');
		$model=new DirectInvoice;
        $items=new DirectInvoiceItems;
        $importe=0;

		if(isset($_POST['DirectInvoice']))
		{
			$model->attributes=$_POST['DirectInvoice'];
            $model->user_id=Yii::app()->user->id;
            $model->isactive=1;

			if($model->save()){

                $tope=count($_POST['DirectInvoiceItems']['quantity']);

                for($i=0;$i<$tope;$i++){
                    $data=array();

                    foreach($_POST['DirectInvoiceItems'] as $id=>$values){
                        $anexo=array($id=>$values[$i]);
                        $data=array_merge($data,$anexo);
                    }

                    $item=new DirectInvoiceItems;
                    $item->attributes=$data;
                    $item->direct_invoice_id=$model->id;
                    $item->save();

                    $importe+=$item->total;

                }

                $model->amount=$importe;
                $model->subtotal=$importe-$model->discount;
                $model->total=$model->subtotal+$model->vat-$model->retiva+$model->ieps;
                $model->save();

                Yii::app()->user->setFlash('success','Success');
                $this->redirect(array('view','id'=>$model->id));
            }

		}

		$this->render('create',array(
			'model'=>$model,
            'items'=>$items,
		));
	}

    public function getItemsToUpdate($id) {

        $list=DirectInvoiceItems::model()->with(array(
            'article'=>array(
                'select'=>'presentation',
                'together'=>false,
                'joinType'=>'INNER JOIN',

            ),
        ))->findAll(
            array(
                'condition'=>'direct_invoice_id=:directInvoiceId',
                'params'=>array('directInvoiceId'=>$id)
            )
        );


        $items=array();

        if (isset($list)) {

            foreach ($list as $item) {
                $items[] = $item;
            }
        }
        return $items;
    }


	public function actionUpdate($id)
	{
        Yii::import('ext.jqrelcopy.JQRelcopy');

		$model=$this->loadModel($id);
        $items= $this->getItemsToUpdate($model->id);

		if(isset($_POST['DirectInvoice']) && isset($_POST['DirectInvoiceItems']))
		{
			$model->attributes=$_POST['DirectInvoice'];

			if($model->save()){

                foreach($_POST['DirectInvoiceItems'] as $item){
                    $itemInvoice=DirectInvoiceItems::model()->findByPk($item['id']);
                    $itemInvoice->attributes=$item;
                    $itemInvoice->save();
                }

                Yii::app()->user->setFlash('success','Success');
                $this->redirect(array('view','id'=>$model->id));
            }

		}

		$this->render('update',array(
			'model'=>$model,
            'items'=>$items
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		if(Yii::app()->request->isPostRequest)
		{
			// we only allow deletion via POST request
			$this->loadModel($id)->delete();

			// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
			if(!isset($_GET['ajax']))
				$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
		}
		else
			throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
        $model=new DirectInvoice('search');
        $model->unsetAttributes();  // clear any default values
        if(isset($_GET['DirectInvoice']))
        $model->attributes=$_GET['DirectInvoice'];

        $this->render('index',array(
        'model'=>$model,
        ));

	}

	/**
	 * Manages all models.
	 */

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer the ID of the model to be loaded
	 */
	public function loadModel($id)
	{
		$model=DirectInvoice::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='direct-invoice-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}

<?php
    $this->breadcrumbs=array(
        Yii::t('mx','Direct Invoice')=>array('index'),
        Yii::t('mx','Manage'),
    );

    $this->menu=array(
        array('label'=>Yii::t('mx', 'Refresh'),'icon'=>'icon-refresh','url'=>array('index')),
        array('label'=>Yii::t('mx','Create'),'icon'=>'icon-plus','url'=>array('create')),
    );

    $this->pageSubTitle=Yii::t('mx','Manage');
    $this->pageIcon='icon-cogs';

    if(Yii::app()->user->hasFlash('success')):
        Yii::app()->user->setFlash('success', '<strong>done!</strong> '.Yii::app()->user->getFlash('success'));
    endif;

    $this->widget('bootstrap.widgets.TbAlert', array(
        'block'=>true,
        'fade'=>true,
        'closeText'=>'×',
        'alerts'=>array(
            'success'=>array('block'=>true, 'fade'=>true, 'closeText'=>'×'),
        ),
    ));

    $url=$this->createUrl('sumaInvoices');


    Yii::app()->clientScript->registerScript('search', "

            $('.select-on-check').click(function(){

                var invoice=$.fn.yiiGridView.getChecked('direct-invoice-grid','chk').toString();

                if(invoice!=''){
                    $.ajax({
                        url:'$url',
                        data: { ids: invoice  },
                        type: 'POST',
                        dataType: 'json',
                        beforeSend: function() { $('#tasks-grid-inner').addClass('loading'); }
                    })

                    .done(function(data) {  $('#suma').html(data.suma); })
                    .fail(function() { bootbox.alert('Error');  })
                    .always(function() { $('#tasks-grid-inner').removeClass('loading'); });
                }

            });
        ");

?>

<div id="suma" class="pull-right"></div>

 <?php $this->renderPartial('_grid', array(
        'model' => $model,
    ));
 ?>







-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Servidor: 68.178.142.157
-- Tiempo de generación: 14-01-2014 a las 12:04:25
-- Versión del servidor: 5.0.96
-- Versión de PHP: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `chinoixeofadmon`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `budget_format`
--

CREATE TABLE `budget_format` (
  `id` int(11) NOT NULL auto_increment,
  `budget` varchar(150) character set utf8 default NULL,
  `policies` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `budget_format`
--

INSERT INTO `budget_format` VALUES(1, 'CABAÑAS', '2,3,4,5,6,7');
INSERT INTO `budget_format` VALUES(2, 'ACAMPADO', '5,6,7,8,9,10,11,14,15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cabana_discount`
--

CREATE TABLE `cabana_discount` (
  `id` int(11) NOT NULL auto_increment,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `cabana_discount`
--

INSERT INTO `cabana_discount` VALUES(1, 2500, 5999, 3);
INSERT INTO `cabana_discount` VALUES(2, 6000, 9999, 5);
INSERT INTO `cabana_discount` VALUES(3, 10000, 19999, 10);
INSERT INTO `cabana_discount` VALUES(4, 20000, 44999, 15);
INSERT INTO `cabana_discount` VALUES(5, 45000, 69999, 20);
INSERT INTO `cabana_discount` VALUES(6, 70000, 1000000, 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calendar_season`
--

CREATE TABLE `calendar_season` (
  `id` int(11) NOT NULL auto_increment,
  `dai` int(11) default NULL,
  `monthh` int(11) default NULL,
  `tipe` varchar(10) default 'BAJA',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=366 ;

--
-- Volcar la base de datos para la tabla `calendar_season`
--

INSERT INTO `calendar_season` VALUES(1, 1, 1, 'ALTA');
INSERT INTO `calendar_season` VALUES(2, 2, 1, 'ALTA');
INSERT INTO `calendar_season` VALUES(3, 3, 1, 'ALTA');
INSERT INTO `calendar_season` VALUES(4, 4, 1, 'ALTA');
INSERT INTO `calendar_season` VALUES(5, 5, 1, 'ALTA');
INSERT INTO `calendar_season` VALUES(6, 6, 1, 'ALTA');
INSERT INTO `calendar_season` VALUES(7, 7, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(8, 8, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(9, 9, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(10, 10, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(11, 11, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(12, 12, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(13, 13, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(14, 14, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(15, 15, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(16, 16, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(17, 17, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(18, 18, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(19, 19, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(20, 20, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(21, 21, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(22, 22, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(23, 23, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(24, 24, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(25, 25, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(26, 26, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(27, 27, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(28, 28, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(29, 29, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(30, 30, 1, 'BAJA');
INSERT INTO `calendar_season` VALUES(31, 31, 1, 'ALTA');
INSERT INTO `calendar_season` VALUES(32, 1, 2, 'ALTA');
INSERT INTO `calendar_season` VALUES(33, 2, 2, 'ALTA');
INSERT INTO `calendar_season` VALUES(34, 3, 2, 'ALTA');
INSERT INTO `calendar_season` VALUES(35, 4, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(36, 5, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(37, 6, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(38, 7, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(39, 8, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(40, 9, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(41, 10, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(42, 11, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(43, 12, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(44, 13, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(45, 14, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(46, 15, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(47, 16, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(48, 17, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(49, 18, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(50, 19, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(51, 20, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(52, 21, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(53, 22, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(54, 23, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(55, 24, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(56, 25, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(57, 26, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(58, 27, 2, 'BAJA');
INSERT INTO `calendar_season` VALUES(59, 28, 2, 'ALTA');
INSERT INTO `calendar_season` VALUES(60, 1, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(61, 2, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(62, 3, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(63, 4, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(64, 5, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(65, 6, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(66, 7, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(67, 8, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(68, 9, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(69, 10, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(70, 11, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(71, 12, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(72, 13, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(73, 14, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(74, 15, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(75, 16, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(76, 17, 3, 'ALTA');
INSERT INTO `calendar_season` VALUES(77, 18, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(78, 19, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(79, 20, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(80, 21, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(81, 22, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(82, 23, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(83, 24, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(84, 25, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(85, 26, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(86, 27, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(87, 28, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(88, 29, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(89, 30, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(90, 31, 3, 'BAJA');
INSERT INTO `calendar_season` VALUES(91, 1, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(92, 2, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(93, 3, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(94, 4, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(95, 5, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(96, 6, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(97, 7, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(98, 8, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(99, 9, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(100, 10, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(101, 11, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(102, 12, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(103, 13, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(104, 14, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(105, 15, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(106, 16, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(107, 17, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(108, 18, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(109, 19, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(110, 20, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(111, 21, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(112, 22, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(113, 23, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(114, 24, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(115, 25, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(116, 26, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(117, 27, 4, 'ALTA');
INSERT INTO `calendar_season` VALUES(118, 28, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(119, 29, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(120, 30, 4, 'BAJA');
INSERT INTO `calendar_season` VALUES(121, 1, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(122, 2, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(123, 3, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(124, 4, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(125, 5, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(126, 6, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(127, 7, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(128, 8, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(129, 9, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(130, 10, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(131, 11, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(132, 12, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(133, 13, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(134, 14, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(135, 15, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(136, 16, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(137, 17, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(138, 18, 5, 'ALTA');
INSERT INTO `calendar_season` VALUES(139, 19, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(140, 20, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(141, 21, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(142, 22, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(143, 23, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(144, 24, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(145, 25, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(146, 26, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(147, 27, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(148, 28, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(149, 29, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(150, 30, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(151, 31, 5, 'BAJA');
INSERT INTO `calendar_season` VALUES(152, 1, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(153, 2, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(154, 3, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(155, 4, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(156, 5, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(157, 6, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(158, 7, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(159, 8, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(160, 9, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(161, 10, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(162, 11, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(163, 12, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(164, 13, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(165, 14, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(166, 15, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(167, 16, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(168, 17, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(169, 18, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(170, 19, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(171, 20, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(172, 21, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(173, 22, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(174, 23, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(175, 24, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(176, 25, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(177, 26, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(178, 27, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(179, 28, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(180, 29, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(181, 30, 6, 'BAJA');
INSERT INTO `calendar_season` VALUES(182, 1, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(183, 2, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(184, 3, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(185, 4, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(186, 5, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(187, 6, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(188, 7, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(189, 8, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(190, 9, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(191, 10, 7, 'BAJA');
INSERT INTO `calendar_season` VALUES(192, 11, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(193, 12, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(194, 13, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(195, 14, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(196, 15, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(197, 16, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(198, 17, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(199, 18, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(200, 19, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(201, 20, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(202, 21, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(203, 22, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(204, 23, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(205, 24, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(206, 25, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(207, 26, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(208, 27, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(209, 28, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(210, 29, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(211, 30, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(212, 31, 7, 'ALTA');
INSERT INTO `calendar_season` VALUES(213, 1, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(214, 2, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(215, 3, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(216, 4, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(217, 5, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(218, 6, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(219, 7, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(220, 8, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(221, 9, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(222, 10, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(223, 11, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(224, 12, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(225, 13, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(226, 14, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(227, 15, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(228, 16, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(229, 17, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(230, 18, 8, 'ALTA');
INSERT INTO `calendar_season` VALUES(231, 19, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(232, 20, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(233, 21, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(234, 22, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(235, 23, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(236, 24, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(237, 25, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(238, 26, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(239, 27, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(240, 28, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(241, 29, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(242, 30, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(243, 31, 8, 'BAJA');
INSERT INTO `calendar_season` VALUES(244, 1, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(245, 2, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(246, 3, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(247, 4, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(248, 5, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(249, 6, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(250, 7, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(251, 8, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(252, 9, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(253, 10, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(254, 11, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(255, 12, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(256, 13, 9, 'ALTA');
INSERT INTO `calendar_season` VALUES(257, 14, 9, 'ALTA');
INSERT INTO `calendar_season` VALUES(258, 15, 9, 'ALTA');
INSERT INTO `calendar_season` VALUES(259, 16, 9, 'ALTA');
INSERT INTO `calendar_season` VALUES(260, 17, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(261, 18, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(262, 19, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(263, 20, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(264, 21, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(265, 22, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(266, 23, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(267, 24, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(268, 25, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(269, 26, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(270, 27, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(271, 28, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(272, 29, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(273, 30, 9, 'BAJA');
INSERT INTO `calendar_season` VALUES(274, 1, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(275, 2, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(276, 3, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(277, 4, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(278, 5, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(279, 6, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(280, 7, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(281, 8, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(282, 9, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(283, 10, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(284, 11, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(285, 12, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(286, 13, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(287, 14, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(288, 15, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(289, 16, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(290, 17, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(291, 18, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(292, 19, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(293, 20, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(294, 21, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(295, 22, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(296, 23, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(297, 24, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(298, 25, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(299, 26, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(300, 27, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(301, 28, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(302, 29, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(303, 30, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(304, 31, 10, 'BAJA');
INSERT INTO `calendar_season` VALUES(305, 1, 11, 'ALTA');
INSERT INTO `calendar_season` VALUES(306, 2, 11, 'ALTA');
INSERT INTO `calendar_season` VALUES(307, 3, 11, 'ALTA');
INSERT INTO `calendar_season` VALUES(308, 4, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(309, 5, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(310, 6, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(311, 7, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(312, 8, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(313, 9, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(314, 10, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(315, 11, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(316, 12, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(317, 13, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(318, 14, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(319, 15, 11, 'ALTA');
INSERT INTO `calendar_season` VALUES(320, 16, 11, 'ALTA');
INSERT INTO `calendar_season` VALUES(321, 17, 11, 'ALTA');
INSERT INTO `calendar_season` VALUES(322, 18, 11, 'ALTA');
INSERT INTO `calendar_season` VALUES(323, 19, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(324, 20, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(325, 21, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(326, 22, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(327, 23, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(328, 24, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(329, 25, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(330, 26, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(331, 27, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(332, 28, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(333, 29, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(334, 30, 11, 'BAJA');
INSERT INTO `calendar_season` VALUES(335, 1, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(336, 2, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(337, 3, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(338, 4, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(339, 5, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(340, 6, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(341, 7, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(342, 8, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(343, 9, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(344, 10, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(345, 11, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(346, 12, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(347, 13, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(348, 14, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(349, 15, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(350, 16, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(351, 17, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(352, 18, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(353, 19, 12, 'BAJA');
INSERT INTO `calendar_season` VALUES(354, 20, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(355, 21, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(356, 22, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(357, 23, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(358, 24, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(359, 25, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(360, 26, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(361, 27, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(362, 28, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(363, 29, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(364, 30, 12, 'ALTA');
INSERT INTO `calendar_season` VALUES(365, 31, 12, 'ALTA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `camped_and_daypass`
--

CREATE TABLE `camped_and_daypass` (
  `id` int(11) NOT NULL auto_increment,
  `type_reservation` enum('','CABANA','TENT','CAMPED','DAYPASS') character set utf8 default NULL,
  `season` enum('','ALTA','BAJA') character set utf8 default NULL,
  `adults` decimal(10,2) default NULL,
  `medium` decimal(10,2) default NULL,
  `children` decimal(10,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `camped_and_daypass`
--

INSERT INTO `camped_and_daypass` VALUES(1, 'CAMPED', 'ALTA', 150.00, NULL, 100.00);
INSERT INTO `camped_and_daypass` VALUES(2, 'CAMPED', 'BAJA', 150.00, NULL, 100.00);
INSERT INTO `camped_and_daypass` VALUES(3, 'DAYPASS', 'ALTA', 100.00, NULL, 50.00);
INSERT INTO `camped_and_daypass` VALUES(4, 'DAYPASS', 'BAJA', 100.00, NULL, 50.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `camped_discount`
--

CREATE TABLE `camped_discount` (
  `id` int(11) NOT NULL auto_increment,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `camped_discount`
--

INSERT INTO `camped_discount` VALUES(2, 1, 14, 0);
INSERT INTO `camped_discount` VALUES(3, 15, 34, 5);
INSERT INTO `camped_discount` VALUES(4, 35, 74, 10);
INSERT INTO `camped_discount` VALUES(5, 75, 199, 15);
INSERT INTO `camped_discount` VALUES(6, 200, 299, 20);
INSERT INTO `camped_discount` VALUES(7, 300, 399, 25);
INSERT INTO `camped_discount` VALUES(8, 400, 499, 30);
INSERT INTO `camped_discount` VALUES(9, 500, 599, 35);
INSERT INTO `camped_discount` VALUES(10, 600, 10000, 40);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_authassignment`
--

CREATE TABLE `cruge_authassignment` (
  `userid` int(11) NOT NULL,
  `bizrule` text,
  `data` text,
  `itemname` varchar(64) NOT NULL,
  PRIMARY KEY  (`userid`,`itemname`),
  KEY `fk_cruge_authassignment_cruge_authitem1_idx` (`itemname`),
  KEY `fk_cruge_authassignment_user_idx` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `cruge_authassignment`
--

INSERT INTO `cruge_authassignment` VALUES(3, NULL, 'N;', 'Administrator');
INSERT INTO `cruge_authassignment` VALUES(4, NULL, 'N;', 'Administrator');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_authitem`
--

CREATE TABLE `cruge_authitem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY  (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `cruge_authitem`
--

INSERT INTO `cruge_authitem` VALUES('action_admin_admin', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_banks_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_banks_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_banks_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_banks_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_banks_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_budgetformat_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_budgetformat_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_budgetFormat_getFormat', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_budgetformat_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_budgetformat_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_budgetformat_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_cabanaDiscount_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_cabanadiscount_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_cabanaDiscount_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_cabanadiscount_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_cabanadiscount_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campedAndDaypass_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campedanddaypass_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campedAndDaypass_getTypeReservation', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campedAndDaypass_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campedAndDaypass_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campedAndDaypass_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campeddiscount_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campeddiscount_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campedDiscount_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campeddiscount_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_campeddiscount_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_charges_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_charges_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_charges_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_charges_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_charges_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_concepts_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_concepts_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_concepts_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_concepts_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_concepts_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_customers_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_customers_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_customers_getEmail', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_customers_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_customers_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_customers_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_labels_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_labels_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_labels_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_labels_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_labels_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_payments_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_payments_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_payments_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_payments_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_payments_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_policies_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_policies_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_policies_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_policies_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_policies_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rates_clone', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rates_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rates_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rates_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rates_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rates_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_book', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_budget', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_budgetWithDiscount', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_cabanaCalendar', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_campedCalendar', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_cotizacion', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_dayPassBudget', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_daypassundiscountedbudget', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_editable', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_exportexcel', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_exportpdf', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_getChildren', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_getRoomCapacity', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_getRooms', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_gridreservation', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_quote', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_reservations', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_saveReservation', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_scheduler_cabana', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_scheduler_camped', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_scheduler_data', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_sendBudget', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_sendbyemail', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_undiscountedBudget', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_reservation_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_roomstype_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_roomstype_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_roomstype_gettypeid', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_roomstype_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_roomstype_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_roomstype_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rooms_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rooms_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rooms_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rooms_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_rooms_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_seasons_calendar', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_seasons_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_seasons_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_seasons_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_seasons_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_seasons_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_site_contact', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_site_error', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_site_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_site_login', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_site_login2', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_site_logout', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_typereservation_create', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_typereservation_delete', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_typereservation_index', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_typereservation_update', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_typereservation_view', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_editprofile', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_rbacajaxassignment', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_rbacajaxsetchilditem', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_rbacauthitemchilditems', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_rbacauthitemcreate', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_rbacauthitemupdate', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_rbaclistroles', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_rbacusersassignments', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_sessionadmin', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_systemupdate', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_usermanagementadmin', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_usermanagementcreate', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_usermanagementupdate', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('action_ui_usersaved', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('Administrator', 2, 'administrador del sistema', '', 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_banks', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_budgetformat', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_cabanadiscount', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_campedanddaypass', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_campeddiscount', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_charges', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_concepts', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_customers', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_labels', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_payments', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_policies', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_rates', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_reservation', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_rooms', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_roomstype', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_seasons', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_site', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('controller_typereservation', 0, '', NULL, 'N;');
INSERT INTO `cruge_authitem` VALUES('edit-advanced-profile-features', 0, '/home/content/n/e/n/nenecoco/html/protected/modules/cruge/views/ui/usermanagementupdate.php linea 114', NULL, 'N;');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_authitemchild`
--

CREATE TABLE `cruge_authitemchild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY  (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `cruge_authitemchild`
--

INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_budgetformat_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_budgetformat_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_budgetFormat_getFormat');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_budgetformat_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_budgetformat_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_budgetformat_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_cabanaDiscount_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_cabanadiscount_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_cabanaDiscount_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_cabanadiscount_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_cabanadiscount_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campedAndDaypass_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campedanddaypass_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campedAndDaypass_getTypeReservation');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campedAndDaypass_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campedAndDaypass_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campedAndDaypass_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campeddiscount_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campeddiscount_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campedDiscount_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campeddiscount_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_campeddiscount_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_customers_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_customers_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_customers_getEmail');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_customers_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_customers_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_customers_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_labels_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_labels_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_labels_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_labels_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_labels_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_policies_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_policies_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_policies_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_policies_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_policies_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rates_clone');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rates_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rates_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rates_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rates_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rates_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_book');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_budget');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_budgetWithDiscount');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_cabanaCalendar');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_campedCalendar');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_cotizacion');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_dayPassBudget');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_daypassundiscountedbudget');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_editable');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_exportexcel');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_exportpdf');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_getChildren');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_getRoomCapacity');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_getRooms');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_quote');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_reservations');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_saveReservation');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_scheduler_cabana');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_scheduler_camped');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_scheduler_data');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_sendBudget');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_sendbyemail');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_undiscountedBudget');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_reservation_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_roomstype_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_roomstype_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_roomstype_gettypeid');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_roomstype_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_roomstype_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_roomstype_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rooms_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rooms_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rooms_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rooms_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_rooms_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_seasons_calendar');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_seasons_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_seasons_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_seasons_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_seasons_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_seasons_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_site_contact');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_site_error');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_site_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_site_login');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_site_login2');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_site_logout');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_typereservation_create');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_typereservation_delete');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_typereservation_index');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_typereservation_update');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_typereservation_view');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_editprofile');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_rbacajaxassignment');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_rbacajaxsetchilditem');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_rbacauthitemchilditems');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_rbacauthitemcreate');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_rbacauthitemupdate');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_rbaclistroles');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_rbacusersassignments');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_sessionadmin');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_systemupdate');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_usermanagementadmin');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_usermanagementcreate');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_usermanagementupdate');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'action_ui_usersaved');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_budgetformat');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_cabanadiscount');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_campedanddaypass');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_campeddiscount');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_customers');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_labels');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_policies');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_rates');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_reservation');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_rooms');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_roomstype');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_seasons');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_site');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'controller_typereservation');
INSERT INTO `cruge_authitemchild` VALUES('Administrator', 'edit-advanced-profile-features');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_field`
--

CREATE TABLE `cruge_field` (
  `idfield` int(11) NOT NULL auto_increment,
  `fieldname` varchar(20) NOT NULL,
  `longname` varchar(50) default NULL,
  `position` int(11) default '0',
  `required` int(11) default '0',
  `fieldtype` int(11) default '0',
  `fieldsize` int(11) default '20',
  `maxlength` int(11) default '45',
  `showinreports` int(11) default '0',
  `useregexp` varchar(512) default NULL,
  `useregexpmsg` varchar(512) default NULL,
  `predetvalue` mediumblob,
  PRIMARY KEY  (`idfield`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `cruge_field`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_fieldvalue`
--

CREATE TABLE `cruge_fieldvalue` (
  `idfieldvalue` int(11) NOT NULL auto_increment,
  `iduser` int(11) NOT NULL,
  `idfield` int(11) NOT NULL,
  `value` blob,
  PRIMARY KEY  (`idfieldvalue`),
  KEY `fk_cruge_fieldvalue_cruge_user1_idx` (`iduser`),
  KEY `fk_cruge_fieldvalue_cruge_field1_idx` (`idfield`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `cruge_fieldvalue`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_session`
--

CREATE TABLE `cruge_session` (
  `idsession` int(11) NOT NULL auto_increment,
  `iduser` int(11) NOT NULL,
  `created` bigint(30) default NULL,
  `expire` bigint(30) default NULL,
  `status` int(11) default '0',
  `ipaddress` varchar(45) default NULL,
  `usagecount` int(11) default '0',
  `lastusage` bigint(30) default NULL,
  `logoutdate` bigint(30) default NULL,
  `ipaddressout` varchar(45) default NULL,
  PRIMARY KEY  (`idsession`),
  KEY `crugesession_iduser` (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=305 ;

--
-- Volcar la base de datos para la tabla `cruge_session`
--

INSERT INTO `cruge_session` VALUES(1, 1, 1379717235, 1379719035, 0, '189.149.120.55', 2, 1379718178, NULL, NULL);
INSERT INTO `cruge_session` VALUES(2, 1, 1379720947, 1379722747, 0, '189.149.120.55', 1, 1379720947, NULL, NULL);
INSERT INTO `cruge_session` VALUES(3, 1, 1379723926, 1379725726, 1, '189.149.120.55', 1, 1379723926, NULL, NULL);
INSERT INTO `cruge_session` VALUES(4, 1, 1379779956, 1379781756, 0, '189.149.120.55', 1, 1379779956, NULL, NULL);
INSERT INTO `cruge_session` VALUES(5, 1, 1379787277, 1379789077, 0, '189.149.125.162', 2, 1379787899, NULL, NULL);
INSERT INTO `cruge_session` VALUES(6, 1, 1379794316, 1379796116, 0, '189.149.120.55', 2, 1379794857, NULL, NULL);
INSERT INTO `cruge_session` VALUES(7, 1, 1379798353, 1379800153, 0, '189.149.120.55', 1, 1379798353, NULL, NULL);
INSERT INTO `cruge_session` VALUES(8, 1, 1379952964, 1379954764, 0, '189.149.120.55', 1, 1379952964, NULL, NULL);
INSERT INTO `cruge_session` VALUES(9, 1, 1379960566, 1379962366, 0, '189.149.120.55', 1, 1379960566, NULL, NULL);
INSERT INTO `cruge_session` VALUES(10, 1, 1379963013, 1379964813, 1, '189.149.120.55', 1, 1379963013, NULL, NULL);
INSERT INTO `cruge_session` VALUES(11, 1, 1379966186, 1379967986, 0, '189.149.120.55', 1, 1379966186, NULL, NULL);
INSERT INTO `cruge_session` VALUES(12, 1, 1380032302, 1380034102, 0, '189.129.26.141', 2, 1380032778, NULL, NULL);
INSERT INTO `cruge_session` VALUES(13, 1, 1380034386, 1380036186, 0, '189.129.26.141', 1, 1380034386, NULL, NULL);
INSERT INTO `cruge_session` VALUES(14, 1, 1380036196, 1380037996, 1, '189.149.120.55', 2, 1380037542, NULL, NULL);
INSERT INTO `cruge_session` VALUES(15, 1, 1380061620, 1380063420, 0, '189.149.120.55', 2, 1380063143, NULL, NULL);
INSERT INTO `cruge_session` VALUES(16, 1, 1380063648, 1380065448, 1, '189.149.120.55', 1, 1380063648, NULL, NULL);
INSERT INTO `cruge_session` VALUES(17, 1, 1380126557, 1380128357, 1, '189.149.42.18', 1, 1380126557, NULL, NULL);
INSERT INTO `cruge_session` VALUES(18, 1, 1380812859, 1380814659, 0, '189.129.40.148', 1, 1380812859, NULL, NULL);
INSERT INTO `cruge_session` VALUES(19, 1, 1380814696, 1380816496, 0, '189.129.40.148', 1, 1380814696, NULL, NULL);
INSERT INTO `cruge_session` VALUES(20, 1, 1380818063, 1380819863, 0, '189.129.40.148', 2, 1380819072, NULL, NULL);
INSERT INTO `cruge_session` VALUES(21, 1, 1380819942, 1380821742, 0, '189.129.40.148', 2, 1380820009, NULL, NULL);
INSERT INTO `cruge_session` VALUES(22, 1, 1380821794, 1380823594, 1, '189.129.40.148', 1, 1380821794, NULL, NULL);
INSERT INTO `cruge_session` VALUES(23, 1, 1380831620, 1380833420, 1, '189.129.40.148', 2, 1380832979, NULL, NULL);
INSERT INTO `cruge_session` VALUES(24, 1, 1380894336, 1380896136, 0, '189.129.40.148', 1, 1380894336, NULL, NULL);
INSERT INTO `cruge_session` VALUES(25, 1, 1380896235, 1380898035, 0, '189.129.40.148', 1, 1380896235, NULL, NULL);
INSERT INTO `cruge_session` VALUES(26, 1, 1380900833, 1380902633, 0, '189.129.40.148', 1, 1380900833, NULL, NULL);
INSERT INTO `cruge_session` VALUES(27, 1, 1380902840, 1380904640, 0, '189.129.40.148', 1, 1380902840, NULL, NULL);
INSERT INTO `cruge_session` VALUES(28, 1, 1380905024, 1380906824, 0, '189.129.40.148', 1, 1380905024, NULL, NULL);
INSERT INTO `cruge_session` VALUES(29, 1, 1380908578, 1380910378, 1, '189.129.40.148', 1, 1380908578, NULL, NULL);
INSERT INTO `cruge_session` VALUES(30, 1, 1380919498, 1380921298, 1, '189.129.40.148', 1, 1380919498, NULL, NULL);
INSERT INTO `cruge_session` VALUES(31, 1, 1380981965, 1380983765, 0, '189.129.40.148', 1, 1380981965, NULL, NULL);
INSERT INTO `cruge_session` VALUES(32, 1, 1380983899, 1380985699, 0, '189.129.40.148', 1, 1380983899, NULL, NULL);
INSERT INTO `cruge_session` VALUES(33, 1, 1380986467, 1380988267, 1, '189.129.40.148', 1, 1380986467, NULL, NULL);
INSERT INTO `cruge_session` VALUES(34, 1, 1381154110, 1381155910, 0, '189.129.40.148', 1, 1381154110, NULL, NULL);
INSERT INTO `cruge_session` VALUES(35, 1, 1381156855, 1381158655, 0, '189.149.22.156', 2, 1381157783, NULL, NULL);
INSERT INTO `cruge_session` VALUES(36, 1, 1381158665, 1381160465, 0, '189.129.40.148', 1, 1381158665, NULL, NULL);
INSERT INTO `cruge_session` VALUES(37, 1, 1381160527, 1381162327, 1, '189.129.40.148', 1, 1381160527, NULL, NULL);
INSERT INTO `cruge_session` VALUES(38, 1, 1381163357, 1381165157, 0, '189.149.24.83', 1, 1381163357, NULL, NULL);
INSERT INTO `cruge_session` VALUES(39, 1, 1381181165, 1381182965, 1, '189.129.46.253', 1, 1381181165, NULL, NULL);
INSERT INTO `cruge_session` VALUES(40, 1, 1381255238, 1381257038, 1, '189.149.24.83', 1, 1381255238, NULL, NULL);
INSERT INTO `cruge_session` VALUES(41, 1, 1381270585, 1381272385, 1, '189.129.30.3', 1, 1381270585, NULL, NULL);
INSERT INTO `cruge_session` VALUES(42, 1, 1381333039, 1381334839, 1, '189.129.2.252', 1, 1381333039, NULL, NULL);
INSERT INTO `cruge_session` VALUES(43, 1, 1381339999, 1381341799, 1, '189.129.2.252', 2, 1381340260, NULL, NULL);
INSERT INTO `cruge_session` VALUES(44, 1, 1381414997, 1381416797, 1, '189.129.2.252', 1, 1381414997, NULL, NULL);
INSERT INTO `cruge_session` VALUES(45, 1, 1381534835, 1381536635, 1, '189.129.2.252', 1, 1381534835, NULL, NULL);
INSERT INTO `cruge_session` VALUES(46, 1, 1381584883, 1381586683, 0, '189.129.2.252', 1, 1381584883, NULL, NULL);
INSERT INTO `cruge_session` VALUES(47, 1, 1381586837, 1381588637, 1, '189.129.2.252', 1, 1381586837, NULL, NULL);
INSERT INTO `cruge_session` VALUES(48, 1, 1381763723, 1381765523, 0, '189.129.2.252', 1, 1381763723, NULL, NULL);
INSERT INTO `cruge_session` VALUES(49, 1, 1381766331, 1381768131, 1, '189.129.2.252', 1, 1381766331, NULL, NULL);
INSERT INTO `cruge_session` VALUES(50, 1, 1383064403, 1383066203, 0, '189.129.15.245', 1, 1383064403, NULL, NULL);
INSERT INTO `cruge_session` VALUES(51, 1, 1383062364, 1383064164, 0, '127.0.0.1', 2, 1383064066, NULL, NULL);
INSERT INTO `cruge_session` VALUES(52, 1, 1383064388, 1383066188, 0, '127.0.0.1', 2, 1383064455, NULL, NULL);
INSERT INTO `cruge_session` VALUES(53, 1, 1383066199, 1383067999, 0, '127.0.0.1', 1, 1383066199, NULL, NULL);
INSERT INTO `cruge_session` VALUES(54, 1, 1383068062, 1383069862, 1, '127.0.0.1', 1, 1383068062, NULL, NULL);
INSERT INTO `cruge_session` VALUES(55, 1, 1383121298, 1383123098, 0, '127.0.0.1', 1, 1383121298, NULL, NULL);
INSERT INTO `cruge_session` VALUES(56, 1, 1383123494, 1383125294, 0, '127.0.0.1', 2, 1383124365, NULL, NULL);
INSERT INTO `cruge_session` VALUES(57, 1, 1383125818, 1383127618, 0, '127.0.0.1', 1, 1383125818, NULL, NULL);
INSERT INTO `cruge_session` VALUES(58, 1, 1383128829, 1383130629, 0, '127.0.0.1', 2, 1383129478, NULL, NULL);
INSERT INTO `cruge_session` VALUES(59, 1, 1383130827, 1383132627, 0, '127.0.0.1', 1, 1383130827, NULL, NULL);
INSERT INTO `cruge_session` VALUES(60, 1, 1383132667, 1383134467, 1, '127.0.0.1', 1, 1383132667, NULL, NULL);
INSERT INTO `cruge_session` VALUES(61, 1, 1383145705, 1383147505, 0, '127.0.0.1', 1, 1383145705, NULL, NULL);
INSERT INTO `cruge_session` VALUES(62, 1, 1383148593, 1383150393, 0, '127.0.0.1', 1, 1383148593, NULL, NULL);
INSERT INTO `cruge_session` VALUES(63, 1, 1383150412, 1383152212, 0, '127.0.0.1', 1, 1383150412, NULL, NULL);
INSERT INTO `cruge_session` VALUES(64, 1, 1383152244, 1383154044, 0, '127.0.0.1', 1, 1383152244, NULL, NULL);
INSERT INTO `cruge_session` VALUES(65, 1, 1383154184, 1383155984, 1, '127.0.0.1', 1, 1383154184, NULL, NULL);
INSERT INTO `cruge_session` VALUES(66, 1, 1383208212, 1383210012, 0, '127.0.0.1', 1, 1383208212, NULL, NULL);
INSERT INTO `cruge_session` VALUES(67, 1, 1383210441, 1383212241, 0, '127.0.0.1', 1, 1383210441, NULL, NULL);
INSERT INTO `cruge_session` VALUES(68, 1, 1383212422, 1383214222, 0, '127.0.0.1', 1, 1383212422, NULL, NULL);
INSERT INTO `cruge_session` VALUES(69, 1, 1383214260, 1383216060, 0, '127.0.0.1', 1, 1383214260, NULL, NULL);
INSERT INTO `cruge_session` VALUES(70, 1, 1383216457, 1383218257, 0, '127.0.0.1', 1, 1383216457, NULL, NULL);
INSERT INTO `cruge_session` VALUES(71, 1, 1383218278, 1383220078, 0, '127.0.0.1', 1, 1383218278, NULL, NULL);
INSERT INTO `cruge_session` VALUES(72, 1, 1383220125, 1383221925, 1, '127.0.0.1', 1, 1383220125, NULL, NULL);
INSERT INTO `cruge_session` VALUES(73, 1, 1383232756, 1383234556, 0, '127.0.0.1', 1, 1383232756, NULL, NULL);
INSERT INTO `cruge_session` VALUES(74, 1, 1383235422, 1383237222, 0, '127.0.0.1', 1, 1383235422, NULL, NULL);
INSERT INTO `cruge_session` VALUES(75, 1, 1383237288, 1383239088, 0, '127.0.0.1', 1, 1383237288, NULL, NULL);
INSERT INTO `cruge_session` VALUES(76, 1, 1383239983, 1383241783, 1, '127.0.0.1', 1, 1383239983, NULL, NULL);
INSERT INTO `cruge_session` VALUES(77, 1, 1383295092, 1383296892, 0, '127.0.0.1', 2, 1383295835, NULL, NULL);
INSERT INTO `cruge_session` VALUES(78, 1, 1383296917, 1383298717, 0, '127.0.0.1', 1, 1383296917, NULL, NULL);
INSERT INTO `cruge_session` VALUES(79, 1, 1383298839, 1383300639, 0, '127.0.0.1', 1, 1383298839, NULL, NULL);
INSERT INTO `cruge_session` VALUES(80, 1, 1383300751, 1383302551, 0, '127.0.0.1', 1, 1383300751, NULL, NULL);
INSERT INTO `cruge_session` VALUES(81, 1, 1383302578, 1383304378, 0, '127.0.0.1', 1, 1383302578, NULL, NULL);
INSERT INTO `cruge_session` VALUES(82, 1, 1383304473, 1383306273, 0, '127.0.0.1', 1, 1383304473, NULL, NULL);
INSERT INTO `cruge_session` VALUES(83, 1, 1383306364, 1383308164, 1, '127.0.0.1', 1, 1383306364, NULL, NULL);
INSERT INTO `cruge_session` VALUES(84, 1, 1383318875, 1383320675, 0, '127.0.0.1', 2, 1383319630, NULL, NULL);
INSERT INTO `cruge_session` VALUES(85, 1, 1383321314, 1383323114, 0, '127.0.0.1', 1, 1383321314, NULL, NULL);
INSERT INTO `cruge_session` VALUES(86, 1, 1383324122, 1383325922, 0, '127.0.0.1', 1, 1383324122, NULL, NULL);
INSERT INTO `cruge_session` VALUES(87, 1, 1383326832, 1383328632, 1, '127.0.0.1', 1, 1383326832, NULL, NULL);
INSERT INTO `cruge_session` VALUES(88, 1, 1383379945, 1383381745, 0, '127.0.0.1', 2, 1383380780, NULL, NULL);
INSERT INTO `cruge_session` VALUES(89, 1, 1383381795, 1383383595, 0, '127.0.0.1', 1, 1383381795, NULL, NULL);
INSERT INTO `cruge_session` VALUES(90, 1, 1383383643, 1383385443, 0, '127.0.0.1', 2, 1383384252, NULL, NULL);
INSERT INTO `cruge_session` VALUES(91, 1, 1383385977, 1383387777, 0, '127.0.0.1', 1, 1383385977, NULL, NULL);
INSERT INTO `cruge_session` VALUES(92, 1, 1383388006, 1383389806, 0, '127.0.0.1', 1, 1383388006, NULL, NULL);
INSERT INTO `cruge_session` VALUES(93, 1, 1383390462, 1383392262, 0, '127.0.0.1', 1, 1383390462, NULL, NULL);
INSERT INTO `cruge_session` VALUES(94, 1, 1383392588, 1383394388, 0, '127.0.0.1', 1, 1383392588, NULL, NULL);
INSERT INTO `cruge_session` VALUES(95, 1, 1383394941, 1383396741, 1, '127.0.0.1', 1, 1383394941, NULL, NULL);
INSERT INTO `cruge_session` VALUES(96, 1, 1383553562, 1383555362, 0, '127.0.0.1', 1, 1383553562, NULL, NULL);
INSERT INTO `cruge_session` VALUES(97, 1, 1383556409, 1383558209, 0, '127.0.0.1', 1, 1383556409, NULL, NULL);
INSERT INTO `cruge_session` VALUES(98, 1, 1383558606, 1383560406, 0, '127.0.0.1', 1, 1383558606, NULL, NULL);
INSERT INTO `cruge_session` VALUES(99, 1, 1383561624, 1383563424, 0, '127.0.0.1', 1, 1383561624, NULL, NULL);
INSERT INTO `cruge_session` VALUES(100, 1, 1383563445, 1383565245, 0, '127.0.0.1', 1, 1383563445, NULL, NULL);
INSERT INTO `cruge_session` VALUES(101, 1, 1383565894, 1383567694, 1, '127.0.0.1', 1, 1383565894, NULL, NULL);
INSERT INTO `cruge_session` VALUES(102, 1, 1383576296, 1383578096, 0, '127.0.0.1', 1, 1383576296, NULL, NULL);
INSERT INTO `cruge_session` VALUES(103, 1, 1383578153, 1383579953, 0, '127.0.0.1', 1, 1383578153, NULL, NULL);
INSERT INTO `cruge_session` VALUES(104, 1, 1383580443, 1383582243, 0, '127.0.0.1', 1, 1383580443, NULL, NULL);
INSERT INTO `cruge_session` VALUES(105, 1, 1383582290, 1383584090, 0, '127.0.0.1', 2, 1383582626, NULL, NULL);
INSERT INTO `cruge_session` VALUES(106, 1, 1383584493, 1383586293, 1, '127.0.0.1', 1, 1383584493, NULL, NULL);
INSERT INTO `cruge_session` VALUES(107, 1, 1383639838, 1383641638, 0, '127.0.0.1', 1, 1383639838, NULL, NULL);
INSERT INTO `cruge_session` VALUES(108, 1, 1383642072, 1383643872, 0, '127.0.0.1', 1, 1383642072, NULL, NULL);
INSERT INTO `cruge_session` VALUES(109, 1, 1383643947, 1383645747, 0, '127.0.0.1', 1, 1383643947, NULL, NULL);
INSERT INTO `cruge_session` VALUES(110, 1, 1383645758, 1383647558, 0, '127.0.0.1', 1, 1383645758, NULL, NULL);
INSERT INTO `cruge_session` VALUES(111, 1, 1383647631, 1383649431, 0, '127.0.0.1', 1, 1383647631, NULL, NULL);
INSERT INTO `cruge_session` VALUES(112, 1, 1383649584, 1383651384, 0, '127.0.0.1', 3, 1383650806, NULL, NULL);
INSERT INTO `cruge_session` VALUES(113, 1, 1383651699, 1383653499, 0, '127.0.0.1', 1, 1383651699, NULL, NULL);
INSERT INTO `cruge_session` VALUES(114, 1, 1383653560, 1383655360, 1, '127.0.0.1', 1, 1383653560, NULL, NULL);
INSERT INTO `cruge_session` VALUES(115, 1, 1383662884, 1383664684, 1, '127.0.0.1', 1, 1383662884, NULL, NULL);
INSERT INTO `cruge_session` VALUES(116, 1, 1383664856, 1383666656, 0, '127.0.0.1', 1, 1383664856, NULL, NULL);
INSERT INTO `cruge_session` VALUES(117, 1, 1383666732, 1383668532, 0, '127.0.0.1', 1, 1383666732, NULL, NULL);
INSERT INTO `cruge_session` VALUES(118, 1, 1383693250, 1383695050, 0, '127.0.0.1', 1, 1383693250, NULL, NULL);
INSERT INTO `cruge_session` VALUES(119, 1, 1383695145, 1383696945, 0, '127.0.0.1', 1, 1383695145, NULL, NULL);
INSERT INTO `cruge_session` VALUES(120, 1, 1383757464, 1383759264, 1, '127.0.0.1', 1, 1383757464, NULL, NULL);
INSERT INTO `cruge_session` VALUES(121, 1, 1383814765, 1383816565, 0, '127.0.0.1', 1, 1383814765, NULL, NULL);
INSERT INTO `cruge_session` VALUES(122, 1, 1383816739, 1383818539, 0, '127.0.0.1', 1, 1383816739, NULL, NULL);
INSERT INTO `cruge_session` VALUES(123, 1, 1383818609, 1383820409, 0, '127.0.0.1', 1, 1383818609, NULL, NULL);
INSERT INTO `cruge_session` VALUES(124, 1, 1383821410, 1383823210, 0, '127.0.0.1', 1, 1383821410, NULL, NULL);
INSERT INTO `cruge_session` VALUES(125, 1, 1383823320, 1383825120, 0, '127.0.0.1', 1, 1383823320, NULL, NULL);
INSERT INTO `cruge_session` VALUES(126, 1, 1383825187, 1383826987, 1, '127.0.0.1', 1, 1383825187, NULL, NULL);
INSERT INTO `cruge_session` VALUES(127, 1, 1383835745, 1383837545, 0, '127.0.0.1', 1, 1383835745, NULL, NULL);
INSERT INTO `cruge_session` VALUES(128, 1, 1383837560, 1383839360, 0, '127.0.0.1', 1, 1383837560, NULL, NULL);
INSERT INTO `cruge_session` VALUES(129, 1, 1383839662, 1383841462, 0, '127.0.0.1', 2, 1383840766, NULL, NULL);
INSERT INTO `cruge_session` VALUES(130, 1, 1383842155, 1383843955, 0, '127.0.0.1', 1, 1383842155, NULL, NULL);
INSERT INTO `cruge_session` VALUES(131, 1, 1383843980, 1383845780, 1, '127.0.0.1', 1, 1383843980, NULL, NULL);
INSERT INTO `cruge_session` VALUES(132, 1, 1383898862, 1383900662, 0, '127.0.0.1', 1, 1383898862, NULL, NULL);
INSERT INTO `cruge_session` VALUES(133, 1, 1383901524, 1383903324, 0, '127.0.0.1', 1, 1383901524, NULL, NULL);
INSERT INTO `cruge_session` VALUES(134, 1, 1383903945, 1383905745, 0, '127.0.0.1', 1, 1383903945, NULL, NULL);
INSERT INTO `cruge_session` VALUES(135, 1, 1383907048, 1383908848, 0, '127.0.0.1', 1, 1383907048, NULL, NULL);
INSERT INTO `cruge_session` VALUES(136, 1, 1383908863, 1383910663, 0, '127.0.0.1', 1, 1383908863, NULL, NULL);
INSERT INTO `cruge_session` VALUES(137, 1, 1383911702, 1383913502, 1, '127.0.0.1', 1, 1383911702, NULL, NULL);
INSERT INTO `cruge_session` VALUES(138, 1, 1383921928, 1383923728, 1, '127.0.0.1', 1, 1383921928, NULL, NULL);
INSERT INTO `cruge_session` VALUES(139, 1, 1383923959, 1383925759, 0, '127.0.0.1', 1, 1383923959, NULL, NULL);
INSERT INTO `cruge_session` VALUES(140, 1, 1383926544, 1383928344, 0, '127.0.0.1', 1, 1383926544, NULL, NULL);
INSERT INTO `cruge_session` VALUES(141, 1, 1383928477, 1383930277, 0, '127.0.0.1', 1, 1383928477, NULL, NULL);
INSERT INTO `cruge_session` VALUES(142, 1, 1383931551, 1383933351, 1, '127.0.0.1', 1, 1383931551, NULL, NULL);
INSERT INTO `cruge_session` VALUES(143, 1, 1383986235, 1383988035, 0, '127.0.0.1', 1, 1383986235, NULL, NULL);
INSERT INTO `cruge_session` VALUES(144, 1, 1383988472, 1383990272, 0, '127.0.0.1', 1, 1383988472, NULL, NULL);
INSERT INTO `cruge_session` VALUES(145, 1, 1383991040, 1383992840, 0, '127.0.0.1', 1, 1383991040, NULL, NULL);
INSERT INTO `cruge_session` VALUES(146, 1, 1383992852, 1383994652, 0, '127.0.0.1', 1, 1383992852, NULL, NULL);
INSERT INTO `cruge_session` VALUES(147, 1, 1383995216, 1383997016, 0, '127.0.0.1', 1, 1383995216, NULL, NULL);
INSERT INTO `cruge_session` VALUES(148, 1, 1383998065, 1383999865, 1, '127.0.0.1', 1, 1383998065, NULL, NULL);
INSERT INTO `cruge_session` VALUES(149, 1, 1384009336, 1384011136, 0, '127.0.0.1', 1, 1384009336, NULL, NULL);
INSERT INTO `cruge_session` VALUES(150, 1, 1384011191, 1384012991, 0, '127.0.0.1', 1, 1384011191, NULL, NULL);
INSERT INTO `cruge_session` VALUES(151, 1, 1384013446, 1384015246, 0, '127.0.0.1', 1, 1384013446, NULL, NULL);
INSERT INTO `cruge_session` VALUES(152, 1, 1384015453, 1384017253, 0, '127.0.0.1', 1, 1384015453, NULL, NULL);
INSERT INTO `cruge_session` VALUES(153, 1, 1384017273, 1384019073, 1, '127.0.0.1', 1, 1384017273, NULL, NULL);
INSERT INTO `cruge_session` VALUES(154, 1, 1384071597, 1384073397, 0, '127.0.0.1', 1, 1384071597, NULL, NULL);
INSERT INTO `cruge_session` VALUES(155, 1, 1384077444, 1384079244, 0, '127.0.0.1', 1, 1384077444, NULL, NULL);
INSERT INTO `cruge_session` VALUES(156, 1, 1384081494, 1384083294, 0, '127.0.0.1', 4, 1384082612, NULL, NULL);
INSERT INTO `cruge_session` VALUES(157, 1, 1384083338, 1384085138, 0, '127.0.0.1', 1, 1384083338, NULL, NULL);
INSERT INTO `cruge_session` VALUES(158, 1, 1384087054, 1384088854, 1, '127.0.0.1', 1, 1384087054, NULL, NULL);
INSERT INTO `cruge_session` VALUES(159, 1, 1384245856, 1384247656, 0, '127.0.0.1', 1, 1384245856, NULL, NULL);
INSERT INTO `cruge_session` VALUES(160, 1, 1384250654, 1384252454, 0, '127.0.0.1', 1, 1384250654, NULL, NULL);
INSERT INTO `cruge_session` VALUES(161, 1, 1384252546, 1384254346, 0, '127.0.0.1', 1, 1384252546, NULL, NULL);
INSERT INTO `cruge_session` VALUES(162, 1, 1384254353, 1384256153, 0, '127.0.0.1', 1, 1384254353, NULL, NULL);
INSERT INTO `cruge_session` VALUES(163, 1, 1384256447, 1384258247, 1, '127.0.0.1', 1, 1384256447, NULL, NULL);
INSERT INTO `cruge_session` VALUES(164, 1, 1384267711, 1384269511, 0, '127.0.0.1', 1, 1384267711, NULL, NULL);
INSERT INTO `cruge_session` VALUES(165, 1, 1384269898, 1384271698, 0, '127.0.0.1', 1, 1384269898, NULL, NULL);
INSERT INTO `cruge_session` VALUES(166, 1, 1384272080, 1384273880, 0, '127.0.0.1', 1, 1384272080, NULL, NULL);
INSERT INTO `cruge_session` VALUES(167, 1, 1384274065, 1384275865, 0, '127.0.0.1', 1, 1384274065, NULL, NULL);
INSERT INTO `cruge_session` VALUES(168, 1, 1384275979, 1384277779, 1, '127.0.0.1', 2, 1384276888, NULL, NULL);
INSERT INTO `cruge_session` VALUES(169, 1, 1384332166, 1384333966, 0, '127.0.0.1', 1, 1384332166, NULL, NULL);
INSERT INTO `cruge_session` VALUES(170, 1, 1384334603, 1384336403, 0, '127.0.0.1', 1, 1384334603, NULL, NULL);
INSERT INTO `cruge_session` VALUES(171, 1, 1384337166, 1384338966, 0, '127.0.0.1', 1, 1384337166, NULL, NULL);
INSERT INTO `cruge_session` VALUES(172, 1, 1384339304, 1384341104, 0, '127.0.0.1', 1, 1384339304, NULL, NULL);
INSERT INTO `cruge_session` VALUES(173, 1, 1384341168, 1384342968, 0, '127.0.0.1', 1, 1384341168, NULL, NULL);
INSERT INTO `cruge_session` VALUES(174, 1, 1384343028, 1384344828, 1, '127.0.0.1', 1, 1384343028, NULL, NULL);
INSERT INTO `cruge_session` VALUES(175, 1, 1384354416, 1384356216, 0, '127.0.0.1', 1, 1384354416, NULL, NULL);
INSERT INTO `cruge_session` VALUES(176, 1, 1384356924, 1384358724, 0, '127.0.0.1', 1, 1384356924, NULL, NULL);
INSERT INTO `cruge_session` VALUES(177, 1, 1384360144, 1384361944, 0, '127.0.0.1', 1, 1384360144, NULL, NULL);
INSERT INTO `cruge_session` VALUES(178, 1, 1384361961, 1384363761, 1, '127.0.0.1', 1, 1384361961, NULL, NULL);
INSERT INTO `cruge_session` VALUES(179, 1, 1384417841, 1384419641, 0, '127.0.0.1', 1, 1384417841, NULL, NULL);
INSERT INTO `cruge_session` VALUES(180, 1, 1384419860, 1384421660, 0, '127.0.0.1', 1, 1384419860, NULL, NULL);
INSERT INTO `cruge_session` VALUES(181, 1, 1384422470, 1384424270, 0, '127.0.0.1', 1, 1384422470, NULL, NULL);
INSERT INTO `cruge_session` VALUES(182, 1, 1384424476, 1384426276, 0, '127.0.0.1', 1, 1384424476, NULL, NULL);
INSERT INTO `cruge_session` VALUES(183, 1, 1384426336, 1384428136, 0, '127.0.0.1', 1, 1384426336, NULL, NULL);
INSERT INTO `cruge_session` VALUES(184, 1, 1384428149, 1384429949, 0, '127.0.0.1', 1, 1384428149, NULL, NULL);
INSERT INTO `cruge_session` VALUES(185, 1, 1384429968, 1384431768, 1, '127.0.0.1', 1, 1384429968, NULL, NULL);
INSERT INTO `cruge_session` VALUES(186, 1, 1384441397, 1384443197, 0, '127.0.0.1', 1, 1384441397, NULL, NULL);
INSERT INTO `cruge_session` VALUES(187, 1, 1384443937, 1384445737, 0, '127.0.0.1', 1, 1384443937, NULL, NULL);
INSERT INTO `cruge_session` VALUES(188, 1, 1384446166, 1384447966, 0, '127.0.0.1', 1, 1384446166, NULL, NULL);
INSERT INTO `cruge_session` VALUES(189, 1, 1384448245, 1384450045, 0, '127.0.0.1', 1, 1384448245, NULL, NULL);
INSERT INTO `cruge_session` VALUES(190, 1, 1384450074, 1384451874, 1, '127.0.0.1', 1, 1384450074, NULL, NULL);
INSERT INTO `cruge_session` VALUES(191, 1, 1384506048, 1384507848, 0, '127.0.0.1', 1, 1384506048, NULL, NULL);
INSERT INTO `cruge_session` VALUES(192, 1, 1384507900, 1384509700, 0, '127.0.0.1', 6, 1384505298, NULL, NULL);
INSERT INTO `cruge_session` VALUES(193, 1, 1384509737, 1384511537, 1, '127.0.0.1', 1, 1384509737, NULL, NULL);
INSERT INTO `cruge_session` VALUES(194, 1, 1384514907, 1384516707, 1, '127.0.0.1', 1, 1384514907, NULL, NULL);
INSERT INTO `cruge_session` VALUES(195, 1, 1384527485, 1384529285, 0, '127.0.0.1', 2, 1384528251, NULL, NULL);
INSERT INTO `cruge_session` VALUES(196, 1, 1384529649, 1384531449, 0, '127.0.0.1', 1, 1384529649, NULL, NULL);
INSERT INTO `cruge_session` VALUES(197, 1, 1384531529, 1384533329, 1, '127.0.0.1', 1, 1384531529, NULL, NULL);
INSERT INTO `cruge_session` VALUES(198, 1, 1384596158, 1384597958, 1, '127.0.0.1', 1, 1384596158, NULL, NULL);
INSERT INTO `cruge_session` VALUES(199, 1, 1384601573, 1384603373, 0, '127.0.0.1', 1, 1384601573, NULL, NULL);
INSERT INTO `cruge_session` VALUES(200, 1, 1384604305, 1384606105, 0, '127.0.0.1', 1, 1384604305, NULL, NULL);
INSERT INTO `cruge_session` VALUES(201, 1, 1384606540, 1384608340, 1, '127.0.0.1', 1, 1384606540, NULL, NULL);
INSERT INTO `cruge_session` VALUES(202, 1, 1384849594, 1384851394, 0, '127.0.0.1', 1, 1384849594, NULL, NULL);
INSERT INTO `cruge_session` VALUES(203, 1, 1384851969, 1384853769, 0, '127.0.0.1', 3, 1384853019, NULL, NULL);
INSERT INTO `cruge_session` VALUES(204, 1, 1384854342, 1384856142, 0, '127.0.0.1', 2, 1384854729, NULL, NULL);
INSERT INTO `cruge_session` VALUES(205, 1, 1384856186, 1384857986, 0, '127.0.0.1', 1, 1384856186, NULL, NULL);
INSERT INTO `cruge_session` VALUES(206, 1, 1384858028, 1384859828, 0, '127.0.0.1', 2, 1384858905, NULL, NULL);
INSERT INTO `cruge_session` VALUES(207, 1, 1384860293, 1384862093, 0, '127.0.0.1', 1, 1384860293, NULL, NULL);
INSERT INTO `cruge_session` VALUES(208, 1, 1384862101, 1384863901, 1, '127.0.0.1', 1, 1384862101, NULL, NULL);
INSERT INTO `cruge_session` VALUES(209, 1, 1384871849, 1384873649, 0, '127.0.0.1', 1, 1384871849, NULL, NULL);
INSERT INTO `cruge_session` VALUES(210, 1, 1384874464, 1384876264, 0, '127.0.0.1', 1, 1384874464, NULL, NULL);
INSERT INTO `cruge_session` VALUES(211, 1, 1384876742, 1384878542, 0, '127.0.0.1', 1, 1384876742, NULL, NULL);
INSERT INTO `cruge_session` VALUES(212, 1, 1384878586, 1384880386, 0, '127.0.0.1', 1, 1384878586, NULL, NULL);
INSERT INTO `cruge_session` VALUES(213, 1, 1384880434, 1384882234, 1, '127.0.0.1', 1, 1384880434, NULL, NULL);
INSERT INTO `cruge_session` VALUES(214, 1, 1384934961, 1384936761, 0, '127.0.0.1', 1, 1384934961, NULL, NULL);
INSERT INTO `cruge_session` VALUES(215, 1, 1384936938, 1384938738, 0, '127.0.0.1', 1, 1384936938, NULL, NULL);
INSERT INTO `cruge_session` VALUES(216, 1, 1384938929, 1384940729, 0, '127.0.0.1', 1, 1384938929, NULL, NULL);
INSERT INTO `cruge_session` VALUES(217, 1, 1384940823, 1384942623, 0, '127.0.0.1', 1, 1384940823, NULL, NULL);
INSERT INTO `cruge_session` VALUES(218, 1, 1384942736, 1384944536, 1, '127.0.0.1', 1, 1384942736, NULL, NULL);
INSERT INTO `cruge_session` VALUES(219, 1, 1384959057, 1384960857, 0, '127.0.0.1', 1, 1384959057, NULL, NULL);
INSERT INTO `cruge_session` VALUES(220, 1, 1384964735, 1384966535, 0, '127.0.0.1', 1, 1384964735, NULL, NULL);
INSERT INTO `cruge_session` VALUES(221, 1, 1384966569, 1384968369, 0, '127.0.0.1', 1, 1384966569, NULL, NULL);
INSERT INTO `cruge_session` VALUES(222, 1, 1384968443, 1384970243, 1, '127.0.0.1', 1, 1384968443, NULL, NULL);
INSERT INTO `cruge_session` VALUES(223, 1, 1385022005, 1385023805, 0, '127.0.0.1', 1, 1385022005, NULL, NULL);
INSERT INTO `cruge_session` VALUES(224, 1, 1385048433, 1385050233, 0, '127.0.0.1', 1, 1385048433, NULL, NULL);
INSERT INTO `cruge_session` VALUES(225, 1, 1385050925, 1385052725, 0, '127.0.0.1', 1, 1385050925, NULL, NULL);
INSERT INTO `cruge_session` VALUES(226, 1, 1385053262, 1385055062, 0, '127.0.0.1', 2, 1385045689, NULL, NULL);
INSERT INTO `cruge_session` VALUES(227, 1, 1385055162, 1385056962, 1, '127.0.0.1', 1, 1385055162, NULL, NULL);
INSERT INTO `cruge_session` VALUES(228, 1, 1385108903, 1385110703, 0, '127.0.0.1', 1, 1385108903, NULL, NULL);
INSERT INTO `cruge_session` VALUES(229, 1, 1385111129, 1385112929, 0, '127.0.0.1', 1, 1385111129, NULL, NULL);
INSERT INTO `cruge_session` VALUES(230, 1, 1385112973, 1385114773, 0, '127.0.0.1', 1, 1385112973, NULL, NULL);
INSERT INTO `cruge_session` VALUES(231, 1, 1385115020, 1385116820, 0, '127.0.0.1', 1, 1385115020, NULL, NULL);
INSERT INTO `cruge_session` VALUES(232, 1, 1385116878, 1385118678, 0, '127.0.0.1', 1, 1385116878, NULL, NULL);
INSERT INTO `cruge_session` VALUES(233, 1, 1385118766, 1385120566, 0, '127.0.0.1', 1, 1385118766, NULL, NULL);
INSERT INTO `cruge_session` VALUES(234, 1, 1385120606, 1385122406, 1, '127.0.0.1', 1, 1385120606, NULL, NULL);
INSERT INTO `cruge_session` VALUES(235, 1, 1385132127, 1385133927, 0, '127.0.0.1', 1, 1385132127, NULL, NULL);
INSERT INTO `cruge_session` VALUES(236, 1, 1385137060, 1385138860, 1, '127.0.0.1', 1, 1385137060, NULL, NULL);
INSERT INTO `cruge_session` VALUES(237, 1, 1385164830, 1385166630, 1, '189.129.15.245', 7, 1385165559, NULL, NULL);
INSERT INTO `cruge_session` VALUES(238, 1, 1385167197, 1385168997, 0, '189.129.15.245', 1, 1385167197, NULL, NULL);
INSERT INTO `cruge_session` VALUES(239, 1, 1385170152, 1385171952, 0, '189.129.15.245', 3, 1385170724, NULL, NULL);
INSERT INTO `cruge_session` VALUES(240, 1, 1385174051, 1385175851, 0, '189.129.15.245', 3, 1385175465, NULL, NULL);
INSERT INTO `cruge_session` VALUES(241, 1, 1385176059, 1385177859, 1, '189.129.15.245', 1, 1385176059, NULL, NULL);
INSERT INTO `cruge_session` VALUES(242, 1, 1385404357, 1385406157, 1, '189.129.15.245', 2, 1385404619, NULL, NULL);
INSERT INTO `cruge_session` VALUES(243, 1, 1385418679, 1385420479, 0, '189.129.15.245', 1, 1385418679, NULL, NULL);
INSERT INTO `cruge_session` VALUES(244, 1, 1385422974, 1385424774, 1, '189.129.15.245', 1, 1385422974, NULL, NULL);
INSERT INTO `cruge_session` VALUES(245, 1, 1385492953, 1385494753, 1, '189.129.45.171', 2, 1385493246, NULL, NULL);
INSERT INTO `cruge_session` VALUES(246, 1, 1385502573, 1385504373, 1, '189.129.45.171', 4, 1385503719, NULL, NULL);
INSERT INTO `cruge_session` VALUES(247, 3, 1385503677, 1385505477, 0, '189.129.45.171', 3, 1385503926, NULL, NULL);
INSERT INTO `cruge_session` VALUES(248, 1, 1385504457, 1385506257, 1, '189.129.45.171', 2, 1385505634, NULL, NULL);
INSERT INTO `cruge_session` VALUES(249, 3, 1385505748, 1385507548, 0, '189.129.45.171', 2, 1385506241, NULL, NULL);
INSERT INTO `cruge_session` VALUES(250, 3, 1385510816, 1385512616, 1, '189.129.45.171', 1, 1385510816, NULL, NULL);
INSERT INTO `cruge_session` VALUES(251, 3, 1385563278, 1385565078, 0, '189.129.45.171', 2, 1385564008, NULL, NULL);
INSERT INTO `cruge_session` VALUES(252, 1, 1385578053, 1385579853, 1, '189.129.45.171', 1, 1385578053, NULL, NULL);
INSERT INTO `cruge_session` VALUES(253, 3, 1385588713, 1385590513, 0, '189.129.45.171', 1, 1385588713, NULL, NULL);
INSERT INTO `cruge_session` VALUES(254, 3, 1385597228, 1385599028, 1, '189.129.45.171', 1, 1385597228, NULL, NULL);
INSERT INTO `cruge_session` VALUES(255, 1, 1385597439, 1385599239, 1, '189.129.45.171', 1, 1385597439, NULL, NULL);
INSERT INTO `cruge_session` VALUES(256, 1, 1385656012, 1385657812, 1, '189.129.45.171', 1, 1385656012, NULL, NULL);
INSERT INTO `cruge_session` VALUES(257, 1, 1385658686, 1385660486, 1, '189.129.45.171', 1, 1385658686, NULL, NULL);
INSERT INTO `cruge_session` VALUES(258, 3, 1385658911, 1385660711, 1, '189.129.45.171', 1, 1385658911, NULL, NULL);
INSERT INTO `cruge_session` VALUES(259, 3, 1385677566, 1385679366, 0, '189.129.45.171', 1, 1385677566, NULL, NULL);
INSERT INTO `cruge_session` VALUES(260, 3, 1385683005, 1385684805, 1, '189.129.45.171', 1, 1385683005, NULL, NULL);
INSERT INTO `cruge_session` VALUES(261, 1, 1385830377, 1385832177, 1, '189.129.45.171', 1, 1385830377, NULL, NULL);
INSERT INTO `cruge_session` VALUES(262, 1, 1386007509, 1386009309, 1, '189.129.45.171', 1, 1386007509, NULL, NULL);
INSERT INTO `cruge_session` VALUES(263, 4, 1386008034, 1386009834, 1, '189.129.45.171', 3, 1386009097, NULL, NULL);
INSERT INTO `cruge_session` VALUES(264, 1, 1386009495, 1386011295, 1, '189.129.45.171', 3, 1386009612, NULL, NULL);
INSERT INTO `cruge_session` VALUES(265, 1, 1386021303, 1386023103, 0, '189.129.45.171', 3, 1386022643, NULL, NULL);
INSERT INTO `cruge_session` VALUES(266, 1, 1386023117, 1386024917, 0, '189.129.45.171', 1, 1386023117, NULL, NULL);
INSERT INTO `cruge_session` VALUES(267, 4, 1386023208, 1386025008, 0, '189.129.45.171', 1, 1386023208, NULL, NULL);
INSERT INTO `cruge_session` VALUES(268, 4, 1386025182, 1386026982, 1, '189.129.45.171', 1, 1386025182, NULL, NULL);
INSERT INTO `cruge_session` VALUES(269, 1, 1386025904, 1386027704, 1, '189.129.45.171', 1, 1386025904, NULL, NULL);
INSERT INTO `cruge_session` VALUES(270, 1, 1386107156, 1386167156, 1, '189.129.45.171', 1, 1386107156, NULL, NULL);
INSERT INTO `cruge_session` VALUES(271, 1, 1386173394, 1386233394, 1, '189.129.45.171', 4, 1386182786, NULL, NULL);
INSERT INTO `cruge_session` VALUES(272, 3, 1386183124, 1386243124, 1, '189.129.45.171', 1, 1386183124, NULL, NULL);
INSERT INTO `cruge_session` VALUES(273, 1, 1386255426, 1386315426, 1, '189.129.45.171', 1, 1386255426, NULL, NULL);
INSERT INTO `cruge_session` VALUES(274, 4, 1386355943, 1386415943, 1, '189.129.45.171', 1, 1386355943, NULL, NULL);
INSERT INTO `cruge_session` VALUES(275, 3, 1386687764, 1386747764, 1, '189.129.42.19', 3, 1386689910, NULL, NULL);
INSERT INTO `cruge_session` VALUES(276, 1, 1386697907, 1386757907, 1, '189.129.42.19', 3, 1386712361, NULL, NULL);
INSERT INTO `cruge_session` VALUES(277, 4, 1386698289, 1386758289, 1, '189.129.42.19', 2, 1386698291, NULL, NULL);
INSERT INTO `cruge_session` VALUES(278, 1, 1386776100, 1386836100, 1, '189.129.42.19', 5, 1386805909, NULL, NULL);
INSERT INTO `cruge_session` VALUES(279, 4, 1386786498, 1386846498, 1, '189.129.42.19', 2, 1386806832, NULL, NULL);
INSERT INTO `cruge_session` VALUES(280, 4, 1386860327, 1386920327, 1, '189.129.42.19', 2, 1386860357, NULL, NULL);
INSERT INTO `cruge_session` VALUES(281, 1, 1386863861, 1386923861, 1, '189.129.42.19', 1, 1386863861, NULL, NULL);
INSERT INTO `cruge_session` VALUES(282, 1, 1386928498, 1386988498, 1, '189.129.42.19', 3, 1386972344, NULL, NULL);
INSERT INTO `cruge_session` VALUES(283, 4, 1386951891, 1387011891, 1, '189.129.42.19', 1, 1386951891, NULL, NULL);
INSERT INTO `cruge_session` VALUES(284, 3, 1386952344, 1387012344, 1, '189.129.42.19', 1, 1386952344, NULL, NULL);
INSERT INTO `cruge_session` VALUES(285, 1, 1387038340, 1387098340, 1, '189.129.42.19', 2, 1387050523, NULL, NULL);
INSERT INTO `cruge_session` VALUES(286, 1, 1387208683, 1387268683, 1, '189.129.42.19', 5, 1387256588, NULL, NULL);
INSERT INTO `cruge_session` VALUES(287, 4, 1387210303, 1387270303, 1, '189.129.42.19', 2, 1387232599, NULL, NULL);
INSERT INTO `cruge_session` VALUES(288, 4, 1387294686, 1387354686, 1, '189.129.42.19', 11, 1387318537, NULL, NULL);
INSERT INTO `cruge_session` VALUES(289, 1, 1387294939, 1387354939, 1, '189.129.42.19', 4, 1387317276, NULL, NULL);
INSERT INTO `cruge_session` VALUES(290, 3, 1387305042, 1387365042, 1, '189.129.42.19', 2, 1387316337, NULL, NULL);
INSERT INTO `cruge_session` VALUES(291, 1, 1387380941, 1387440941, 1, '189.129.42.19', 2, 1387385800, NULL, NULL);
INSERT INTO `cruge_session` VALUES(292, 4, 1387382730, 1387442730, 1, '189.129.42.19', 4, 1387404073, NULL, NULL);
INSERT INTO `cruge_session` VALUES(293, 4, 1387574970, 1387634970, 1, '189.129.3.200', 1, 1387574970, NULL, NULL);
INSERT INTO `cruge_session` VALUES(294, 1, 1387582797, 1387642797, 1, '189.129.3.200', 2, 1387583243, NULL, NULL);
INSERT INTO `cruge_session` VALUES(295, 4, 1387640862, 1387700862, 0, '189.129.3.200', 2, 1387653390, NULL, NULL);
INSERT INTO `cruge_session` VALUES(296, 4, 1387842055, 1387902055, 1, '189.129.46.66', 1, 1387842055, NULL, NULL);
INSERT INTO `cruge_session` VALUES(297, 1, 1387902895, 1387962895, 1, '189.129.46.66', 1, 1387902895, NULL, NULL);
INSERT INTO `cruge_session` VALUES(298, 1, 1388079332, 1388139332, 1, '189.129.14.252', 1, 1388079332, NULL, NULL);
INSERT INTO `cruge_session` VALUES(299, 1, 1388183246, 1388243246, 1, '189.129.14.252', 2, 1388184687, NULL, NULL);
INSERT INTO `cruge_session` VALUES(300, 1, 1388440522, 1388500522, 1, '189.129.14.252', 1, 1388440522, NULL, NULL);
INSERT INTO `cruge_session` VALUES(301, 4, 1388761578, 1388821578, 1, '189.129.14.252', 2, 1388786127, NULL, NULL);
INSERT INTO `cruge_session` VALUES(302, 4, 1389021042, 1389081042, 1, '189.129.14.252', 1, 1389021042, NULL, NULL);
INSERT INTO `cruge_session` VALUES(303, 1, 1389116617, 1389176617, 1, '189.129.14.252', 1, 1389116617, NULL, NULL);
INSERT INTO `cruge_session` VALUES(304, 1, 1389225251, 1389285251, 1, '189.129.14.252', 1, 1389225251, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_system`
--

CREATE TABLE `cruge_system` (
  `idsystem` int(11) NOT NULL auto_increment,
  `name` varchar(45) default NULL,
  `largename` varchar(45) default NULL,
  `sessionmaxdurationmins` int(11) default '30',
  `sessionmaxsameipconnections` int(11) default '10',
  `sessionreusesessions` int(11) default '1' COMMENT '1yes 0no',
  `sessionmaxsessionsperday` int(11) default '-1',
  `sessionmaxsessionsperuser` int(11) default '-1',
  `systemnonewsessions` int(11) default '0' COMMENT '1yes 0no',
  `systemdown` int(11) default '0',
  `registerusingcaptcha` int(11) default '0',
  `registerusingterms` int(11) default '0',
  `terms` blob,
  `registerusingactivation` int(11) default '1',
  `defaultroleforregistration` varchar(64) default NULL,
  `registerusingtermslabel` varchar(100) default NULL,
  `registrationonlogin` int(11) default '1',
  PRIMARY KEY  (`idsystem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `cruge_system`
--

INSERT INTO `cruge_system` VALUES(1, 'default', NULL, 1000, 10, 1, -1, -1, 0, 0, 0, 0, '', 0, '', '', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cruge_user`
--

CREATE TABLE `cruge_user` (
  `iduser` int(11) NOT NULL auto_increment,
  `regdate` bigint(30) default NULL,
  `actdate` bigint(30) default NULL,
  `logondate` bigint(30) default NULL,
  `username` varchar(64) default NULL,
  `email` varchar(45) default NULL,
  `password` varchar(64) default NULL COMMENT 'Hashed password',
  `authkey` varchar(100) default NULL COMMENT 'llave de autentificacion',
  `state` int(11) default '0',
  `totalsessioncounter` int(11) default '0',
  `currentsessioncounter` int(11) default '0',
  PRIMARY KEY  (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `cruge_user`
--

INSERT INTO `cruge_user` VALUES(1, NULL, NULL, 1389225251, 'admin', 'nenepil@gmail.com', 'nenepil', NULL, 1, 0, 0);
INSERT INTO `cruge_user` VALUES(2, NULL, NULL, NULL, 'invitado', 'invitado', 'nopassword', NULL, 1, 0, 0);
INSERT INTO `cruge_user` VALUES(3, 1385503126, NULL, 1387316337, 'root', 'cocoaventura@gmail.com', 'root123', '6af63e9e6a49931dc2f17c719e98505a', 1, 0, 0);
INSERT INTO `cruge_user` VALUES(4, 1386007967, NULL, 1389021042, 'larissa', 'eventos.cocoaventura@gmail.com', '7c0241ee', 'd1aacbd5f156e70f637d1f816608d8a8', 1, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(100) default NULL,
  `alternative_email` varchar(500) default NULL,
  `first_name` varchar(100) character set utf8 default NULL,
  `last_name` varchar(100) character set utf8 default NULL,
  `country` varchar(50) default NULL,
  `state` varchar(50) character set utf8 default NULL,
  `city` varchar(50) character set utf8 default NULL,
  `how_find_us` tinytext,
  `home_phone` varchar(50) character set utf8 default NULL,
  `work_phone` varchar(50) character set utf8 default NULL,
  `cell_phone` varchar(50) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Volcar la base de datos para la tabla `customers`
--

INSERT INTO `customers` VALUES(7, 'roahmonic@hotmail.com', 'eventos.cocoaventura@gmail.com', 'Mónica', 'Roa Herrera', 'Mexico', 'Puebla', 'Puebla', '', '2223230558', '', '');
INSERT INTO `customers` VALUES(8, 'rh.orizaba@pathlogistic.com', '', 'Carmen Ivonne', 'Flores Guerra', 'Mexico', 'Veracruz', 'orizaba', 'Cada año hacen evento con nosotros', '01800-0104011', '(272) 721 33 00', '');
INSERT INTO `customers` VALUES(9, 'silvia.gc15@hotmail.com', '', 'Franciscaa', 'Silva Grajales', 'Mexico', 'DF', 'DF', 'Internet', '', '', '045 (555) 413-0381');
INSERT INTO `customers` VALUES(10, 'martin_vallejo01@hotmail.com', '', 'Martin', 'Vallejo Velazquez', 'Mexico', 'Favor de Proporcionar', 'Favor de proporcionar', '', 'Favor deProporcionar', 'Favor de Proporcionar', 'Favor de Proporcionar ');
INSERT INTO `customers` VALUES(11, 'frojas@urbanscience.com', '', 'Fidencio ', 'Rojas', 'Mexico', 'Cd de Mexico', 'Cd de Mexico', '', '045-555-401-8258', '', '');
INSERT INTO `customers` VALUES(12, 'eventos.cocoaventura@gmail.com', '', 'ruth elena', 'ramirez', 'mexico', '', '', '', '', '', '');
INSERT INTO `customers` VALUES(13, 'rlcaballerop@prodigy.net.mx', '', 'Ricardo ', 'Caballero', 'Mexico', 'Cd. México', 'Cd. México', 'internet', '', '', '044 554 353 2202');
INSERT INTO `customers` VALUES(14, 'viortiz@live.com.mx', '', 'Violeta Adriana', 'Ortiz Alvarado', 'Mexico', 'Toluca', 'Toluca', 'ya se ha hospedado anteriormente', '(722) 278-0086', '', '');
INSERT INTO `customers` VALUES(15, 'iafs1968@hotmail.com', '', 'Ivan ', 'Falcon', 'Mexico', 'DF', 'DF', 'x internet', 'Favor de Proporcionar', 'Favor de Proporcionar', '045-551-451-1085');
INSERT INTO `customers` VALUES(16, 'lzanella@asf.gob.mx', '', 'Lizbeth', 'Zanella Pedrera', 'Mexico', 'Cd. de Mexico', 'Cd de Mexico', 'x internet', '01-555-200-1594', '', '');
INSERT INTO `customers` VALUES(17, 'jose.angel.velazco@gmail.com', '', 'Jose Angel', 'Velazco Ornelas', 'Mexico', 'DF', 'DF', 'Ya se ha hospedado antes', '556-364-1602', '', '');
INSERT INTO `customers` VALUES(18, 'g.r.i.p.h.o@hotmail.com ', '', 'Juan ', 'Hernández', 'Mexico', 'Edo de México', 'Edo de México', 'x internet', '554 925 4705', '', '');
INSERT INTO `customers` VALUES(19, 'rlcaballerop@prodigy.net.mx', '', 'Ricardo ', 'Caballero', 'Mexico', 'Cd. México', 'Cd. México', 'internet', '', '', '044 554 353 2202');
INSERT INTO `customers` VALUES(20, 'jmd_mta@hotmail.com', '', 'Javier', 'Maldonado de Dios', 'Mexico', 'Puebla', 'Puebla', 'x internet', '(222) 615-1048', '', '');
INSERT INTO `customers` VALUES(21, 'moranmc@gmail.com', '', 'CONCEPCION', 'MORAN MARTINEZ', 'MEXICO', 'DF', 'DF', 'POR INTERNET', '555-677-6289', '', '');
INSERT INTO `customers` VALUES(25, 'cocoaventura@gmail.com', 'cocoaventura@gmail.com', 'Andrea ', 'Ramírez', '', '', '', '', '9-21-26-26', '', '');
INSERT INTO `customers` VALUES(27, 'mrossy_76@live.com.mx', '', 'Rocio', 'Lopez', 'Mexico', 'Puebla', 'puebla', 'x internet', '', '', '222-282-8692');
INSERT INTO `customers` VALUES(28, 'badjl0550@gmail.com', '', 'Jose Luis', 'Badillo', 'Mexico', 'Favor de Proporcionar', 'Favor de proporcionar', 'x internetg', '', '', 'Favor de Proporcionar ');
INSERT INTO `customers` VALUES(29, 'venus_iki@hotmail.com', '', 'Mirsha Itzel', 'Figueroa Sánchez', 'Mexico', 'Veracruz', 'Xalapa', 'Zonaturistica', '(228) 9794-145', '', '(228) 9794-145');
INSERT INTO `customers` VALUES(30, 'cmonsivaisc@yahoo.com.mx', '', 'Carmen', 'Monsivais', 'Mexico', 'Coahuila', 'Saltillo', 'Zona turistica', '(844) 1457-053', '', '(844) 1457-053');
INSERT INTO `customers` VALUES(31, 'andii_2905@hotmail.com', '', 'andrea', 'hiller', 'Mexico', 'Veracruz', 'veracruz', 'internet', '', '', '2291012857');
INSERT INTO `customers` VALUES(32, 'machisi29@hotmail.com', '', 'EDGAR', '', '', '', '', '', '', '', '');
INSERT INTO `customers` VALUES(33, 'gelos_samy@hotmail.com', '', 'Maria de los Angeles', 'Sanchez', 'Mexico', 'Puebla', 'Tepeaca', 'Zona TUristica', '(01223) 2751-988', '', '(01 223) 275 1988');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_reservations`
--

CREATE TABLE `customer_reservations` (
  `id` int(11) NOT NULL auto_increment,
  `customer_id` int(11) NOT NULL,
  `subtotal` decimal(10,2) default NULL,
  `cabana_discount` decimal(10,2) default NULL,
  `tent_discount` decimal(10,2) default NULL,
  `camped_discount` decimal(10,2) default NULL,
  `day_pass_discount` decimal(10,2) default NULL,
  `grand_total` decimal(10,2) default NULL,
  `see_discount` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Volcar la base de datos para la tabla `customer_reservations`
--

INSERT INTO `customer_reservations` VALUES(1, 9, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `customer_reservations` VALUES(3, 10, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `customer_reservations` VALUES(4, 11, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(5, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `customer_reservations` VALUES(6, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `customer_reservations` VALUES(7, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `customer_reservations` VALUES(8, 14, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(9, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `customer_reservations` VALUES(10, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `customer_reservations` VALUES(11, 17, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(14, 21, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(28, 25, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(30, 12, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(31, 27, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(32, 28, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(33, 18, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(34, 29, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(35, 30, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(36, 31, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(37, 32, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `customer_reservations` VALUES(38, 33, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `labels`
--

CREATE TABLE `labels` (
  `id` int(11) NOT NULL auto_increment,
  `label` varchar(150) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `labels`
--

INSERT INTO `labels` VALUES(1, 'Nombre');
INSERT INTO `labels` VALUES(2, 'Telefono');
INSERT INTO `labels` VALUES(3, 'Procedencia');
INSERT INTO `labels` VALUES(4, 'Email');
INSERT INTO `labels` VALUES(5, 'Estimado(a)');
INSERT INTO `labels` VALUES(6, 'Encabezado');
INSERT INTO `labels` VALUES(7, 'Opciones De Admision');
INSERT INTO `labels` VALUES(8, 'Presupuesto');
INSERT INTO `labels` VALUES(9, 'Condiciones');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `labels_format`
--

CREATE TABLE `labels_format` (
  `id` int(11) NOT NULL auto_increment,
  `budget_format_id` int(11) NOT NULL,
  `order` int(11) default NULL,
  `label_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_labels_format_budget_format1_idx` (`budget_format_id`),
  KEY `fk_labels_format_labels1_idx` (`label_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Volcar la base de datos para la tabla `labels_format`
--

INSERT INTO `labels_format` VALUES(1, 2, 1, 1);
INSERT INTO `labels_format` VALUES(2, 2, 2, 2);
INSERT INTO `labels_format` VALUES(3, 2, 3, 3);
INSERT INTO `labels_format` VALUES(4, 2, 4, 4);
INSERT INTO `labels_format` VALUES(5, 1, 1, 1);
INSERT INTO `labels_format` VALUES(8, 1, 2, 2);
INSERT INTO `labels_format` VALUES(9, 1, 3, 3);
INSERT INTO `labels_format` VALUES(10, 1, 4, 4);
INSERT INTO `labels_format` VALUES(11, 1, 5, 5);
INSERT INTO `labels_format` VALUES(12, 1, 6, 6);
INSERT INTO `labels_format` VALUES(13, 1, 7, 7);
INSERT INTO `labels_format` VALUES(14, 1, 8, 8);
INSERT INTO `labels_format` VALUES(15, 1, 9, 9);
INSERT INTO `labels_format` VALUES(20, 1, NULL, 9);
INSERT INTO `labels_format` VALUES(21, 2, NULL, 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `policies`
--

CREATE TABLE `policies` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) character set utf8 default NULL,
  `content` text character set utf8,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `policies`
--

INSERT INTO `policies` VALUES(2, 'OPCIONES DE ADMISION', '<p style="margin-left: 36pt;"><strong>OPCIONES DE ADMISION</strong></p>\r\n\r\n<hr />\r\n<p style="margin-left: 36pt; text-align: justify;">&nbsp;</p>\r\n\r\n<p style="margin-left: 36pt; text-align: justify;">1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Admisi&oacute;n por D&iacute;a (le llamamos &quot;Pasar el D&iacute;a&quot;):&nbsp;</strong>Esta opci&oacute;n cuesta&nbsp;<strong>$100.00 pesos&nbsp;</strong>por persona mayor de 1.20 mt. de estatura y&nbsp;<strong>$ 50.00 pesos&nbsp;</strong>por persona menor de 1.20 mt de estatura y le permite estar en CocoAventura de 9am a 18:00 horas. Las personas que permanezcan en CocoAventura despu&eacute;s de las 18:00 horas deber&aacute;n pagar&nbsp;<strong>$150.00 pesos&nbsp;</strong>por persona adicional que corresponde\na la &quot;tarifa nocturna&quot; y pueden salir hasta el siguiente d&iacute;a a las 13:00 horas como m&aacute;ximo.</p>\r\n\r\n<p style="margin-left: 36pt; text-align: justify;">2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Camping:&nbsp;</strong>Esta opci&oacute;n cuesta&nbsp;<strong>$ 150.00 pesos&nbsp;</strong>por persona por noche mayor de 1.20 mt de estatura y&nbsp;<strong>$ 100.00 pesos&nbsp;</strong>por persona por noche menor de 1.20 mt de estatura&nbsp;<strong>acampando en sus propias casas de campa&ntilde;a</strong> y les permite estar en CocoAventura desde las 15:00 horas del primer d&iacute;a hasta las 13:00 horas del d&iacute;a siguiente.</p>\r\n\r\n<p style="margin-left: 36pt; text-align: justify;">3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Caba&ntilde;as:&nbsp;</strong>Tenemos\ncaba&ntilde;as con Ventiladores o con Aire Acondicionado con capacidades de 1 hasta 5 personas (ver tarifas en el link anterior). El horario de entrada es desde las 15:00 horas del primer d&iacute;a hasta las 13:00 horas del d&iacute;a siguiente.</p>\r\n\r\n<p style="text-align: justify;">&nbsp;</p>\r\n\r\n<p style="text-align: justify; margin-left: 40px;">Contamos con tres zonas para acampar, una frente al mar (dentro del Club de Playa), una atr&aacute;s de la alberca (dentro del Club de Playa) y otra dentro de la selva tropical.</p>\r\n\r\n<p style="text-align: justify; margin-left: 40px;">Contamos con ba&ntilde;os separados para hombres y mujeres tanto en el Club de Playa como en la Selva Tropical. No cuentan con agua caliente.</p>\r\n\r\n<p style="text-align: justify; margin-left: 40px;">El\nClub de Playa que consta de: Sombras, Palapas, Alberca con tobog&aacute;n, mesas y sillas de playa, ba&ntilde;os, estacionamiento y Acceso peatonal al Mar.</p>\r\n');
INSERT INTO `policies` VALUES(3, 'ESPECIFICACIÓN CABAÑAS', '<p><img alt="" src="http://www.cocoaventura.com/images/cabanas.gif" style="width: 103px; height: 15px;" /></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<p style="text-align: justify;">Todas las Caba&ntilde;as se encuentran ubicadas dentro de la Selva Tropical, unidas por senderos pero separadas cierta distancia para mayor privacidad.<br />\r\n<br />\r\nEn esta zona, gracias a la Selva Tropical las caba&ntilde;as se encuentran protegidas de los vientos com&uacute;nmente llamados &quot;Nortes&quot; que en ocasiones llegan a Veracruz, pero a la vez se localizan a una distancia caminable hacia la playa (aprox 250 mts), lo que nos convierte en un lugar que se puede visitar en cualquier &eacute;poca del a&ntilde;o.&nbsp;<br />\r\n<br />\r\nLas caba&ntilde;as son amplias\ny ofrecen una confortable estancia debido a la sombra que les proveen los &aacute;rboles, sus ventanas cuentan con mosquiteros y a su vez permiten disfrutar de agradables vistas de los alrededores.<br />\r\n<br />\r\nTodas las Caba&ntilde;as cuentan con:<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Dos Camas Matrimoniales y una individual Ropa de Cama y Almohadas&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Ba&ntilde;o privado&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif"\nsrc="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Regadera con agua caliente (Electrica)<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Lavamanos con espejo&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Toallas&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Jabones y Shampoo&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif"\nsrc="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Entrepa&ntilde;os&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Mesa, sillas y bur&oacute; de cama&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Terraza&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Iluminaci&oacute;n interna y externa&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif"\nsrc="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Contactos el&eacute;ctricos (110/120v)&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Ventanas con cortinas&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Ventanas con mosquitero&nbsp;<br />\r\n<br />\r\n<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/caba%C3%B1as-de-ventilador.gif" src="http://www.cocoaventura.com/images/caba%C3%B1as-de-ventilador.gif" style="width: 281px; height: 24px;" />&nbsp;<br\n/>\r\n<br />\r\nAdicional a lo que tienen en general todas las caba&ntilde;as estas cuentan con:&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Dos Ventiladores de techo y Uno de Pared&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" />Techo de lamina de teja de fibrocemento&nbsp;<br />\r\n<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 18px;" /><a href="http://www.cocoaventura.com/caba_venti.php"\ntarget="_blank">Ver galeria de fotos</a><br />\r\n<br />\r\n<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/caba%C3%B1as-de-clima.gif" src="http://www.cocoaventura.com/images/caba%C3%B1as-de-clima.gif" style="border-width: 0px; border-style: solid; width: 187px; height: 28px;" />&nbsp;<br />\r\n<br />\r\nAdicional a lo que tienen en general todas las caba&ntilde;as estas cuentan con:&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="border-width: 0px; border-style: solid; width: 36px; height: 18px;" />Aire Acondicionado&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif"\nstyle="border-width: 0px; border-style: solid; width: 36px; height: 18px;" />Techo de Loza de concreto&nbsp;<br />\r\n<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="border-width: 0px; border-style: solid; width: 36px; height: 18px;" /><a href="http://www.cocoaventura.com/caba_clima.php" target="_blank">Ver galeria de fotos</a><br />\r\n<br />\r\n<br />\r\n<br />\r\nLas Caba&ntilde;as NO cuentan con televisi&oacute;n debido a que promovemos que su estancia en CocoAventura le sirva para salir de la rutina y estar m&aacute;s en contacto con la naturaleza. De todos modos, las caba&ntilde;as cuentan con contactos el&eacute;ctricos por lo que puede traer sus aparatos el&eacute;ctricos\nque requiera.&nbsp;<br />\r\n<br />\r\nAl hospedarse en las caba&ntilde;as podr&aacute; utilizar los asadores comunes y los comedores con estufa para elaborar sus alimentos. Por el momento no contamos con restaurante, por lo que puede traer sus propios alimentos. (Debe traer sus implementos para cocinar como son: sartenes, ollas, trastes, cubiertos, platos, etc.). No contamos con refrigerador en los comedores.&nbsp;<br />\r\n<br />\r\nLa mayor parte del tiempo contamos con una &ldquo;fondita&rdquo; que se localiza en la Palapa de la Playa, la cu&aacute;l ofrece Antojitos Veracruzanos para el desayuno y el almuerzo.<br />\r\n<br />\r\n- Tambi&eacute;n ponemos a su disposici&oacute;n una &ldquo;tiendita&rdquo; que ofrece venta de refrescos, aguas, cervezas, sabritas, cigarros, etc, que tambi&eacute;n\nse localiza en la Palapa de la Playa y que opera de 9 am a 6 pm.&nbsp;<br />\r\n<br />\r\nNotas:&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="border-width: 0px; border-style: solid; width: 36px; height: 18px;" />Horario de Entrada 3 p.m. (check-in)<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="border-width: 0px; border-style: solid; width: 36px; height: 18px;" />Horario de Salida 1 p.m. (check-out)</p>\r\n');
INSERT INTO `policies` VALUES(4, 'CAMPING', '<p><strong>CAMPING</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<p style="text-align: justify;">En&nbsp;<strong>CocoAventura</strong>&nbsp;contamos con una extensa &aacute;rea verde rodeada de cocoteros y &aacute;rboles frutales donde podr&aacute;s instalar tu casa de campa&ntilde;a junto con tus familiares &oacute; amigos y gozar de momentos inolvidables, aprovechando la seguridad y comodidad de nuestras instalaciones.&nbsp;<br />\r\n<br />\r\nDescansen bajo un cielo majestuoso, cobijados por cientos de estrellas, el viento acariciando las copas de los &aacute;rboles y arrullados por las olas del mar que se escuchan a lo lejos...&nbsp;</p>\r\n\r\n<p style="text-align: justify;">Contamos con tres zonas para acampar, una frente al mar (dentro del Club de Playa), una atr&aacute;s\nde la alberca (dentro del Club de Playa) y otra dentro de la selva tropical.</p>\r\n\r\n<p style="text-align: justify;"><br />\r\n<br />\r\nEn nuestra Zona de Acampado encontrar&aacute;s:&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Vigilancia&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Alumbrado&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height:\n16px;" />Corriente El&eacute;ctrica&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Asador&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Regaderas separadas para mujeres y hombres (no tienen agua caliente)&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Ba&ntilde;os separados para mujeres y hombres&nbsp;<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif"\nsrc="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Renta de Casas de Campa&ntilde;a&nbsp;<br />\r\n<br />\r\nEsc&aacute;pate un fin de semana, trae tu propia casa de campa&ntilde;a &oacute; renta una de las nuestras, enciende una fogata y pasa una velada maravillosa asando bombones y salchichas entre amenas charlas, historias, cantos y juegos que te har&aacute;n vivir una noche inolvidable.&nbsp;<br />\r\n<br />\r\nProveemos atenci&oacute;n especial para grupos, ven a pasar momentos llenos de emoci&oacute;n y aventura!!&nbsp;<br />\r\n<br />\r\nPonte en contacto con nosotros y te ayudaremos a organizar un paquete de actividades de acuerdo a tus necesidades para que vengas con todos tus amigos.</p>\r\n\r\n<p><img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif"\nsrc="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 18px;" />Horario de Entrada 3 p.m. (check-in)<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 18px;" />Horario de Salida 1 p.m. (check-out)</p>\r\n');
INSERT INTO `policies` VALUES(5, 'CAMPING  SAFARI', '<p><strong>CAMPING &nbsp;SAFARI</strong></p>\r\n\r\n<hr />\r\n<p style="text-align: justify;">&nbsp;</p>\r\n\r\n<p style="text-align: justify;">El Hospedaje Safari son casas de campa&ntilde;a bastante amplias (4.27 mts de largo x 3.65 mts de ancho, con una altura central de 2.19 mts) que se arman con una cama matrimonial, ropa de cama y dos almohadas.<br />\r\n<br />\r\nContamos con tres zonas para acampar, una frente al mar (dentro del Club de Playa), una atr&aacute;s de la alberca (dentro del Club de Playa) y otra dentro de la selva tropical.</p>\r\n\r\n<p style="text-align: justify;"><br />\r\nEl Hospedaje Safari no cuenta con electricidad, por lo tanto dentro de las Casas Safari no hay ventiladores, luz, ni contactos el&eacute;ctricos. Pero tienen ventanas grandes\ncon mosquiteros lo que las hace que tengan buena ventilaci&oacute;n. De todos modos le recomendamos traer l&aacute;mpara de mano, zarape en temporadas de invierno, repelente de insectos, chanclas, toallas, shampoo, jabon, bloqueador solar, etc.<br />\r\n<br />\r\nLas Safari est&aacute;n dise&ntilde;adas para que duerman dos personas en la cama matrimonial, sin embargo pueden entrar personas adicionales. Favor de revisar los costos. Le recomendamos si vienen personas adicionales traerles un colch&oacute;n inflable &oacute; colchoneta.<br />\r\n<br />\r\nSe requiere de un dep&oacute;sito por cada Casa Safari rentada, reembolsable al devolverla en buenas condiciones como se recibi&oacute;.</p>\r\n\r\n<p><img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif"\nstyle="width: 36px; height: 18px;" />Horario de Entrada 3 p.m. (check-in)<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet.gif" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 18px;" />Horario de Salida 1 p.m. (check-out)</p>\r\n');
INSERT INTO `policies` VALUES(6, 'EVENTOS', '<p><strong>EVENTOS</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<p>Las instalaciones se rentan para eventos especiales tales como:</p>\r\n\r\n<p><img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Cumplea&ntilde;os<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Bautizos<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Comuniones<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Bodas<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;"\n/>Fiestas Infantiles &oacute; de Universidades<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Eventos Familiares<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Promoci&oacute;n<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Excursiones<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Reuniones de Negocios<br />\r\n<img alt="" src="http://www.cocoaventura.com/images/menu_bullet_small.gif" style="width: 36px; height: 16px;" />Festivales<br />\r\n&nbsp;</p>\r\n\r\n<p>Contamos con 2 &aacute;reas verdes d&oacute;nde\nse pueden colocar carpas.</p>\r\n\r\n<p>Miden:</p>\r\n\r\n<p>Tambi&eacute;n dos palapas una con capacidad para:</p>\r\n\r\n<p>Palapa Fondita:</p>\r\n\r\n<p>Palapa Gemela:</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `policies` VALUES(7, 'CLUB DE PLAYA', '<p><img alt="" src="http://www.cocoaventura.com/images/club_de_playa.gif" style="width: 201px; height: 13px;" /></p>\r\n\r\n<hr />\r\n<p style="text-align: justify;">&nbsp;</p>\r\n\r\n<p style="text-align: justify;">El Club de Playa de CocoAventura es un espacio muy amplio con una hermosa vista del mar, del pueblo de Ant&oacute;n Lizardo y de Boca del R&iacute;o y Veracruz. Cuenta con una Palapa grande, una fondita que en temporadas ofrece ricos antojitos veracruzanos, Alberca con Muro de Escalar acu&aacute;tico y Tobog&aacute;n, Juegos para ni&ntilde;os, Camas Cubo, Camastros, Sombras, Sillas y Mesas, Estacionamiento, Ba&ntilde;os, Regaderas y un extenso Jard&iacute;n para Eventos...</p>\r\n\r\n<p style="text-align: justify;"><br />\r\n<br />\r\nLas mascotas son bienvenidas\ntanto en las caba&ntilde;as como en el Club de Playa, deber&aacute;n portar correa y NO est&aacute; permitido que se metan a la alberca, pero al Mar s&iacute; =).<br />\r\n<br />\r\nLa amplia Playa ofrece un Mar muy tranquilo, poco profundo y de agua limpia. Usted, sus hijos y mascotas pueden disfrutarlo siempre que las condiciones climatol&oacute;gicas lo permitan.<br />\r\n<br />\r\nEl Club de Playa est&aacute; abierto al P&uacute;blico todos los d&iacute;as de 9:00 am a 6:30 pm (no necesita estar hospedado en CocoAventura para accesar pero si debe cubrir el costo de&nbsp;<a href="http://www.cocoaventura.com/tarifas_hospedaje.php" target="_blank">admisi&oacute;n para pasar el d&iacute;a</a>).&nbsp;<br />\r\n<br />\r\nLas Camas Cubo se rentan en $50 pesos por Cama por el turno del d&iacute;a.\nSi usted est&aacute; hospedado en Caba&ntilde;a la Cama Cubo se le otorga gratis. Pida su cama Cubo al encargado del Club de Playa. Todas las Cama Cubo se recogen y se guardan a las 6:00 pm. Las Camas Cubo estan sujetas a disponibilidad ya que solo contamos con 4.&nbsp;<br />\r\n<br />\r\nRecuerde que todas las Actividades de Aventura requieren reservarse con 24 hrs de anticipaci&oacute;n.&nbsp;</p>\r\n');
INSERT INTO `policies` VALUES(8, 'MASCOTAS', '<p><strong>MASCOTAS</strong></p>\r\n\r\n<hr />\r\n<p style="text-align: justify;">&nbsp;</p>\r\n\r\n<p style="text-align: justify;">Porque tus Mascotas forman parte de t&uacute; Familia las recibimos con mucho gusto en CocoAventura. (P.A.W. Pets Are Welcome)<br />\r\n<br />\r\nLas mascotas son bienvenidas y su ingreso a CocoAventura no tiene costo. Puede traerlas tanto a pasar el d&iacute;a como a que se hospeden con usted en las Caba&ntilde;as. Si las mascotas son peque&ntilde;as pueden quedarse dentro de la Caba&ntilde;a con su due&ntilde;o, si las mascotas son muy grandes contamos con algunos corralitos (3) para que duerman ah&iacute;.<br />\r\n<br />\r\nVigile su mascota ya que si esta mancha, rompe &oacute; muerde parte del mobiliario se le har&aacute; el cargo correspondiente\npara reemplazarlo.&nbsp;</p>\r\n\r\n<p style="text-align: justify;"><br />\r\n<br />\r\n<strong>Recomendaciones cuando nos visite con su mascota:</strong>&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Lleve a su mascota al veterinario y cerci&oacute;rese que cuenta con buena salud para viajar.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />No alimente a su mascota antes de emprender el viaje, ya que el movimiento puede causarle v&oacute;mitos.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción:\nhttp://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Recuerde portar con usted los registros de vacunaci&oacute;n de su mascota, as&iacute; como cualquier otro documento&nbsp;como n&uacute;mero de licencia, tatuaje, microchip, etc, as&iacute; como una foto reciente de su mascota por si esta se&nbsp;llegara a extraviar en alguna parte de su viaje.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Durante su estancia en CocoAventura su mascota deber&aacute; traer collar y correa todo el tiempo &oacute; si es muy&nbsp;obediente puede soltarla pero\ntenerla bajo vigilancia.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />No nos hacemos responsables por peleas, mordeduras entre mascotas &oacute; hacia los humanos, extrav&iacute;os,&nbsp;infecciones, picaduras de bichos, etc. Favor de cuidar a sus mascotas.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />No permita que su mascota haga m&aacute;s ejercicio del que est&aacute; acostumbrada, tome en cuenta que el exceso de&nbsp;sol, calor y humedad del ambiente le pueden afectar.&nbsp;<br />\r\n<br\n/>\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Tenga cuidado donde pasea a su mascota, no deje que ande sola olfateando &oacute; rascando debajo de ramas,&nbsp;piedras, hoyos, etc, recuerde que se encuentra en una selva tropical pueden salir bichos, alacranes u otros&nbsp;animales.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Recomendamos que porten collar anti-pulgas / garrapatas.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif"\nstyle="width: 36px; height: 16px;" />Est&aacute; prohibido permitir que su mascota se introduzca a la Alberca as&iacute; como que tome agua de la misma. Porfavor respete a los dem&aacute;s hu&eacute;spedes.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Traer su recipiente para Agua y Comida.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Traer la comida que su mascota est&aacute; acostumbrada comer para prevenir malestares estomacales, no le&nbsp;alimente cosas nuevas durante sus viajes.&nbsp;<br\n/>\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Traer Cama &oacute; alfombrita para dormir.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Traer pelota o juguete de playa.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Traer bolsitas para recoger los desechos de su mascota (si su mascota se hace&hellip; usted no se haga...)&nbsp;Deposite los desechos\nde su mascota en los botes de basura.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Traer utensilios de belleza: shampoo, jab&oacute;n, peine, cepillo y lo necesario para mantenerlas limpias (considere que su&nbsp;mascota correr&aacute; en la playa, se meter&aacute; al mar, se revolcar&aacute; en la arena, etc, es decir se desestrezar&aacute;).&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Traer toalla especial para su mascota, POR FAVOR no utilice las toallas de los hu&eacute;spedes de\nCocoAventura.&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Si su mascota ocupa ciertos medicamentos no los olvide en su casa (botiqu&iacute;n).&nbsp;<br />\r\n<br />\r\n<img alt="Descripción: http://www.cocoaventura.com/images/menu_bullet_small.gif" src="http://www.cocoaventura.com/images/menu_bullet.gif" style="width: 36px; height: 16px;" />Si usted planea salir durante el d&iacute;a y dejar a su mascota en CocoAventura lo puede hacer, de preferencia en alguno&nbsp;&nbsp;de nuestros corralitos, ya que si la deja dentro de la Caba&ntilde;a es probable que la persona del aseo no pueda&nbsp;accesar a limpiarla.</p>\r\n');
INSERT INTO `policies` VALUES(9, 'CONDICIONES HOSPEDAJE EN CABAÑA', '<p><strong>CONDICIONES HOSPEDAJE EN CABA&Ntilde;A</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li style="text-align: justify;"><u>Para reservar se requiere depositar m&iacute;nimo el 50% de su Total.</u></li>\r\n	<li style="text-align: justify;"><strong>El hospedaje en caba&ntilde;as con actividades no incluye actividades para los ni&ntilde;os con alojamiento gratis.</strong></li>\r\n	<li style="text-align: justify;">Aceptamos 2 Mascotas Gratis, pero est&aacute; prohibido que entren a la alberca y secarlos con las toallas del hotel. Mascota Adicional $ 100.00 x mascota x noche.</li>\r\n	<li style="text-align: justify;">Horario de Caba&ntilde;as y Camping: Check-in: 15:00 hrs y Check-out: 13:00 hrs.</li>\r\n	<li style="text-align: justify;">En\nla zona de Caba&ntilde;as tenemos un comedor comunitario, equipado con tarja, estufa de gas, hielera y asador para que preparen sus alimentos; deber&aacute;n traer sus implementos de cocina: platos, sartenes, carb&oacute;n, cubiertos, hielo. etc.</li>\r\n</ul>\r\n');
INSERT INTO `policies` VALUES(10, 'CONDICIONES CLUB DE PLAYA', '<p><strong>CONDICIONES CLUB DE PLAYA ( EVENTOS, PASAR EL D&Iacute;A, HOSPEDAJE)</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li style="text-align: justify;">El Club de Playa se comparte con los dem&aacute;s hu&eacute;spedes de CocoAventura.</li>\r\n	<li style="text-align: justify;">Se permite introducir alimentos y bebidas a nuestras instalaciones.</li>\r\n	<li style="text-align: justify;">Queda estrictamente prohibido utilizar vasos, botellas y objetos de cristal cerca de la alberca.</li>\r\n	<li style="text-align: justify;">El uso de TODAS las instalaciones es bajo su propia responsabilidad, la administraci&oacute;n no es responsable de accidentes o lesiones. El hotel no cuenta con salvavidas.</li>\r\n	<li style="text-align:\njustify;">Los menores de edad deber&aacute;n ser supervisados por un adulto responsable todo el tiempo.</li>\r\n	<li style="text-align: justify;"><strong>Se permite traer equipo de sonido a su evento, pero deber&aacute; estar a un volumen moderado. A partir de la 1:00 de la ma&ntilde;ana comienza el horario de silencio para permitir que los dem&aacute;s hu&eacute;spedes o acampantes puedan dormir.</strong></li>\r\n	<li style="text-align: justify;">Indispensable usar traje de ba&ntilde;o para entrar a la alberca. Las bermudas NO son traje de ba&ntilde;o. No se permite usar playeras dentro de la alberca.</li>\r\n	<li style="text-align: justify;"><strong>El horario de la alberca es de 10 am a 6:00 pm.</strong></li>\r\n	<li style="text-align: justify;"><strong>El horario del Club de Playa es de\n9 am a 6:30 pm.</strong></li>\r\n	<li style="text-align: justify;">El tobog&aacute;n prende autom&aacute;ticamente en el siguiente horario\r\n	<ul>\r\n		<li>De 10:30 a 12:00</li>\r\n		<li>De 13:30 a 15:00</li>\r\n		<li>De 16:30 a 18:00</li>\r\n		<li>El resto del tiempo el tobog&aacute;n permanece apagado</li>\r\n	</ul>\r\n	</li>\r\n	<li style="text-align: justify;">No contamos con restaurante, pero la mayor parte del tiempo contamos con una &quot;fondita&quot; que se localiza en la palapa de la playa, la cual ofrece antojitos veracruzanos para el desayuno y el almuerzo. S&oacute;lo abre en temporadas.</li>\r\n	<li style="text-align: justify;">Hay una &quot;tiendita&quot; que ofrece venta de refrescos, aguas, cervezas, sabritas, cigarros, etc., que tambi&eacute;n se localiza en la palapa de\nla playa y que opera de 9 am a 6 pm. <strong>S&oacute;lo abre en temporadas</strong>.</li>\r\n	<li style="text-align: justify;">CocoAventura est&aacute; situado en el km. 11.9 de la carretera Boca del Rio - Ant&oacute;n Lizardo a escasos 10 minutos del Centro de Boca del Rio y a 5 minutos del pueblo de Ant&oacute;n Lizardo (en auto propio), donde encontrara diversos restaurantes de comida y mariscos y tiendas de autoservicio.</li>\r\n</ul>\r\n');
INSERT INTO `policies` VALUES(11, 'CONDICIONES BRAZALETES', '<p><strong>CONDICIONES BRAZALETES</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li style="text-align: justify;">A su llegada se le colocar&aacute; un brazalete. Es requisito que el TOTAL de las personas integrantes de su grupo porten sus brazaletes durante TODA su estancia dentro de las instalaciones.</li>\r\n	<li style="text-align: justify;">Las personas que pierdan, se quiten o rompan su brazalete se les cobrar&aacute; de nuevo su acceso y se les colocar&aacute; un nuevo brazalete.</li>\r\n	<li style="text-align: justify;">Esta estrictamente prohibido que est&eacute;n personas sin brazaletes en CocoAventura.</li>\r\n</ul>\r\n');
INSERT INTO `policies` VALUES(12, 'CONDICIONES ACTIVIDADES', '<p><strong>CONDICIONES ACTIVIDADES</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<p style="text-align: justify;">* Las actividades deben ser reservados con 2 d&iacute;as de anticipaci&oacute;n y se imparten a grupos de 6 personas m&iacute;nimo.</p>\r\n\r\n<p style="text-align: justify;">* La duraci&oacute;n de las actividades puede variar seg&uacute;n el tama&ntilde;o de los grupos, las edades de los participantes y la facilidad y rapidez con la que las realicen.</p>\r\n\r\n<p style="text-align: justify;">* El horario de las actividades dentro de CocoAventura es de 10:00 a 13:00 hrs &oacute; de 15:00 a 17:00 hrs.</p>\r\n\r\n<p style="text-align: justify;">* Se debe cubrir tambi&eacute;n la cuota de admisi&oacute;n al parque &oacute; estar hospedado en CocoAventura.</p>\r\n');
INSERT INTO `policies` VALUES(13, 'CONDICIONES ALIMENTOS', '<p><strong>CONDICIONES ALIMENTOS</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<p>Precios sujetos a cambio sin previo aviso.</p>\r\n\r\n<p>Men&uacute;s sujetos a cambio sin previo aviso.</p>\r\n\r\n<p>Se reserva el men&uacute; con el 50% UNA semana antes del evento.</p>\r\n\r\n<p>Se finiquita el 50% restante TRES d&iacute;as antes del evento.</p>\r\n\r\n<p>Se requiere firmar de aceptaci&oacute;n la cantidad de personas, el men&uacute; y los horarios en los que &nbsp;se servir&aacute;.</p>\r\n\r\n<p>Si requiere cambios en el men&uacute; es con 48 hrs antes del evento.</p>\r\n\r\n<p>No hay devoluciones si son menos integrantes del grupo que los firmados.</p>\r\n\r\n<p>Platillos adicionales est&aacute;n sujetos a disponibilidad.</p>\r\n');
INSERT INTO `policies` VALUES(14, 'CONDICIONES CANCELACIONES', '<p><strong>CONDICIONES CANCELACIONES</strong></p>\r\n\r\n<hr />\r\n<p style="text-align: justify;"><br />\r\n<br />\r\nLas reservaciones canceladas con 6 &oacute; m&aacute;s d&iacute;as antes de la fecha de llegada se reembolsan &iacute;ntegramente.&nbsp;<br />\r\n<br />\r\nLas reservaciones canceladas de 5 a 2 d&iacute;as antes de la fecha de llegada est&aacute;n sujetas a un cargo del 20%&nbsp;&nbsp;del total de la reservaci&oacute;n.&nbsp;<br />\r\n<br />\r\nLas reservaciones canceladas 1 d&iacute;a antes de la fecha l&iacute;mite de llegada est&aacute;n sujeta a un cargo del 50% del&nbsp;total de la reservaci&oacute;n.&nbsp;<br />\r\n<br />\r\nEn caso de No Arribo (no show) y/o las reservaciones canceladas con menos de 24 hrs de anticipaci&oacute;n se&nbsp;&nbsp;pierde\nel dep&oacute;sito y la reservaci&oacute;n.&nbsp;<br />\r\n<br />\r\nDurante puentes, asuetos, vacaciones y eventos especiales se pueden aplicar excepciones &uacute; otras pol&iacute;ticas.</p>\r\n');
INSERT INTO `policies` VALUES(15, 'LINKS', '<p><strong>LINKS</strong></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n\r\n<p>Para conocer nuestra ubicaci&oacute;n visitar:&nbsp; <a href="http://www.cocoaventura.com/localizacion.php" target="_blank">http://www.cocoaventura.com/localizacion.php</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Informaci&oacute;n sobre las Mascotas <a href="http://www.cocoaventura.com/mascotas.php" target="_blank">http://www.cocoaventura.com/mascotas.php</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style="text-align: justify;">Contamos con diversas actividades de Aventura, Ecoturismo, Recreativas, Talleres y Deportes, favor de visitar nuestra p&aacute;gina web en la secci&oacute;n de &quot;Actividades&quot;. Las actividades requieren ser reservadas con 24 hrs de anticipaci&oacute;n.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Informaci&oacute;n\nsobre paquetes con Actividades: <a href="http://www.cocoaventura.com/Paquetes.php" target="_blank">http://www.cocoaventura.com/Paquetes.php</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Informaci&oacute;n de nuestras pol&iacute;ticas: <a href="http://www.cocoaventura.com/politicas_menu.php" target="_blank">http://www.cocoaventura.com/politicas_menu.php</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Para ver cuando es Temporada ALTA O BAJA: <a href="http://www.cocoaventura.com/temporadas.php" target="_blank">http://www.cocoaventura.com/temporadas.php</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Para visitar nuestra galer&iacute;a de fotos: <a href="http://picasaweb.google.com/cocoaventura" target="_blank">http://picasaweb.google.com/cocoaventura</a></p>\r\n');
INSERT INTO `policies` VALUES(16, 'COTIZACION ENCABEZADO', '<p>Gracias por su inter&eacute;s en visitarnos el d&iacute;a:&nbsp;<strong>s&aacute;bado 7 de diciembre de 2013.&nbsp;</strong>TEMPORADA&nbsp;<strong>BAJA</strong></p>\r\n\r\n<p>Favor de visitar nuestra p&aacute;gina:&nbsp;<a href="http://www.cocoaventura.com/">www.cocoaventura.com</a></p>\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prices`
--

CREATE TABLE `prices` (
  `id` int(11) NOT NULL auto_increment,
  `rate_id` int(11) NOT NULL,
  `pax` int(11) default NULL,
  `price` decimal(10,2) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_prices_rates1_idx` (`rate_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=296 ;

--
-- Volcar la base de datos para la tabla `prices`
--

INSERT INTO `prices` VALUES(1, 89, 2, 850.00);
INSERT INTO `prices` VALUES(2, 89, 3, 1000.00);
INSERT INTO `prices` VALUES(3, 89, 4, 1150.00);
INSERT INTO `prices` VALUES(4, 89, 5, 1300.00);
INSERT INTO `prices` VALUES(5, 90, 2, 700.00);
INSERT INTO `prices` VALUES(6, 90, 3, 800.00);
INSERT INTO `prices` VALUES(7, 90, 4, 900.00);
INSERT INTO `prices` VALUES(8, 90, 5, 1000.00);
INSERT INTO `prices` VALUES(9, 91, 2, 850.00);
INSERT INTO `prices` VALUES(10, 91, 3, 1000.00);
INSERT INTO `prices` VALUES(11, 91, 4, 1150.00);
INSERT INTO `prices` VALUES(12, 91, 5, 1300.00);
INSERT INTO `prices` VALUES(13, 92, 2, 700.00);
INSERT INTO `prices` VALUES(14, 92, 3, 800.00);
INSERT INTO `prices` VALUES(15, 92, 4, 900.00);
INSERT INTO `prices` VALUES(16, 92, 5, 1000.00);
INSERT INTO `prices` VALUES(17, 93, 2, 850.00);
INSERT INTO `prices` VALUES(18, 93, 3, 1000.00);
INSERT INTO `prices` VALUES(19, 93, 4, 1150.00);
INSERT INTO `prices` VALUES(20, 93, 5, 1300.00);
INSERT INTO `prices` VALUES(21, 94, 2, 700.00);
INSERT INTO `prices` VALUES(22, 94, 3, 800.00);
INSERT INTO `prices` VALUES(23, 94, 4, 900.00);
INSERT INTO `prices` VALUES(24, 94, 5, 1000.00);
INSERT INTO `prices` VALUES(25, 95, 2, 850.00);
INSERT INTO `prices` VALUES(26, 95, 3, 1000.00);
INSERT INTO `prices` VALUES(27, 95, 4, 1150.00);
INSERT INTO `prices` VALUES(28, 95, 5, 1300.00);
INSERT INTO `prices` VALUES(29, 96, 2, 700.00);
INSERT INTO `prices` VALUES(30, 96, 3, 800.00);
INSERT INTO `prices` VALUES(31, 96, 4, 900.00);
INSERT INTO `prices` VALUES(32, 96, 5, 1000.00);
INSERT INTO `prices` VALUES(34, 98, 2, 850.00);
INSERT INTO `prices` VALUES(35, 98, 3, 1000.00);
INSERT INTO `prices` VALUES(36, 98, 4, 1150.00);
INSERT INTO `prices` VALUES(37, 98, 5, 1300.00);
INSERT INTO `prices` VALUES(41, 100, 2, 700.00);
INSERT INTO `prices` VALUES(42, 100, 3, 800.00);
INSERT INTO `prices` VALUES(43, 100, 4, 900.00);
INSERT INTO `prices` VALUES(44, 100, 5, 1000.00);
INSERT INTO `prices` VALUES(45, 101, 2, 1200.00);
INSERT INTO `prices` VALUES(46, 101, 3, 1350.00);
INSERT INTO `prices` VALUES(47, 101, 4, 1500.00);
INSERT INTO `prices` VALUES(48, 101, 5, 1650.00);
INSERT INTO `prices` VALUES(49, 102, 2, 1000.00);
INSERT INTO `prices` VALUES(50, 102, 3, 1100.00);
INSERT INTO `prices` VALUES(51, 102, 4, 1200.00);
INSERT INTO `prices` VALUES(52, 102, 5, 1300.00);
INSERT INTO `prices` VALUES(53, 103, 2, 1200.00);
INSERT INTO `prices` VALUES(54, 103, 3, 1350.00);
INSERT INTO `prices` VALUES(55, 103, 4, 1500.00);
INSERT INTO `prices` VALUES(56, 103, 5, 1650.00);
INSERT INTO `prices` VALUES(57, 104, 2, 1000.00);
INSERT INTO `prices` VALUES(58, 104, 3, 1100.00);
INSERT INTO `prices` VALUES(59, 104, 4, 1200.00);
INSERT INTO `prices` VALUES(60, 104, 5, 1300.00);
INSERT INTO `prices` VALUES(61, 105, 2, 1200.00);
INSERT INTO `prices` VALUES(62, 105, 3, 1350.00);
INSERT INTO `prices` VALUES(63, 105, 4, 1500.00);
INSERT INTO `prices` VALUES(64, 105, 5, 1650.00);
INSERT INTO `prices` VALUES(65, 106, 2, 1000.00);
INSERT INTO `prices` VALUES(66, 106, 3, 1100.00);
INSERT INTO `prices` VALUES(67, 106, 4, 1200.00);
INSERT INTO `prices` VALUES(68, 106, 5, 1300.00);
INSERT INTO `prices` VALUES(69, 107, 2, 1200.00);
INSERT INTO `prices` VALUES(70, 107, 3, 1350.00);
INSERT INTO `prices` VALUES(71, 107, 4, 1500.00);
INSERT INTO `prices` VALUES(72, 107, 5, 1650.00);
INSERT INTO `prices` VALUES(73, 108, 2, 1000.00);
INSERT INTO `prices` VALUES(74, 108, 3, 1100.00);
INSERT INTO `prices` VALUES(75, 108, 4, 1200.00);
INSERT INTO `prices` VALUES(76, 108, 5, 1300.00);
INSERT INTO `prices` VALUES(77, 109, 2, 1200.00);
INSERT INTO `prices` VALUES(78, 109, 3, 1350.00);
INSERT INTO `prices` VALUES(79, 109, 4, 1500.00);
INSERT INTO `prices` VALUES(80, 109, 5, 1650.00);
INSERT INTO `prices` VALUES(81, 110, 2, 1000.00);
INSERT INTO `prices` VALUES(82, 110, 3, 1100.00);
INSERT INTO `prices` VALUES(83, 110, 4, 1200.00);
INSERT INTO `prices` VALUES(84, 110, 5, 1300.00);
INSERT INTO `prices` VALUES(85, 111, 2, 1200.00);
INSERT INTO `prices` VALUES(86, 111, 3, 1350.00);
INSERT INTO `prices` VALUES(87, 111, 4, 1500.00);
INSERT INTO `prices` VALUES(88, 111, 5, 1650.00);
INSERT INTO `prices` VALUES(89, 112, 2, 1000.00);
INSERT INTO `prices` VALUES(90, 112, 3, 1100.00);
INSERT INTO `prices` VALUES(91, 112, 4, 1200.00);
INSERT INTO `prices` VALUES(92, 112, 5, 1300.00);
INSERT INTO `prices` VALUES(93, 113, 2, 1200.00);
INSERT INTO `prices` VALUES(94, 113, 3, 1350.00);
INSERT INTO `prices` VALUES(95, 113, 4, 1500.00);
INSERT INTO `prices` VALUES(96, 113, 5, 1650.00);
INSERT INTO `prices` VALUES(97, 114, 2, 1000.00);
INSERT INTO `prices` VALUES(98, 114, 3, 1100.00);
INSERT INTO `prices` VALUES(99, 114, 4, 1200.00);
INSERT INTO `prices` VALUES(100, 114, 5, 1300.00);
INSERT INTO `prices` VALUES(101, 115, 2, 1200.00);
INSERT INTO `prices` VALUES(102, 115, 3, 1350.00);
INSERT INTO `prices` VALUES(103, 115, 4, 1500.00);
INSERT INTO `prices` VALUES(104, 115, 5, 1650.00);
INSERT INTO `prices` VALUES(105, 116, 2, 1000.00);
INSERT INTO `prices` VALUES(106, 116, 3, 1100.00);
INSERT INTO `prices` VALUES(107, 116, 4, 1200.00);
INSERT INTO `prices` VALUES(108, 116, 5, 1300.00);
INSERT INTO `prices` VALUES(109, 117, 2, 1200.00);
INSERT INTO `prices` VALUES(110, 117, 3, 1350.00);
INSERT INTO `prices` VALUES(111, 117, 4, 1500.00);
INSERT INTO `prices` VALUES(112, 117, 5, 1650.00);
INSERT INTO `prices` VALUES(113, 118, 2, 1000.00);
INSERT INTO `prices` VALUES(114, 118, 3, 1100.00);
INSERT INTO `prices` VALUES(115, 118, 4, 1200.00);
INSERT INTO `prices` VALUES(116, 118, 5, 1300.00);
INSERT INTO `prices` VALUES(117, 119, 2, 1200.00);
INSERT INTO `prices` VALUES(118, 119, 3, 1350.00);
INSERT INTO `prices` VALUES(119, 119, 4, 1500.00);
INSERT INTO `prices` VALUES(120, 119, 5, 1650.00);
INSERT INTO `prices` VALUES(121, 120, 2, 1000.00);
INSERT INTO `prices` VALUES(122, 120, 3, 1100.00);
INSERT INTO `prices` VALUES(123, 120, 4, 1200.00);
INSERT INTO `prices` VALUES(124, 120, 5, 1300.00);
INSERT INTO `prices` VALUES(125, 122, 1, 200.00);
INSERT INTO `prices` VALUES(126, 123, 1, 200.00);
INSERT INTO `prices` VALUES(127, 123, 2, 400.00);
INSERT INTO `prices` VALUES(128, 123, 3, 600.00);
INSERT INTO `prices` VALUES(129, 123, 4, 800.00);
INSERT INTO `prices` VALUES(130, 124, 1, 200.00);
INSERT INTO `prices` VALUES(131, 124, 2, 400.00);
INSERT INTO `prices` VALUES(132, 124, 3, 600.00);
INSERT INTO `prices` VALUES(133, 121, 1, 200.00);
INSERT INTO `prices` VALUES(134, 121, 2, 400.00);
INSERT INTO `prices` VALUES(135, 121, 3, 600.00);
INSERT INTO `prices` VALUES(136, 121, 4, 800.00);
INSERT INTO `prices` VALUES(137, 121, 5, 1000.00);
INSERT INTO `prices` VALUES(138, 121, 6, 1200.00);
INSERT INTO `prices` VALUES(139, 121, 7, 1400.00);
INSERT INTO `prices` VALUES(140, 122, 2, 400.00);
INSERT INTO `prices` VALUES(141, 122, 3, 600.00);
INSERT INTO `prices` VALUES(142, 122, 4, 800.00);
INSERT INTO `prices` VALUES(143, 122, 5, 1000.00);
INSERT INTO `prices` VALUES(144, 122, 6, 1200.00);
INSERT INTO `prices` VALUES(145, 122, 7, 1400.00);
INSERT INTO `prices` VALUES(146, 124, 4, 800.00);
INSERT INTO `prices` VALUES(147, 125, 1, 200.00);
INSERT INTO `prices` VALUES(148, 125, 2, 400.00);
INSERT INTO `prices` VALUES(149, 125, 3, 600.00);
INSERT INTO `prices` VALUES(150, 125, 4, 800.00);
INSERT INTO `prices` VALUES(151, 126, 1, 200.00);
INSERT INTO `prices` VALUES(152, 126, 2, 400.00);
INSERT INTO `prices` VALUES(153, 126, 3, 600.00);
INSERT INTO `prices` VALUES(154, 126, 4, 800.00);
INSERT INTO `prices` VALUES(155, 127, 1, 200.00);
INSERT INTO `prices` VALUES(156, 127, 2, 400.00);
INSERT INTO `prices` VALUES(157, 127, 3, 600.00);
INSERT INTO `prices` VALUES(158, 127, 4, 800.00);
INSERT INTO `prices` VALUES(159, 128, 1, 150.00);
INSERT INTO `prices` VALUES(160, 128, 2, 300.00);
INSERT INTO `prices` VALUES(161, 128, 3, 450.00);
INSERT INTO `prices` VALUES(162, 128, 4, 600.00);
INSERT INTO `prices` VALUES(163, 130, 1, 500.00);
INSERT INTO `prices` VALUES(164, 130, 2, 500.00);
INSERT INTO `prices` VALUES(165, 130, 3, 680.00);
INSERT INTO `prices` VALUES(166, 131, 1, 400.00);
INSERT INTO `prices` VALUES(167, 131, 2, 400.00);
INSERT INTO `prices` VALUES(168, 131, 3, 550.00);
INSERT INTO `prices` VALUES(169, 132, 1, 500.00);
INSERT INTO `prices` VALUES(170, 132, 2, 500.00);
INSERT INTO `prices` VALUES(171, 132, 3, 680.00);
INSERT INTO `prices` VALUES(172, 133, 1, 400.00);
INSERT INTO `prices` VALUES(173, 133, 2, 400.00);
INSERT INTO `prices` VALUES(174, 133, 3, 550.00);
INSERT INTO `prices` VALUES(175, 89, 6, 1500.00);
INSERT INTO `prices` VALUES(176, 89, 7, 1700.00);
INSERT INTO `prices` VALUES(177, 89, 8, 1900.00);
INSERT INTO `prices` VALUES(178, 90, 6, 1150.00);
INSERT INTO `prices` VALUES(179, 90, 7, 1300.00);
INSERT INTO `prices` VALUES(180, 90, 8, 1450.00);
INSERT INTO `prices` VALUES(181, 89, 1, 850.00);
INSERT INTO `prices` VALUES(182, 90, 1, 700.00);
INSERT INTO `prices` VALUES(184, 91, 1, 850.00);
INSERT INTO `prices` VALUES(185, 91, 6, 1500.00);
INSERT INTO `prices` VALUES(186, 91, 7, 1700.00);
INSERT INTO `prices` VALUES(187, 91, 8, 1900.00);
INSERT INTO `prices` VALUES(188, 92, 6, 1150.00);
INSERT INTO `prices` VALUES(189, 92, 7, 1300.00);
INSERT INTO `prices` VALUES(190, 92, 8, 1450.00);
INSERT INTO `prices` VALUES(191, 92, 1, 700.00);
INSERT INTO `prices` VALUES(192, 93, 6, 1500.00);
INSERT INTO `prices` VALUES(193, 93, 7, 1700.00);
INSERT INTO `prices` VALUES(194, 93, 8, 1900.00);
INSERT INTO `prices` VALUES(195, 93, 1, 850.00);
INSERT INTO `prices` VALUES(196, 94, 6, 1150.00);
INSERT INTO `prices` VALUES(197, 94, 7, 1300.00);
INSERT INTO `prices` VALUES(198, 94, 8, 1450.00);
INSERT INTO `prices` VALUES(199, 94, 1, 700.00);
INSERT INTO `prices` VALUES(200, 95, 6, 1500.00);
INSERT INTO `prices` VALUES(201, 95, 7, 1700.00);
INSERT INTO `prices` VALUES(202, 95, 8, 1900.00);
INSERT INTO `prices` VALUES(203, 95, 1, 850.00);
INSERT INTO `prices` VALUES(204, 96, 6, 1150.00);
INSERT INTO `prices` VALUES(205, 96, 7, 1300.00);
INSERT INTO `prices` VALUES(206, 96, 8, 1450.00);
INSERT INTO `prices` VALUES(207, 96, 1, 700.00);
INSERT INTO `prices` VALUES(208, 98, 6, 1500.00);
INSERT INTO `prices` VALUES(209, 98, 7, 1700.00);
INSERT INTO `prices` VALUES(210, 98, 8, 1900.00);
INSERT INTO `prices` VALUES(211, 98, 1, 850.00);
INSERT INTO `prices` VALUES(212, 100, 6, 1150.00);
INSERT INTO `prices` VALUES(213, 100, 7, 1300.00);
INSERT INTO `prices` VALUES(214, 100, 8, 1450.00);
INSERT INTO `prices` VALUES(215, 100, 1, 700.00);
INSERT INTO `prices` VALUES(216, 101, 6, 1850.00);
INSERT INTO `prices` VALUES(217, 101, 7, 2050.00);
INSERT INTO `prices` VALUES(218, 101, 8, 2250.00);
INSERT INTO `prices` VALUES(219, 101, 1, 1200.00);
INSERT INTO `prices` VALUES(220, 102, 6, 1450.00);
INSERT INTO `prices` VALUES(221, 102, 7, 1600.00);
INSERT INTO `prices` VALUES(222, 102, 8, 1750.00);
INSERT INTO `prices` VALUES(223, 102, 1, 1000.00);
INSERT INTO `prices` VALUES(224, 103, 6, 1850.00);
INSERT INTO `prices` VALUES(225, 103, 7, 2050.00);
INSERT INTO `prices` VALUES(226, 103, 8, 2250.00);
INSERT INTO `prices` VALUES(227, 103, 1, 1200.00);
INSERT INTO `prices` VALUES(228, 104, 6, 1450.00);
INSERT INTO `prices` VALUES(229, 104, 7, 1600.00);
INSERT INTO `prices` VALUES(230, 104, 8, 1750.00);
INSERT INTO `prices` VALUES(231, 104, 1, 1000.00);
INSERT INTO `prices` VALUES(232, 105, 6, 1850.00);
INSERT INTO `prices` VALUES(233, 105, 7, 2050.00);
INSERT INTO `prices` VALUES(234, 105, 8, 2250.00);
INSERT INTO `prices` VALUES(235, 105, 1, 1200.00);
INSERT INTO `prices` VALUES(236, 106, 6, 1450.00);
INSERT INTO `prices` VALUES(237, 106, 7, 1600.00);
INSERT INTO `prices` VALUES(238, 106, 8, 1750.00);
INSERT INTO `prices` VALUES(239, 106, 1, 1000.00);
INSERT INTO `prices` VALUES(240, 106, 6, 1450.00);
INSERT INTO `prices` VALUES(241, 106, 7, 1600.00);
INSERT INTO `prices` VALUES(242, 106, 8, 1750.00);
INSERT INTO `prices` VALUES(243, 106, 1, 1000.00);
INSERT INTO `prices` VALUES(244, 107, 6, 1850.00);
INSERT INTO `prices` VALUES(245, 107, 7, 2050.00);
INSERT INTO `prices` VALUES(246, 107, 8, 2250.00);
INSERT INTO `prices` VALUES(247, 107, 1, 1200.00);
INSERT INTO `prices` VALUES(248, 108, 6, 1450.00);
INSERT INTO `prices` VALUES(249, 108, 7, 1600.00);
INSERT INTO `prices` VALUES(250, 108, 8, 1750.00);
INSERT INTO `prices` VALUES(251, 108, 1, 1000.00);
INSERT INTO `prices` VALUES(252, 109, 6, 1850.00);
INSERT INTO `prices` VALUES(253, 109, 7, 2050.00);
INSERT INTO `prices` VALUES(254, 109, 8, 2250.00);
INSERT INTO `prices` VALUES(255, 109, 1, 1200.00);
INSERT INTO `prices` VALUES(256, 110, 6, 1450.00);
INSERT INTO `prices` VALUES(257, 110, 7, 1600.00);
INSERT INTO `prices` VALUES(258, 110, 8, 1750.00);
INSERT INTO `prices` VALUES(259, 110, 1, 1000.00);
INSERT INTO `prices` VALUES(260, 111, 6, 1850.00);
INSERT INTO `prices` VALUES(261, 111, 7, 2050.00);
INSERT INTO `prices` VALUES(262, 111, 8, 2250.00);
INSERT INTO `prices` VALUES(263, 111, 1, 1200.00);
INSERT INTO `prices` VALUES(264, 112, 6, 1450.00);
INSERT INTO `prices` VALUES(265, 112, 7, 1600.00);
INSERT INTO `prices` VALUES(266, 112, 8, 1750.00);
INSERT INTO `prices` VALUES(267, 112, 1, 1000.00);
INSERT INTO `prices` VALUES(268, 113, 6, 1850.00);
INSERT INTO `prices` VALUES(269, 113, 7, 2050.00);
INSERT INTO `prices` VALUES(270, 113, 8, 2250.00);
INSERT INTO `prices` VALUES(271, 113, 1, 1200.00);
INSERT INTO `prices` VALUES(272, 116, 6, 1450.00);
INSERT INTO `prices` VALUES(273, 116, 7, 1600.00);
INSERT INTO `prices` VALUES(274, 116, 8, 1750.00);
INSERT INTO `prices` VALUES(275, 116, 1, 1000.00);
INSERT INTO `prices` VALUES(276, 115, 6, 1850.00);
INSERT INTO `prices` VALUES(277, 115, 7, 2050.00);
INSERT INTO `prices` VALUES(278, 115, 8, 2250.00);
INSERT INTO `prices` VALUES(279, 115, 1, 1200.00);
INSERT INTO `prices` VALUES(280, 117, 6, 1850.00);
INSERT INTO `prices` VALUES(281, 117, 7, 2050.00);
INSERT INTO `prices` VALUES(282, 117, 8, 2250.00);
INSERT INTO `prices` VALUES(283, 117, 1, 1200.00);
INSERT INTO `prices` VALUES(284, 118, 6, 1450.00);
INSERT INTO `prices` VALUES(285, 118, 7, 1600.00);
INSERT INTO `prices` VALUES(286, 118, 8, 1750.00);
INSERT INTO `prices` VALUES(287, 118, 1, 1000.00);
INSERT INTO `prices` VALUES(288, 119, 6, 1850.00);
INSERT INTO `prices` VALUES(289, 119, 7, 2050.00);
INSERT INTO `prices` VALUES(290, 119, 8, 2250.00);
INSERT INTO `prices` VALUES(291, 119, 1, 1200.00);
INSERT INTO `prices` VALUES(292, 120, 6, 1450.00);
INSERT INTO `prices` VALUES(293, 120, 7, 1600.00);
INSERT INTO `prices` VALUES(294, 120, 8, 1750.00);
INSERT INTO `prices` VALUES(295, 120, 1, 1000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rates`
--

CREATE TABLE `rates` (
  `id` int(11) NOT NULL auto_increment,
  `room_id` int(11) NOT NULL,
  `type_reservation_id` int(11) NOT NULL,
  `season` enum('','ALTA','BAJA') default NULL,
  `price` decimal(10,2) default NULL,
  `adults` decimal(10,2) default NULL,
  `children` decimal(10,2) default NULL,
  `additional_person` decimal(10,2) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_rates_rooms_idx` (`room_id`),
  KEY `fk_rates_type_reservation1_idx` (`type_reservation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=134 ;

--
-- Volcar la base de datos para la tabla `rates`
--

INSERT INTO `rates` VALUES(89, 1, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(90, 1, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(91, 2, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(92, 2, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(93, 3, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(94, 3, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(95, 4, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(96, 4, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(98, 5, 1, 'ALTA', NULL, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(100, 5, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(101, 6, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(102, 6, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(103, 7, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(104, 7, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(105, 8, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(106, 8, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(107, 9, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(108, 9, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(109, 10, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(110, 10, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(111, 11, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(112, 11, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(113, 12, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(114, 12, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(115, 13, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(116, 13, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(117, 14, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(118, 14, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(119, 15, 1, 'ALTA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(120, 15, 1, 'BAJA', 0.00, NULL, NULL, NULL);
INSERT INTO `rates` VALUES(121, 16, 1, 'ALTA', 0.00, 200.00, 150.00, NULL);
INSERT INTO `rates` VALUES(122, 16, 1, 'BAJA', 0.00, 170.00, 120.00, NULL);
INSERT INTO `rates` VALUES(123, 17, 1, 'ALTA', 0.00, 200.00, 150.00, NULL);
INSERT INTO `rates` VALUES(124, 17, 1, 'BAJA', 0.00, 170.00, 120.00, NULL);
INSERT INTO `rates` VALUES(125, 18, 1, 'ALTA', 0.00, 200.00, 150.00, NULL);
INSERT INTO `rates` VALUES(126, 18, 1, 'BAJA', 0.00, 170.00, 120.00, NULL);
INSERT INTO `rates` VALUES(127, 19, 1, 'ALTA', 0.00, 200.00, 150.00, NULL);
INSERT INTO `rates` VALUES(128, 19, 1, 'BAJA', 0.00, 170.00, 120.00, NULL);
INSERT INTO `rates` VALUES(129, 12, 2, 'ALTA', 0.00, NULL, 0.00, NULL);
INSERT INTO `rates` VALUES(130, 20, 1, 'ALTA', 0.00, NULL, 0.00, NULL);
INSERT INTO `rates` VALUES(131, 20, 1, 'BAJA', 0.00, NULL, 0.00, NULL);
INSERT INTO `rates` VALUES(132, 21, 1, 'ALTA', 0.00, NULL, 0.00, NULL);
INSERT INTO `rates` VALUES(133, 21, 1, 'ALTA', 0.00, NULL, 0.00, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservation`
--

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL auto_increment,
  `type_reservation` enum('','CABANA','TENT','CAMPED','DAYPASS') character set utf8 default NULL,
  `customer_reservation_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `checkin` datetime default NULL,
  `checkout` datetime default NULL,
  `adults` int(11) default NULL,
  `children` int(11) default '0',
  `pets` int(11) default '0',
  `totalpax` int(11) default NULL,
  `statux` enum('FOR-CONFIRMED','RESERVED','CANCELLED','NO-SHOW','OCCUPIED','AVAILABLE') character set utf8 default NULL,
  `nigth_ta` int(11) default NULL,
  `nigth_tb` int(11) default NULL,
  `nights` int(11) default NULL,
  `price_ta` decimal(10,2) default NULL,
  `price_tb` decimal(10,2) default NULL,
  `price_early_checkin` decimal(10,2) default NULL,
  `price_late_checkout` decimal(10,2) default NULL,
  `price` decimal(10,2) default NULL,
  `description` text,
  PRIMARY KEY  (`id`),
  KEY `fk_reservation_rooms1_idx` (`room_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Volcar la base de datos para la tabla `reservation`
--

INSERT INTO `reservation` VALUES(1, 'CABANA', 1, 7, '2013-12-15 15:00:00', '2013-12-22 13:00:00', 3, 0, 2, 3, 'RESERVED', 0, 5, 5, 0.00, 1100.00, 0.00, 0.00, 5500.00, 'antc $2750');
INSERT INTO `reservation` VALUES(3, 'CABANA', 3, 1, '2013-12-17 15:00:00', '2013-12-20 13:00:00', 2, 0, 2, 2, 'RESERVED', 0, 3, 3, 0.00, 700.00, 0.00, 0.00, 2100.00, 'antc$ 1,050  rest$ 1,050');
INSERT INTO `reservation` VALUES(4, 'CABANA', 4, 10, '2013-12-18 15:00:00', '2013-12-22 13:00:00', 2, 0, 2, 2, 'RESERVED', 2, 2, 4, 1200.00, 1000.00, 0.00, 0.00, 4400.00, '  Fecha de entrada: miércoles 18 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: domingo 22 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches: 4\n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches = $  TOTAL = $4,800.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches  = $  TOTAL = $4,800.00. \n \n \n·         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: viernes 27 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches:1\n \n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches = $  TOTAL = $1,200.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches  = $  TOTAL = $1,200.00.\n \nGRAN TOTAL $12,000.00\n \nPor esta cantidad se otorga un 10 % de descuento quedando en $ 10,800.00\n \n \n\nAntc$5400 (4/11/13)\nRest$5400');
INSERT INTO `reservation` VALUES(5, 'CABANA', 4, 9, '2013-12-18 15:00:00', '2013-12-22 13:00:00', 2, 0, 2, 2, 'RESERVED', 2, 2, 4, 1200.00, 1000.00, 0.00, 0.00, 4400.00, '  Fecha de entrada: miércoles 18 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: domingo 22 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches: 4\n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches = $  TOTAL = $4,800.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches  = $  TOTAL = $4,800.00. \n \n \n·         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: viernes 27 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches:1\n \n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches = $  TOTAL = $1,200.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches  = $  TOTAL = $1,200.00.\n \nGRAN TOTAL $12,000.00\n \nPor esta cantidad se otorga un 10 % de descuento quedando en $ 10,800.00\n \n \n\nAntc$5400 (4/11/13)\nRest$5400');
INSERT INTO `reservation` VALUES(6, 'CABANA', 4, 10, '2013-12-26 15:00:00', '2013-12-27 13:00:00', 2, 0, 2, 2, 'RESERVED', 1, 0, 1, 1200.00, 0.00, 0.00, 0.00, 1200.00, '  Fecha de entrada: miércoles 18 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: domingo 22 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches: 4\n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches = $  TOTAL = $4,800.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches  = $  TOTAL = $4,800.00. \n \n \n·         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: viernes 27 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches:1\n \n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches = $  TOTAL = $1,200.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches  = $  TOTAL = $1,200.00.\n \nGRAN TOTAL $12,000.00\n \nPor esta cantidad se otorga un 10 % de descuento quedando en $ 10,800.00\n \n \n\nAntc$5400 (4/11/13)\nRest$5400');
INSERT INTO `reservation` VALUES(7, 'CABANA', 4, 9, '2013-12-26 15:00:00', '2013-12-27 13:00:00', 2, 0, 2, 2, 'RESERVED', 1, 0, 1, 1200.00, 0.00, 0.00, 0.00, 1200.00, '  Fecha de entrada: miércoles 18 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: domingo 22 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches: 4\n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches = $  TOTAL = $4,800.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 4 noches  = $  TOTAL = $4,800.00. \n \n \n·         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n·         Fecha de salida: viernes 27 de diciembre del 2013 a las 13:00 hrs\n·         Total Noches:1\n \n ·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches = $  TOTAL = $1,200.00.\n \n·                    1 Cabaña de aire acondicionado para 2 personas más 2 mascotas gratis en hospedaje, al precio de $1,200.00 pesos x noche x 1 noches  = $  TOTAL = $1,200.00.\n \nGRAN TOTAL $12,000.00\n \nPor esta cantidad se otorga un 10 % de descuento quedando en $ 10,800.00\n \n \n\nAntc$5400 (4/11/13)\nRest$5400');
INSERT INTO `reservation` VALUES(8, 'CABANA', 5, 1, '2013-12-21 15:00:00', '2013-12-23 13:00:00', 5, 0, 2, 5, 'RESERVED', 2, 0, 2, 1300.00, 0.00, 0.00, 0.00, 2600.00, 'PRESUPUESTO:\n·                Fecha de entrada: viernes 20 de Diciembre de 2013 a las 15:00 hrs\n·                Fecha de salida: domingo 22 de Diciembre de 2013 a las 13:00 hrs\n·                Total Noches: 2\n \n \nOpción 1:\n \n·                 1 Cabañas de ventilador para 05 personas más 2 mascotas gratis en hospedaje, al precio de $1,300.00 pesos x 2 noches TOTAL = $2,600.00.\n \nPor lo tanto para reservar debe depositar la cantidad de $1,300.00\n\nT:$2,600\nA:$1,300.00\nR:$1,300.00\n');
INSERT INTO `reservation` VALUES(9, 'CABANA', 6, 6, '2013-12-28 15:00:00', '2013-12-31 13:00:00', 3, 0, 3, 3, 'RESERVED', 3, 0, 3, 1350.00, 0.00, 0.00, 0.00, 4350.00, 'PRESUPUESTO:\n\n·         Fecha de entrada: miércoles 25 de diciembre de 2013 al a las 15:00 hrs\n\n·         Fecha de salida: sábado 28 de diciembre del 2013 a las 13:00 hrs\n\n·         Total Noches: 3\n\n Opción 1:\n \n·                    1 Cabañas de aire acondicionado para 3 personas más 02 mascotas gratis, al precio de $1,350.00 pesos x cabaña x noche x 3 noches TOTAL = $4,050.00.\n·                    Mascota adicional $100.00 x 3 noches = $300.00\n·                    GRAN TOTAL HOSPEDAJE: $4,350.00\n\nA: $2175\nR: $2175\n\nFL: 31 / Octubre');
INSERT INTO `reservation` VALUES(10, 'CABANA', 7, 12, '2013-12-26 15:00:00', '2013-12-30 13:00:00', 2, 0, 1, 2, 'RESERVED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, '·               Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\r\n·               Fecha de salida: lunes 30 de diciembre de 2013 a las 13:00 hrs\r\n·               Total Noches: 04\r\n\r\n·                1 Cabaña de aire acondicionado para 02 personas más una mascota gratis, al precio de $1,200.00 pesos x noche x 4 noches TOTAL = $4,800.00.\r\n\r\nPor lo tanto para reservar debe depositar la cantidad de $2,400.00.\r\n\r\nT: $4,800\r\nA: $2,400.00\r\nR:$ 2,400.00\r\nFL: 02 de diciembre');
INSERT INTO `reservation` VALUES(11, 'CABANA', 8, 6, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 2, 0, 0, 2, 'RESERVED', 3, 0, 3, 1200.00, 0.00, 0.00, 0.00, 3600.00, '•         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n•         Fecha de salida: domingo 29 de diciembre del 2013 a las 13:00 hrs\n•         Total Noches: 3\n \n \n•                    1 Cabañas de aire acondicionado para 2 personas, al precio de $1,200.00 pesos x cabaña x noche x 3 noches TOTAL = $3,600.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 2 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $850.00 pesos x cabaña x noche x 3 noches TOTAL = $2,550.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n \nGRAN TOTAL DE HOSPEDAJE $18,150.00\n \nPOR ESTA CANTIDAD SE OTORGA UN 10% DE DESCUENTO QUEDANDO EN $16,335.00\n \n \nPor lo tanto debe reservar con la cantidad de $8,168.00\n\n\nAntc$8168\nrest$8167\n');
INSERT INTO `reservation` VALUES(12, 'CABANA', 8, 1, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 3, 1, 0, 4, 'RESERVED', 3, 0, 3, 1000.00, 0.00, 0.00, 0.00, 3000.00, '•         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n•         Fecha de salida: domingo 29 de diciembre del 2013 a las 13:00 hrs\n•         Total Noches: 3\n \n \n•                    1 Cabañas de aire acondicionado para 2 personas, al precio de $1,200.00 pesos x cabaña x noche x 3 noches TOTAL = $3,600.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 2 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $850.00 pesos x cabaña x noche x 3 noches TOTAL = $2,550.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n \nGRAN TOTAL DE HOSPEDAJE $18,150.00\n \nPOR ESTA CANTIDAD SE OTORGA UN 10% DE DESCUENTO QUEDANDO EN $16,335.00\n \n \nPor lo tanto debe reservar con la cantidad de $8,168.00\n\n\nAntc$8168\nrest$8167\n');
INSERT INTO `reservation` VALUES(13, 'CABANA', 8, 2, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 3, 2, 0, 5, 'RESERVED', 3, 0, 3, 1000.00, 0.00, 0.00, 0.00, 3000.00, '•         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n•         Fecha de salida: domingo 29 de diciembre del 2013 a las 13:00 hrs\n•         Total Noches: 3\n \n \n•                    1 Cabañas de aire acondicionado para 2 personas, al precio de $1,200.00 pesos x cabaña x noche x 3 noches TOTAL = $3,600.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 2 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $850.00 pesos x cabaña x noche x 3 noches TOTAL = $2,550.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n \nGRAN TOTAL DE HOSPEDAJE $18,150.00\n \nPOR ESTA CANTIDAD SE OTORGA UN 10% DE DESCUENTO QUEDANDO EN $16,335.00\n \n \nPor lo tanto debe reservar con la cantidad de $8,168.00\n\n\nAntc$8168\nrest$8167\n');
INSERT INTO `reservation` VALUES(14, 'CABANA', 8, 3, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 3, 1, 0, 4, 'RESERVED', 3, 0, 3, 1000.00, 0.00, 0.00, 0.00, 3000.00, '');
INSERT INTO `reservation` VALUES(15, 'CABANA', 8, 4, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 3, 1, 0, 4, 'RESERVED', 3, 0, 3, 1000.00, 0.00, 0.00, 0.00, 3000.00, '•         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n•         Fecha de salida: domingo 29 de diciembre del 2013 a las 13:00 hrs\n•         Total Noches: 3\n \n \n•                    1 Cabañas de aire acondicionado para 2 personas, al precio de $1,200.00 pesos x cabaña x noche x 3 noches TOTAL = $3,600.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 2 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $850.00 pesos x cabaña x noche x 3 noches TOTAL = $2,550.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n \nGRAN TOTAL DE HOSPEDAJE $18,150.00\n \nPOR ESTA CANTIDAD SE OTORGA UN 10% DE DESCUENTO QUEDANDO EN $16,335.00\n \n \nPor lo tanto debe reservar con la cantidad de $8,168.00\n\n\nAntc$8168\nrest$8167\n');
INSERT INTO `reservation` VALUES(16, 'CABANA', 8, 5, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 2, 2, 0, 4, 'RESERVED', 3, 0, 3, 850.00, 0.00, 0.00, 0.00, 2550.00, '•         Fecha de entrada: jueves 26 de diciembre de 2013 al a las 15:00 hrs\n•         Fecha de salida: domingo 29 de diciembre del 2013 a las 13:00 hrs\n•         Total Noches: 3\n \n \n•                    1 Cabañas de aire acondicionado para 2 personas, al precio de $1,200.00 pesos x cabaña x noche x 3 noches TOTAL = $3,600.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n•                    1 Cabañas de ventilador  para 2 personas más 2 niño menor de 10 años gratis en hospedaje, al precio de $850.00 pesos x cabaña x noche x 3 noches TOTAL = $2,550.00.\n•                    1 Cabañas de ventilador  para 3 personas más 1 niño menor de 10 años gratis en hospedaje, al precio de $1,000.00 pesos x cabaña x noche x 3 noches TOTAL = $3,000.00.\n \nGRAN TOTAL DE HOSPEDAJE $18,150.00\n \nPOR ESTA CANTIDAD SE OTORGA UN 10% DE DESCUENTO QUEDANDO EN $16,335.00\n \n \nPor lo tanto debe reservar con la cantidad de $8,168.00\n\n\nAntc$8168\nrest$8167\n');
INSERT INTO `reservation` VALUES(17, 'CABANA', 9, 7, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 3, 1, 0, 4, 'RESERVED', 3, 0, 3, 1350.00, 0.00, 0.00, 0.00, 4050.00, '·               Fecha de entrada: jueves 26 de diciembre del 2013 a las 15:00 hrs\n·               Fecha de salida: domingo 29 de diciembre de 2013 a las 13:00 hrs\n·               Total Noches: 03\n \n \n·                1 Cabañas de aire acondicionado para 03 personas más 01 niño menor de 10 años gratis en hospedaje, al precio de $1,350.00 pesos x 3 noches TOTAL = $4,050.00.\n\nantc$2025 dep 9 dic 13\nrest$2025');
INSERT INTO `reservation` VALUES(18, 'CABANA', 10, 11, '2013-12-26 15:00:00', '2013-12-29 13:00:00', 3, 0, 3, 3, 'FOR-CONFIRMED', 3, 0, 3, 1350.00, 0.00, 0.00, 0.00, 4350.00, '·                Fecha de entrada: jueves 26 de diciembre del 2013 a las 15:00 hrs\n·                Fecha de salida: domingo 29 de diciembre de 2013 a las 13:00 hrs\n·                Total Noches: 3\n \n \n·                 1 Cabañas de aire acondicionado para 3 personas más 2 mascotas gratis en hospedaje,al precio de $1,350.00 pesos x 3 noches TOTAL = $4,050.00.\n·                 1 mascota adicional en hospedaje  a $100 x mascota x  noch x 3 noch = $ 300\n·                 Total de hospedaje $4,350.00\n\nAntc $\nRest$ 4350');
INSERT INTO `reservation` VALUES(19, 'CABANA', 11, 1, '2013-12-29 15:00:00', '2014-01-02 13:00:00', 2, 2, 2, 4, 'RESERVED', 4, 0, 4, 850.00, 0.00, 0.00, 0.00, 3400.00, '                    1 Cabañas de ventilador para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis, al precio de $850.00 pesos x noche x  4 noches TOTAL = $3,400.00.\n·                    1 Cabañas de ventilador para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis, al precio de $850.00 pesos x noche x  4 noches TOTAL = $3,400.00.\n·                    1 Cabañas de aire acondicionado para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis,, al precio de $1,200.00 pesos x noche x  4 noches TOTAL = $4,800.00.\n \nGRAN TOTAL DE HOSPEDAJE $11,600.00\n \nPor esta cantidad se otorga un 10% quedando en $10,440.00\n \n\nantc$5220\nrest$ 5220\n\nFL 4 nov 13');
INSERT INTO `reservation` VALUES(20, 'CABANA', 11, 2, '2013-12-29 15:00:00', '2014-01-02 13:00:00', 2, 2, 2, 4, 'RESERVED', 4, 0, 4, 850.00, 0.00, 0.00, 0.00, 3400.00, '                    1 Cabañas de ventilador para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis, al precio de $850.00 pesos x noche x  4 noches TOTAL = $3,400.00.\n·                    1 Cabañas de ventilador para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis, al precio de $850.00 pesos x noche x  4 noches TOTAL = $3,400.00.\n·                    1 Cabañas de aire acondicionado para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis,, al precio de $1,200.00 pesos x noche x  4 noches TOTAL = $4,800.00.\n \nGRAN TOTAL DE HOSPEDAJE $11,600.00\n \nPor esta cantidad se otorga un 10% quedando en $10,440.00\n \n\nantc$5220\nrest$ 5220\n\nFL 4 nov 13');
INSERT INTO `reservation` VALUES(21, 'CABANA', 11, 6, '2013-12-29 15:00:00', '2014-01-02 13:00:00', 2, 2, 2, 4, 'RESERVED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, '                    1 Cabañas de ventilador para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis, al precio de $850.00 pesos x noche x  4 noches TOTAL = $3,400.00.\n·                    1 Cabañas de ventilador para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis, al precio de $850.00 pesos x noche x  4 noches TOTAL = $3,400.00.\n·                    1 Cabañas de aire acondicionado para 2 personas más 2 niños menores de 10 años gratis en hospedaje más 2 mascotas gratis,, al precio de $1,200.00 pesos x noche x  4 noches TOTAL = $4,800.00.\n \nGRAN TOTAL DE HOSPEDAJE $11,600.00\n \nPor esta cantidad se otorga un 10% quedando en $10,440.00\n \n\nantc$5220\nrest$ 5220\n\nFL 4 nov 13');
INSERT INTO `reservation` VALUES(24, 'CABANA', 14, 6, '2013-12-16 15:00:00', '2013-12-21 13:00:00', 2, 2, 1, 4, 'RESERVED', 1, 4, 5, 1200.00, 1000.00, 0.00, 0.00, 5200.00, '');
INSERT INTO `reservation` VALUES(38, 'CABANA', 28, 1, '2013-12-25 15:00:00', '2013-12-28 13:00:00', 5, 0, 0, 5, 'FOR-CONFIRMED', 3, 0, 3, 1300.00, 0.00, 0.00, 0.00, 3900.00, NULL);
INSERT INTO `reservation` VALUES(40, 'CABANA', 30, 9, '2013-12-17 15:00:00', '2013-12-18 13:00:00', 3, 2, 3, 5, 'FOR-CONFIRMED', 0, 1, 1, 0.00, 1100.00, 0.00, 0.00, 1200.00, NULL);
INSERT INTO `reservation` VALUES(41, 'CABANA', 31, 7, '2013-12-19 15:00:00', '2013-12-22 13:00:00', 5, 0, 0, 5, 'CANCELLED', 2, 1, 3, 1650.00, 1300.00, 0.00, 0.00, 4600.00, 'PRESUPUESTO:\n·      Fecha de entrada: jueves 19 de diciembre del 2013 a las 15:00 hrs\n·      Fecha de salida: domingo 22 de diciembre de 2013 a las 13:00 hrs\n·      Total Noches: 3\n \n \nOpción 1:\n \n·      1 Cabaña de aire acondicionado para 5 personas más 2 niños menores de 10 años gratis en hospedaje, al precio de $1,300.00 pesos x 1 noches TOTAL = $1,300.00.(Temp. Baja 19 de Diciembre).\n·      1 Cabaña de aire acondicionado para 5 personas más 2 niños menores de 10 años gratis en hospedaje, al precio de $1,650.00 pesos x 2 noches TOTAL = $3,300.00.(Temp. Alta 20 y 21 de Diciembre).\n·      Total de Hospedaje$4,600.00\n\n·      Por esta cantidad se otorga un 3% de descuento quedando en $4,462.00\n \n·       Por lo tanto para reservar debe depositar la cantidad de $2,231.00.\n \n\nAnt $0\nRest $4,462.00\n');
INSERT INTO `reservation` VALUES(42, 'CABANA', 32, 6, '2013-12-20 15:00:00', '2013-12-22 13:00:00', 2, 0, 0, 2, 'RESERVED', 2, 0, 2, 1200.00, 0.00, 0.00, 0.00, 2400.00, 'NOMBRE: José Luis B.\n\nTELÉFONO: Favor de Proporcionar\n\nPROCEDENCIA: Favor de Proporcionar\nEMAIL: badjl0550@gmail.com\n \n\n\nPRESUPUESTO:\n•                Fecha de entrada: viernes 20 de diciembre del 2013 a las 15:00 hrs\n•                Fecha de salida: domingo 22 de diciembre de 2013 a las 13:00 hrs\n•                Total Noches: 02\n \n \nOpción 1:\n \n•                 1 Cabañas de aire acondicionado para 02 personas, al precio de $1,200.00 pesos x 2 noches TOTAL = $2,400.00.\n \n\nANT: $1,200.00\n\nREST $1,200.00\n');
INSERT INTO `reservation` VALUES(44, 'CABANA', 34, 6, '2014-02-14 15:00:00', '2014-02-21 13:00:00', 2, NULL, 0, 2, 'FOR-CONFIRMED', 0, 7, 7, 0.00, 1000.00, 0.00, 0.00, 7000.00, NULL);
INSERT INTO `reservation` VALUES(45, 'CABANA', 35, 6, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(46, 'CABANA', 35, 7, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(47, 'CABANA', 35, 8, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(48, 'CABANA', 35, 9, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(49, 'CABANA', 35, 10, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(50, 'CABANA', 35, 11, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(51, 'CABANA', 35, 12, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(52, 'CABANA', 35, 13, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(53, 'CABANA', 35, 14, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(54, 'CABANA', 35, 15, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 1200.00, 0.00, 0.00, 0.00, 4800.00, NULL);
INSERT INTO `reservation` VALUES(55, 'CABANA', 35, 4, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, 2, 0, 4, 'FOR-CONFIRMED', 4, 0, 4, 850.00, 0.00, 0.00, 0.00, 3400.00, NULL);
INSERT INTO `reservation` VALUES(56, 'CABANA', 35, 5, '2014-07-19 15:00:00', '2014-07-23 13:00:00', 2, NULL, 0, 2, 'FOR-CONFIRMED', 4, 0, 4, 850.00, 0.00, 0.00, 0.00, 3400.00, NULL);
INSERT INTO `reservation` VALUES(57, 'CABANA', 36, 6, '2014-01-03 15:00:00', '2014-01-06 13:00:00', 5, NULL, 2, 5, 'FOR-CONFIRMED', 3, 0, 3, 1650.00, 0.00, 0.00, 0.00, 4950.00, NULL);
INSERT INTO `reservation` VALUES(58, 'CABANA', 37, 6, '2014-03-24 15:00:00', '2014-03-27 13:00:00', 2, NULL, 2, 2, 'FOR-CONFIRMED', 0, 3, 3, 0.00, 1000.00, 0.00, 0.00, 3000.00, NULL);
INSERT INTO `reservation` VALUES(59, 'CABANA', 38, 6, '2014-02-01 15:00:00', '2014-02-03 13:00:00', 3, NULL, 0, 3, 'FOR-CONFIRMED', 2, 0, 2, 1350.00, 0.00, 0.00, 0.00, 2700.00, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservation_camped`
--

CREATE TABLE `reservation_camped` (
  `id` int(11) NOT NULL auto_increment,
  `type_reservation` enum('','CABANA','TENT','CAMPED','DAYPASS') character set utf8 NOT NULL,
  `customer_reservation_id` int(11) NOT NULL,
  `checkin` datetime default NULL,
  `checkout` datetime default NULL,
  `adults` int(11) default NULL,
  `children` int(11) default NULL,
  `pets` int(11) default NULL,
  `totalpax` int(11) default NULL,
  `statux` enum('FOR-CONFIRMED','RESERVED','CANCELLED','NO-SHOW','OCCUPIED','AVAILABLE') character set utf8 default NULL,
  `nigth_ta` int(11) default NULL,
  `nigth_tb` int(11) default NULL,
  `nights` int(11) default NULL,
  `price_ta` decimal(10,2) default NULL,
  `price_tb` decimal(10,2) default NULL,
  `price_early_checkin` decimal(10,2) default NULL,
  `price_late_checkout` decimal(10,2) default NULL,
  `price` decimal(10,2) default NULL,
  `description` text character set utf8,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `reservation_camped`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL auto_increment,
  `room_type_id` int(11) NOT NULL,
  `capacity` int(11) default NULL,
  `room` varchar(10) default NULL,
  `image` varchar(50) default NULL,
  `image_title` varchar(100) default NULL,
  `image_title_es` varchar(100) default NULL,
  `description` text,
  `descrition_es` text,
  PRIMARY KEY  (`id`),
  KEY `fk_rooms_rooms_type1_idx` (`room_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Volcar la base de datos para la tabla `rooms`
--

INSERT INTO `rooms` VALUES(1, 1, 8, 'CabVent-01', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(2, 1, 8, 'CabVent-02', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(3, 1, 8, 'CabVent-03', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(4, 1, 8, 'CabVent-04', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(5, 1, 8, 'CabVent-05', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(6, 2, 8, 'CabAA-06', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(7, 2, 8, 'CabAA-07', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(8, 2, 8, 'CabAA-08', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(9, 2, 8, 'CabAA-09', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(10, 2, 8, 'CabAA-10', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(11, 2, 8, 'CabAA-11', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(12, 2, 8, 'CabAA-12', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(13, 2, 8, 'CabAA-14', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(14, 2, 8, 'CabAA-15', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(15, 2, 8, 'CabAA-16', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(16, 3, 7, 'RtaCcTr-17', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(17, 3, 4, 'RtaCcTr-18', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(18, 3, 4, 'RtaCcTr-19', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(19, 3, 4, 'RtaCcTr-20', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(20, 5, 2, 'RtaSaf-21', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `rooms` VALUES(21, 5, 2, 'RtaSaf-22', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rooms_type`
--

CREATE TABLE `rooms_type` (
  `id` int(11) NOT NULL auto_increment,
  `tipe` varchar(250) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `rooms_type`
--

INSERT INTO `rooms_type` VALUES(1, 'Cabaña Ventiladores');
INSERT INTO `rooms_type` VALUES(2, 'Cabaña Aire Acondicionado');
INSERT INTO `rooms_type` VALUES(3, 'Casa Campaña Tradicional');
INSERT INTO `rooms_type` VALUES(5, 'Casa Campaña Safari');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seasons`
--

CREATE TABLE `seasons` (
  `id` int(11) NOT NULL auto_increment,
  `commemoration` varchar(100) default NULL,
  `froom` date default NULL,
  `too` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `seasons`
--

INSERT INTO `seasons` VALUES(5, 'Fiestas Patrias', '2013-09-13', '2013-09-16');
INSERT INTO `seasons` VALUES(6, 'Todos Santos', '2013-11-01', '2013-11-03');
INSERT INTO `seasons` VALUES(7, 'Revolución', '2013-11-15', '2013-11-18');
INSERT INTO `seasons` VALUES(8, 'Fiestas Navideñas', '2013-12-20', '2014-01-06');
INSERT INTO `seasons` VALUES(9, 'Constitución', '2014-01-31', '2014-02-03');
INSERT INTO `seasons` VALUES(10, 'Carnaval', '2014-02-28', '2014-03-05');
INSERT INTO `seasons` VALUES(11, 'Primavera', '2014-03-14', '2014-03-17');
INSERT INTO `seasons` VALUES(12, 'Semana Santa', '2014-04-11', '2014-04-27');
INSERT INTO `seasons` VALUES(13, 'D. Trabajo / B. Puebla', '2014-05-01', '2014-05-05');
INSERT INTO `seasons` VALUES(14, 'Día de las madres', '2014-05-10', '2014-05-11');
INSERT INTO `seasons` VALUES(15, 'Día del maestro', '2014-05-15', '2014-05-18');
INSERT INTO `seasons` VALUES(16, 'Vacaciones de Verano', '2014-07-11', '2014-08-18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_audit_trail`
--

CREATE TABLE `tbl_audit_trail` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `old_value` text NOT NULL,
  `new_value` text NOT NULL,
  `action` varchar(20) NOT NULL,
  `model` varchar(255) NOT NULL,
  `field` varchar(64) NOT NULL,
  `stamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `model_id` varchar(65) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_model_id` (`model_id`),
  KEY `idx_model` (`model`),
  KEY `idx_field` (`field`),
  KEY `idx_old_value` (`old_value`(16)),
  KEY `idx_new_value` (`new_value`(16)),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3682 ;

--
-- Volcar la base de datos para la tabla `tbl_audit_trail`
--

INSERT INTO `tbl_audit_trail` VALUES(3, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(4, '', 'silvia.gc15@hotmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(5, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(6, '', 'Francisca', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(7, '', 'Silva Grajales', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(8, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(9, '', 'DF', 'SET', 'CustomerReservations', 'state', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(10, '', 'DF', 'SET', 'CustomerReservations', 'city', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(11, '', 'Internet', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(12, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(13, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(14, '', '045 (555) 413-0381', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(15, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(16, '', '1', 'SET', 'CustomerReservations', 'id', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(17, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(18, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(19, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(20, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(21, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(22, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(23, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(24, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(25, '', '6', 'SET', 'Reservation', 'room_id', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(26, '', '2013-12-15 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(27, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(28, '', '3', 'SET', 'Reservation', 'adults', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(29, '', '', 'SET', 'Reservation', 'children', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(30, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(31, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(32, '', '5', 'SET', 'Reservation', 'nights', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(33, '', '3', 'SET', 'Reservation', 'totalpax', '2013-12-11 11:31:07', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(34, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(35, '', '5', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(36, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(37, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(38, '', '1100.00', 'SET', 'Reservation', 'price_tb', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(39, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(40, '', '5500', 'SET', 'Reservation', 'price', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(41, '', '1', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(42, '', '', 'SET', 'Reservation', 'description', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(43, '', '1', 'SET', 'Reservation', 'id', '2013-12-11 11:31:08', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(44, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(45, '', 'martin_vallejo01@hotmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(46, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(47, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(48, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(49, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(50, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(51, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(52, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(53, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(54, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(55, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(56, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(57, '', '2', 'SET', 'CustomerReservations', 'id', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(58, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(59, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(60, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(61, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(62, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(63, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(64, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(65, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(66, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(67, '', '2013-12-17 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(68, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(69, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 11:34:57', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(70, '', '', 'SET', 'Reservation', 'children', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(71, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(72, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(73, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(74, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(75, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(76, '', '3', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(77, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(78, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(79, '', '700.00', 'SET', 'Reservation', 'price_tb', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(80, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(81, '', '2100', 'SET', 'Reservation', 'price', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(82, '', '2', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(83, '', '', 'SET', 'Reservation', 'description', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(84, '', '2', 'SET', 'Reservation', 'id', '2013-12-11 11:34:58', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(85, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(86, '', 'martin_vallejo01@hotmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(87, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(88, '', 'Martin', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(89, '', 'Vallejo Velazquez', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(90, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(91, '', 'Favor de Proporcionar', 'SET', 'CustomerReservations', 'state', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(92, '', 'Favor de proporcionar', 'SET', 'CustomerReservations', 'city', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(93, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(94, '', 'Favor deProporcionar', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(95, '', 'Favor de Proporcionar', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(96, '', 'Favor de Proporcionar ', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(97, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(98, '', '3', 'SET', 'CustomerReservations', 'id', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(99, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(100, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(101, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(102, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(103, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(104, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(105, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(106, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(107, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(108, '', '2013-12-17 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(109, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(110, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(111, '', '', 'SET', 'Reservation', 'children', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(112, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(113, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(114, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(115, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(116, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(117, '', '3', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(118, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(119, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(120, '', '700.00', 'SET', 'Reservation', 'price_tb', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(121, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(122, '', '2100', 'SET', 'Reservation', 'price', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(123, '', '3', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(124, '', '', 'SET', 'Reservation', 'description', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(125, '', '3', 'SET', 'Reservation', 'id', '2013-12-11 11:45:06', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(126, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(127, '', 'frojas@urbanscience.com', 'SET', 'CustomerReservations', 'email', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(128, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(129, '', 'Fidencio', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(130, '', 'Rojas', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(131, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(132, '', 'Cd de Mexico', 'SET', 'CustomerReservations', 'state', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(133, '', 'Cd de mexico', 'SET', 'CustomerReservations', 'city', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(134, '', 'Ya se ha hospedado anterirmente', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 12:02:04', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(135, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(136, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(137, '', '045-555-401-8258', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(138, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(139, '', '4', 'SET', 'CustomerReservations', 'id', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(140, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(141, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(142, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(143, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(144, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(145, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(146, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(147, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(148, '', '10', 'SET', 'Reservation', 'room_id', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(149, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(150, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(151, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(152, '', '', 'SET', 'Reservation', 'children', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(153, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(154, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(155, '', '4', 'SET', 'Reservation', 'nights', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(156, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(157, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(158, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(159, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(160, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(161, '', '1000.00', 'SET', 'Reservation', 'price_tb', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(162, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(163, '', '4400', 'SET', 'Reservation', 'price', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(164, '', '4', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(165, '', '', 'SET', 'Reservation', 'description', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(166, '', '4', 'SET', 'Reservation', 'id', '2013-12-11 12:02:05', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(167, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(168, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(169, '', '9', 'SET', 'Reservation', 'room_id', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(170, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(171, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(172, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(173, '', '', 'SET', 'Reservation', 'children', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(174, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(175, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(176, '', '4', 'SET', 'Reservation', 'nights', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(177, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(178, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(179, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(180, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(181, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(182, '', '1000.00', 'SET', 'Reservation', 'price_tb', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(183, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(184, '', '4400', 'SET', 'Reservation', 'price', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(185, '', '4', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(186, '', '', 'SET', 'Reservation', 'description', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(187, '', '5', 'SET', 'Reservation', 'id', '2013-12-11 12:02:05', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(188, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(189, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(190, '', '10', 'SET', 'Reservation', 'room_id', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(191, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(192, '', '2013-12-27 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(193, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(194, '', '', 'SET', 'Reservation', 'children', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(195, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(196, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(197, '', '1', 'SET', 'Reservation', 'nights', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(198, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(199, '', '1', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(200, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(201, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(202, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(203, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(204, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(205, '', '1200', 'SET', 'Reservation', 'price', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(206, '', '4', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(207, '', '', 'SET', 'Reservation', 'description', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(208, '', '6', 'SET', 'Reservation', 'id', '2013-12-11 12:02:05', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(209, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(210, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(211, '', '9', 'SET', 'Reservation', 'room_id', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(212, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(213, '', '2013-12-27 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(214, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(215, '', '', 'SET', 'Reservation', 'children', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(216, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(217, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(218, '', '1', 'SET', 'Reservation', 'nights', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(219, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(220, '', '1', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(221, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(222, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(223, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(224, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(225, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(226, '', '1200', 'SET', 'Reservation', 'price', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(227, '', '4', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(228, '', '', 'SET', 'Reservation', 'description', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(229, '', '7', 'SET', 'Reservation', 'id', '2013-12-11 12:02:05', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(230, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(231, '', 'g.r.i.p.h.o@hotmail.com ', 'SET', 'CustomerReservations', 'email', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(232, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(233, '', 'Juan ', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(234, '', 'Hernández', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(235, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(236, '', 'Edo de México', 'SET', 'CustomerReservations', 'state', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(237, '', 'Edo de México', 'SET', 'CustomerReservations', 'city', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(238, '', 'x internet', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(239, '', '554 925 4705', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(240, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(241, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(242, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(243, '', '5', 'SET', 'CustomerReservations', 'id', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(244, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(245, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(246, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(247, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(248, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(249, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 17:12:20', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(250, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(251, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(252, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(253, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(254, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(255, '', '5', 'SET', 'Reservation', 'adults', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(256, '', '', 'SET', 'Reservation', 'children', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(257, '', '2', 'SET', 'Reservation', 'pets', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(258, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(259, '', '2', 'SET', 'Reservation', 'nights', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(260, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(261, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(262, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(263, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(264, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(265, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(266, '', '1300.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(267, '', '2600', 'SET', 'Reservation', 'price', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(268, '', '5', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(269, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(270, '', '8', 'SET', 'Reservation', 'id', '2013-12-11 17:12:20', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(271, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(272, '', 'rlcaballerop@prodigy.net.mx', 'SET', 'CustomerReservations', 'email', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(273, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(274, '', 'Ricardo ', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(275, '', 'Caballero', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(276, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(277, '', 'Cd. México', 'SET', 'CustomerReservations', 'state', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(278, '', 'Cd. México', 'SET', 'CustomerReservations', 'city', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(279, '', 'internet', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(280, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(281, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(282, '', '044 554 353 2202', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(283, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(284, '', '6', 'SET', 'CustomerReservations', 'id', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(285, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(286, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(287, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(288, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 17:17:40', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(289, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 17:17:41', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(290, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 17:17:41', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(291, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(292, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(293, '', '6', 'SET', 'Reservation', 'room_id', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(294, '', '2013-12-25 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(295, '', '2013-12-28 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(296, '', '3', 'SET', 'Reservation', 'adults', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(297, '', '', 'SET', 'Reservation', 'children', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(298, '', '3', 'SET', 'Reservation', 'pets', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(299, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(300, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(301, '', '3', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(302, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(303, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(304, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(305, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(306, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(307, '', '1350.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(308, '', '4350', 'SET', 'Reservation', 'price', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(309, '', '6', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(310, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(311, '', '9', 'SET', 'Reservation', 'id', '2013-12-11 17:17:41', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(312, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(313, '', 'rlcaballerop@prodigy.net.mx', 'SET', 'Customers', 'email', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(314, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(315, '', 'Ricardo ', 'SET', 'Customers', 'first_name', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(316, '', 'Caballero', 'SET', 'Customers', 'last_name', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(317, '', 'Mexico', 'SET', 'Customers', 'country', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(318, '', 'Cd. México', 'SET', 'Customers', 'state', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(319, '', 'Cd. México', 'SET', 'Customers', 'city', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(320, '', 'internet', 'SET', 'Customers', 'how_find_us', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(321, '', '', 'SET', 'Customers', 'home_phone', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(322, '', '', 'SET', 'Customers', 'work_phone', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(323, '', '044 554 353 2202', 'SET', 'Customers', 'cell_phone', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(324, '', '13', 'SET', 'Customers', 'id', '2013-12-11 17:17:41', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(325, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(326, '', ' jmd_mta@hotmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(327, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(328, '', 'Javier', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(329, '', 'Maldonado de Dios', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(330, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(331, '', 'Puebla', 'SET', 'CustomerReservations', 'state', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(332, '', 'Puebla', 'SET', 'CustomerReservations', 'city', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(333, '', 'x internet', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(334, '', '(222) 615-1048', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(335, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(336, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(337, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(338, '', '7', 'SET', 'CustomerReservations', 'id', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(339, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(340, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(341, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(342, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(343, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(344, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 17:24:50', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(345, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(346, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(347, '', '12', 'SET', 'Reservation', 'room_id', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(348, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(349, '', '2013-12-30 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(350, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(351, '', '', 'SET', 'Reservation', 'children', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(352, '', '1', 'SET', 'Reservation', 'pets', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(353, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(354, '', '4', 'SET', 'Reservation', 'nights', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(355, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(356, '', '4', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(357, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(358, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(359, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(360, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(361, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(362, '', '4800', 'SET', 'Reservation', 'price', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(363, '', '7', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(364, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(365, '', '10', 'SET', 'Reservation', 'id', '2013-12-11 17:24:50', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(366, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(367, '', 'viortiz@live.com.mx', 'SET', 'CustomerReservations', 'email', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(368, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(369, '', 'Violeta Adriana', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(370, '', 'Ortiz Alvarado', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(371, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(372, '', 'Toluca', 'SET', 'CustomerReservations', 'state', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(373, '', 'Toluca', 'SET', 'CustomerReservations', 'city', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(374, '', 'ya se ha hospedado anteriormente', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(375, '', '(722) 278-0086', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(376, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(377, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(378, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(379, '', '8', 'SET', 'CustomerReservations', 'id', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(380, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(381, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(382, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(383, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(384, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(385, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 17:32:05', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(386, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(387, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(388, '', '6', 'SET', 'Reservation', 'room_id', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(389, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(390, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(391, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(392, '', '', 'SET', 'Reservation', 'children', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(393, '', '0', 'SET', 'Reservation', 'pets', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(394, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(395, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(396, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(397, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(398, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(399, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(400, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(401, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(402, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(403, '', '3600', 'SET', 'Reservation', 'price', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(404, '', '8', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(405, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(406, '', '11', 'SET', 'Reservation', 'id', '2013-12-11 17:32:05', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(407, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(408, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(409, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(410, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(411, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(412, '', '3', 'SET', 'Reservation', 'adults', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(413, '', '1', 'SET', 'Reservation', 'children', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(414, '', '0', 'SET', 'Reservation', 'pets', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(415, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(416, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(417, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(418, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(419, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(420, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(421, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(422, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(423, '', '1000.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(424, '', '3000', 'SET', 'Reservation', 'price', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(425, '', '8', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(426, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(427, '', '12', 'SET', 'Reservation', 'id', '2013-12-11 17:32:05', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(428, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(429, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(430, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(431, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(432, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(433, '', '3', 'SET', 'Reservation', 'adults', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(434, '', '2', 'SET', 'Reservation', 'children', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(435, '', '0', 'SET', 'Reservation', 'pets', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(436, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(437, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(438, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(439, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(440, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(441, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(442, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(443, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(444, '', '1000.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(445, '', '3000', 'SET', 'Reservation', 'price', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(446, '', '8', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(447, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(448, '', '13', 'SET', 'Reservation', 'id', '2013-12-11 17:32:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(449, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(450, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(451, '', '3', 'SET', 'Reservation', 'room_id', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(452, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(453, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(454, '', '3', 'SET', 'Reservation', 'adults', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(455, '', '1', 'SET', 'Reservation', 'children', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(456, '', '0', 'SET', 'Reservation', 'pets', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(457, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(458, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(459, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(460, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(461, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(462, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(463, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(464, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(465, '', '1000.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(466, '', '3000', 'SET', 'Reservation', 'price', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(467, '', '8', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(468, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(469, '', '14', 'SET', 'Reservation', 'id', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(470, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(471, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(472, '', '4', 'SET', 'Reservation', 'room_id', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(473, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(474, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(475, '', '3', 'SET', 'Reservation', 'adults', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(476, '', '1', 'SET', 'Reservation', 'children', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(477, '', '0', 'SET', 'Reservation', 'pets', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(478, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(479, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(480, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(481, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(482, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(483, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(484, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(485, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(486, '', '1000.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(487, '', '3000', 'SET', 'Reservation', 'price', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(488, '', '8', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(489, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(490, '', '15', 'SET', 'Reservation', 'id', '2013-12-11 17:32:05', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(491, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(492, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(493, '', '5', 'SET', 'Reservation', 'room_id', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(494, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(495, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(496, '', '2', 'SET', 'Reservation', 'adults', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(497, '', '2', 'SET', 'Reservation', 'children', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(498, '', '0', 'SET', 'Reservation', 'pets', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(499, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(500, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(501, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(502, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(503, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(504, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(505, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(506, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(507, '', '850.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(508, '', '2550', 'SET', 'Reservation', 'price', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(509, '', '8', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(510, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(511, '', '16', 'SET', 'Reservation', 'id', '2013-12-11 17:32:05', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(512, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(513, '', 'viortiz@live.com.mx', 'SET', 'Customers', 'email', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(514, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(515, '', 'Violeta Adriana', 'SET', 'Customers', 'first_name', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(516, '', 'Ortiz Alvarado', 'SET', 'Customers', 'last_name', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(517, '', 'Mexico', 'SET', 'Customers', 'country', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(518, '', 'Toluca', 'SET', 'Customers', 'state', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(519, '', 'Toluca', 'SET', 'Customers', 'city', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(520, '', 'ya se ha hospedado anteriormente', 'SET', 'Customers', 'how_find_us', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(521, '', '(722) 278-0086', 'SET', 'Customers', 'home_phone', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(522, '', '', 'SET', 'Customers', 'work_phone', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(523, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(524, '', '14', 'SET', 'Customers', 'id', '2013-12-11 17:32:05', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(525, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(526, '', 'iafs1968@hotmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(527, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(528, '', 'Ivan ', 'SET', 'CustomerReservations', 'first_name', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(529, '', 'Falcon', 'SET', 'CustomerReservations', 'last_name', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(530, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(531, '', 'DF', 'SET', 'CustomerReservations', 'state', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(532, '', 'DF', 'SET', 'CustomerReservations', 'city', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(533, '', 'x internet', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(534, '', 'Favor de Proporcionar', 'SET', 'CustomerReservations', 'home_phone', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(535, '', 'Favor de Proporcionar', 'SET', 'CustomerReservations', 'work_phone', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(536, '', '045-551-451-1085', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(537, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(538, '', '9', 'SET', 'CustomerReservations', 'id', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(539, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(540, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(541, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(542, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(543, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(544, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-11 17:38:53', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(545, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(546, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(547, '', '7', 'SET', 'Reservation', 'room_id', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(548, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(549, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(550, '', '3', 'SET', 'Reservation', 'adults', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(551, '', '1', 'SET', 'Reservation', 'children', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(552, '', '0', 'SET', 'Reservation', 'pets', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(553, '', '1', 'SET', 'Reservation', 'statux', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(554, '', '3', 'SET', 'Reservation', 'nights', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(555, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(556, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(557, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(558, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(559, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(560, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(561, '', '1350.00', 'SET', 'Reservation', 'price_ta', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(562, '', '4050', 'SET', 'Reservation', 'price', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(563, '', '9', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(564, '', '', 'SET', 'Reservation', 'description', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(565, '', '17', 'SET', 'Reservation', 'id', '2013-12-11 17:38:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(566, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(567, '', 'iafs1968@hotmail.com', 'SET', 'Customers', 'email', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(568, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(569, '', 'Ivan ', 'SET', 'Customers', 'first_name', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(570, '', 'Falcon', 'SET', 'Customers', 'last_name', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(571, '', 'Mexico', 'SET', 'Customers', 'country', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(572, '', 'DF', 'SET', 'Customers', 'state', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(573, '', 'DF', 'SET', 'Customers', 'city', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(574, '', 'x internet', 'SET', 'Customers', 'how_find_us', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(575, '', 'Favor de Proporcionar', 'SET', 'Customers', 'home_phone', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(576, '', 'Favor de Proporcionar', 'SET', 'Customers', 'work_phone', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(577, '', '045-551-451-1085', 'SET', 'Customers', 'cell_phone', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(578, '', '15', 'SET', 'Customers', 'id', '2013-12-11 17:38:53', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(579, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(580, '', 'lzanella@asf.gob.mx', 'SET', 'CustomerReservations', 'email', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(581, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(582, '', 'Lizbeth', 'SET', 'CustomerReservations', 'first_name', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(583, '', 'Zanella Pedrera', 'SET', 'CustomerReservations', 'last_name', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(584, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(585, '', 'Cd. de Mexico', 'SET', 'CustomerReservations', 'state', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(586, '', 'Cd de Mexico', 'SET', 'CustomerReservations', 'city', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(587, '', 'x internet', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(588, '', '01-555-200-1594', 'SET', 'CustomerReservations', 'home_phone', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(589, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(590, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(591, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(592, '', '10', 'SET', 'CustomerReservations', 'id', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(593, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(594, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(595, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-12 08:20:51', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(596, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-12 08:20:52', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(597, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-12 08:20:52', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(598, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-12 08:20:52', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(599, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(600, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(601, '', '11', 'SET', 'Reservation', 'room_id', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(602, '', '2013-12-26 15:00', 'SET', 'Reservation', 'checkin', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(603, '', '2013-12-29 13:00', 'SET', 'Reservation', 'checkout', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(604, '', '3', 'SET', 'Reservation', 'adults', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(605, '', '', 'SET', 'Reservation', 'children', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(606, '', '3', 'SET', 'Reservation', 'pets', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(607, '', '1', 'SET', 'Reservation', 'statux', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(608, '', '3', 'SET', 'Reservation', 'nights', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(609, '', '3', 'SET', 'Reservation', 'totalpax', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(610, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(611, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(612, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(613, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(614, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(615, '', '1350.00', 'SET', 'Reservation', 'price_ta', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(616, '', '4350', 'SET', 'Reservation', 'price', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(617, '', '10', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(618, '', '', 'SET', 'Reservation', 'description', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(619, '', '18', 'SET', 'Reservation', 'id', '2013-12-12 08:20:52', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(620, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(621, '', 'lzanella@asf.gob.mx', 'SET', 'Customers', 'email', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(622, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(623, '', 'Lizbeth', 'SET', 'Customers', 'first_name', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(624, '', 'Zanella Pedrera', 'SET', 'Customers', 'last_name', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(625, '', 'Mexico', 'SET', 'Customers', 'country', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(626, '', 'Cd. de Mexico', 'SET', 'Customers', 'state', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(627, '', 'Cd de Mexico', 'SET', 'Customers', 'city', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(628, '', 'x internet', 'SET', 'Customers', 'how_find_us', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(629, '', '01-555-200-1594', 'SET', 'Customers', 'home_phone', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(630, '', '', 'SET', 'Customers', 'work_phone', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(631, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(632, '', '16', 'SET', 'Customers', 'id', '2013-12-12 08:20:52', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(633, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(634, '', 'jose.angel.velazco@gmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(635, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(636, '', 'Jose Angel', 'SET', 'CustomerReservations', 'first_name', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(637, '', 'Velazco Ornelas', 'SET', 'CustomerReservations', 'last_name', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(638, '', 'Mexico', 'SET', 'CustomerReservations', 'country', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(639, '', 'DF', 'SET', 'CustomerReservations', 'state', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(640, '', 'DF', 'SET', 'CustomerReservations', 'city', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(641, '', 'Ya se ha hospedado antes', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(642, '', '556-364-1602', 'SET', 'CustomerReservations', 'home_phone', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(643, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(644, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(645, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(646, '', '11', 'SET', 'CustomerReservations', 'id', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(647, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(648, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(649, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(650, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(651, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(652, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-12 08:47:01', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(653, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(654, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(655, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(656, '', '2013-12-29 15:00', 'SET', 'Reservation', 'checkin', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(657, '', '2014-01-02 13:00', 'SET', 'Reservation', 'checkout', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(658, '', '2', 'SET', 'Reservation', 'adults', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(659, '', '2', 'SET', 'Reservation', 'children', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(660, '', '2', 'SET', 'Reservation', 'pets', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(661, '', '1', 'SET', 'Reservation', 'statux', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(662, '', '4', 'SET', 'Reservation', 'nights', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(663, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(664, '', '4', 'SET', 'Reservation', 'nigth_ta', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(665, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(666, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(667, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(668, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(669, '', '850.00', 'SET', 'Reservation', 'price_ta', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(670, '', '3400', 'SET', 'Reservation', 'price', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(671, '', '11', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(672, '', '', 'SET', 'Reservation', 'description', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(673, '', '19', 'SET', 'Reservation', 'id', '2013-12-12 08:47:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(674, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(675, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(676, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(677, '', '2013-12-29 15:00', 'SET', 'Reservation', 'checkin', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(678, '', '2014-01-02 13:00', 'SET', 'Reservation', 'checkout', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(679, '', '2', 'SET', 'Reservation', 'adults', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(680, '', '2', 'SET', 'Reservation', 'children', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(681, '', '2', 'SET', 'Reservation', 'pets', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(682, '', '1', 'SET', 'Reservation', 'statux', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(683, '', '4', 'SET', 'Reservation', 'nights', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(684, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(685, '', '4', 'SET', 'Reservation', 'nigth_ta', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(686, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(687, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(688, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(689, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(690, '', '850.00', 'SET', 'Reservation', 'price_ta', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(691, '', '3400', 'SET', 'Reservation', 'price', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(692, '', '11', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(693, '', '', 'SET', 'Reservation', 'description', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(694, '', '20', 'SET', 'Reservation', 'id', '2013-12-12 08:47:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(695, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(696, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(697, '', '6', 'SET', 'Reservation', 'room_id', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(698, '', '2013-12-29 15:00', 'SET', 'Reservation', 'checkin', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(699, '', '2014-01-02 13:00', 'SET', 'Reservation', 'checkout', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(700, '', '2', 'SET', 'Reservation', 'adults', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(701, '', '2', 'SET', 'Reservation', 'children', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(702, '', '2', 'SET', 'Reservation', 'pets', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(703, '', '1', 'SET', 'Reservation', 'statux', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(704, '', '4', 'SET', 'Reservation', 'nights', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(705, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(706, '', '4', 'SET', 'Reservation', 'nigth_ta', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(707, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(708, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(709, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(710, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(711, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(712, '', '4800', 'SET', 'Reservation', 'price', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(713, '', '11', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(714, '', '', 'SET', 'Reservation', 'description', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(715, '', '21', 'SET', 'Reservation', 'id', '2013-12-12 08:47:02', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(716, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(717, '', 'jose.angel.velazco@gmail.com', 'SET', 'Customers', 'email', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(718, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(719, '', 'Jose Angel', 'SET', 'Customers', 'first_name', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(720, '', 'Velazco Ornelas', 'SET', 'Customers', 'last_name', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(721, '', 'Mexico', 'SET', 'Customers', 'country', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(722, '', 'DF', 'SET', 'Customers', 'state', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(723, '', 'DF', 'SET', 'Customers', 'city', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(724, '', 'Ya se ha hospedado antes', 'SET', 'Customers', 'how_find_us', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(725, '', '556-364-1602', 'SET', 'Customers', 'home_phone', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(726, '', '', 'SET', 'Customers', 'work_phone', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(727, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(728, '', '17', 'SET', 'Customers', 'id', '2013-12-12 08:47:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(729, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(730, '', 'eventos.cocoaventura@gmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(731, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(732, '', 'Ruth', 'SET', 'CustomerReservations', 'first_name', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(733, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(734, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(735, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(736, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(737, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(738, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(739, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(740, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(741, '', '', 'SET', 'CustomerReservations', 'see_discount', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(742, '', '12', 'SET', 'CustomerReservations', 'id', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(743, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(744, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(745, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(746, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(747, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(748, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-12 11:50:56', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(749, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(750, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(751, '', '8', 'SET', 'Reservation', 'room_id', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(752, '', '2013-12-16 15:00', 'SET', 'Reservation', 'checkin', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(753, '', '2013-12-21 13:00', 'SET', 'Reservation', 'checkout', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(754, '', '3', 'SET', 'Reservation', 'adults', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(755, '', '', 'SET', 'Reservation', 'children', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(756, '', '1', 'SET', 'Reservation', 'pets', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(757, '', '1', 'SET', 'Reservation', 'statux', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(758, '', '5', 'SET', 'Reservation', 'nights', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(759, '', '3', 'SET', 'Reservation', 'totalpax', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(760, '', '1', 'SET', 'Reservation', 'nigth_ta', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(761, '', '4', 'SET', 'Reservation', 'nigth_tb', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(762, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(763, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(764, '', '1100.00', 'SET', 'Reservation', 'price_tb', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(765, '', '1350.00', 'SET', 'Reservation', 'price_ta', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(766, '', '5750', 'SET', 'Reservation', 'price', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(767, '', '12', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(768, '', '', 'SET', 'Reservation', 'description', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(769, '', '22', 'SET', 'Reservation', 'id', '2013-12-12 11:50:56', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(770, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(771, '', 'eventos.cocoaventura@gmail.com', 'SET', 'CustomerReservations', 'email', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(772, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(773, '', 'Ruth Elena', 'SET', 'CustomerReservations', 'first_name', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(774, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(775, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(776, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(777, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(778, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(779, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(780, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(781, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(782, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(783, '', '13', 'SET', 'CustomerReservations', 'id', '2013-12-13 09:28:04', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(784, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-13 09:28:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(785, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-13 09:28:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(786, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-13 09:28:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(787, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-13 09:28:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(788, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-13 09:28:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(789, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-13 09:28:05', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(790, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(791, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(792, '', '11', 'SET', 'Reservation', 'room_id', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(793, '', '2013-12-19 15:00', 'SET', 'Reservation', 'checkin', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(794, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(795, '', '3', 'SET', 'Reservation', 'adults', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(796, '', '', 'SET', 'Reservation', 'children', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(797, '', '2', 'SET', 'Reservation', 'pets', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(798, '', '1', 'SET', 'Reservation', 'statux', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(799, '', '1', 'SET', 'Reservation', 'nights', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(800, '', '3', 'SET', 'Reservation', 'totalpax', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(801, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(802, '', '1', 'SET', 'Reservation', 'nigth_tb', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(803, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(804, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(805, '', '1100.00', 'SET', 'Reservation', 'price_tb', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(806, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(807, '', '1100', 'SET', 'Reservation', 'price', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(808, '', '13', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(809, '', '', 'SET', 'Reservation', 'description', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(810, '', '23', 'SET', 'Reservation', 'id', '2013-12-13 09:28:05', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(811, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(812, '', 'moranmc@gmail.com', 'SET', 'Customers', 'email', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(813, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(814, '', 'CONCEPCION', 'SET', 'Customers', 'first_name', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(815, '', 'MORAN MARTINEZ', 'SET', 'Customers', 'last_name', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(816, '', 'MEXICO', 'SET', 'Customers', 'country', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(817, '', 'DF', 'SET', 'Customers', 'state', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(818, '', 'DF', 'SET', 'Customers', 'city', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(819, '', 'POR INTERNET', 'SET', 'Customers', 'how_find_us', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(820, '', '555-677-6289', 'SET', 'Customers', 'home_phone', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(821, '', '', 'SET', 'Customers', 'work_phone', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(822, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(823, '', '21', 'SET', 'Customers', 'id', '2013-12-16 15:28:40', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(824, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(825, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(826, '', '21', 'SET', 'CustomerReservations', 'customer_id', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(827, '', '14', 'SET', 'CustomerReservations', 'id', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(828, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(829, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(830, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(831, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(832, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(833, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(834, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(835, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(836, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(837, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(838, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(839, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(840, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(841, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(842, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(843, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(844, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-16 15:28:40', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(845, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(846, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(847, '', '7', 'SET', 'Reservation', 'room_id', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(848, '', '2013-12-16 15:00', 'SET', 'Reservation', 'checkin', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(849, '', '2013-12-21 13:00', 'SET', 'Reservation', 'checkout', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(850, '', '2', 'SET', 'Reservation', 'adults', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(851, '', '2', 'SET', 'Reservation', 'children', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(852, '', '1', 'SET', 'Reservation', 'pets', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(853, '', '1', 'SET', 'Reservation', 'statux', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(854, '', '5', 'SET', 'Reservation', 'nights', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(855, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(856, '', '1', 'SET', 'Reservation', 'nigth_ta', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(857, '', '4', 'SET', 'Reservation', 'nigth_tb', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(858, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(859, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(860, '', '1000.00', 'SET', 'Reservation', 'price_tb', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(861, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(862, '', '5200', 'SET', 'Reservation', 'price', '2013-12-16 15:28:40', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(863, '', '14', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-16 15:28:41', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(864, '', '', 'SET', 'Reservation', 'description', '2013-12-16 15:28:41', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(865, '', '24', 'SET', 'Reservation', 'id', '2013-12-16 15:28:41', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(866, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(867, '', 'luishojeda@hotmail.com', 'SET', 'Customers', 'email', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(868, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(869, '', 'pruebA', 'SET', 'Customers', 'first_name', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(870, '', 'prueba', 'SET', 'Customers', 'last_name', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(871, '', 'prueba', 'SET', 'Customers', 'country', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(872, '', 'prueba', 'SET', 'Customers', 'state', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(873, '', 'prueba', 'SET', 'Customers', 'city', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(874, '', 'esto es una prueba', 'SET', 'Customers', 'how_find_us', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(875, '', '9982389217', 'SET', 'Customers', 'home_phone', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(876, '', '', 'SET', 'Customers', 'work_phone', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(877, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(878, '', '22', 'SET', 'Customers', 'id', '2013-12-16 22:04:52', 1, '22');
INSERT INTO `tbl_audit_trail` VALUES(879, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(880, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(881, '', '22', 'SET', 'CustomerReservations', 'customer_id', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(882, '', '15', 'SET', 'CustomerReservations', 'id', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(883, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(884, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(885, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(886, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(887, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(888, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(889, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(890, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(891, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(892, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(893, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(894, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(895, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(896, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(897, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(898, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(899, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-16 22:04:52', 1, '15');
INSERT INTO `tbl_audit_trail` VALUES(900, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(901, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(902, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(903, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(904, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(905, '', '4', 'SET', 'Reservation', 'adults', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(906, '', '1', 'SET', 'Reservation', 'children', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(907, '', '2', 'SET', 'Reservation', 'pets', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(908, '', '1', 'SET', 'Reservation', 'statux', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(909, '', '2', 'SET', 'Reservation', 'nights', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(910, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(911, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(912, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(913, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(914, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(915, '', '900.00', 'SET', 'Reservation', 'price_tb', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(916, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(917, '', '1800', 'SET', 'Reservation', 'price', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(918, '', '15', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(919, '', '', 'SET', 'Reservation', 'description', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(920, '', '25', 'SET', 'Reservation', 'id', '2013-12-16 22:04:52', 1, '25');
INSERT INTO `tbl_audit_trail` VALUES(921, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(922, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(923, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(924, '', '16', 'SET', 'CustomerReservations', 'id', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(925, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(926, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(927, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(928, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(929, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(930, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(931, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(932, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(933, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(934, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(935, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(936, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(937, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(938, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(939, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(940, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(941, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 08:47:33', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(942, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(943, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(944, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(945, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(946, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(947, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(948, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(949, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(950, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(951, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(952, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(953, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(954, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(955, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(956, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(957, '', '800.00', 'SET', 'Reservation', 'price_tb', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(958, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(959, '', '1800', 'SET', 'Reservation', 'price', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(960, '', '16', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(961, '', '', 'SET', 'Reservation', 'description', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(962, '', '26', 'SET', 'Reservation', 'id', '2013-12-17 08:47:33', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(963, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(964, '', 'eventos@gmail.com', 'SET', 'Customers', 'email', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(965, '', 'lee_geing@hotmail.com', 'SET', 'Customers', 'alternative_email', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(966, '', 'cocoaventura', 'SET', 'Customers', 'first_name', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(967, '', 'cocoaventura', 'SET', 'Customers', 'last_name', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(968, '', 'cocoaVENTURA', 'SET', 'Customers', 'country', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(969, '', 'cocoaventura', 'SET', 'Customers', 'state', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(970, '', 'cocoaventura', 'SET', 'Customers', 'city', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(971, '', 'cocoaventura', 'SET', 'Customers', 'how_find_us', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(972, '', '9982389217', 'SET', 'Customers', 'home_phone', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(973, '', '9982389217', 'SET', 'Customers', 'work_phone', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(974, '', '9982389217', 'SET', 'Customers', 'cell_phone', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(975, '', '23', 'SET', 'Customers', 'id', '2013-12-17 08:57:52', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(976, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(977, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(978, '', '23', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(979, '', '17', 'SET', 'CustomerReservations', 'id', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(980, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(981, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(982, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(983, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 08:57:52', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(984, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(985, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(986, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(987, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(988, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(989, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(990, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(991, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(992, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(993, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(994, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(995, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(996, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 08:57:53', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(997, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(998, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(999, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1000, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1001, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1002, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1003, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1004, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1005, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1006, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1007, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1008, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1009, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1010, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1011, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1012, '', '800.00', 'SET', 'Reservation', 'price_tb', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1013, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1014, '', '1800', 'SET', 'Reservation', 'price', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1015, '', '17', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1016, '', '', 'SET', 'Reservation', 'description', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1017, '', '27', 'SET', 'Reservation', 'id', '2013-12-17 08:57:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1018, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1019, '', 'chinux.suse@gmail.com', 'SET', 'Customers', 'email', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1020, '', 'lee_geing@hotmail.com', 'SET', 'Customers', 'alternative_email', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1021, '', 'luis', 'SET', 'Customers', 'first_name', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1022, '', 'ojeds', 'SET', 'Customers', 'last_name', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1023, '', 'mexico', 'SET', 'Customers', 'country', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1024, '', 'quintanaroo', 'SET', 'Customers', 'state', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1025, '', 'cancun', 'SET', 'Customers', 'city', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1026, '', 'por intenet', 'SET', 'Customers', 'how_find_us', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1027, '', '9982389217', 'SET', 'Customers', 'home_phone', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1028, '', '', 'SET', 'Customers', 'work_phone', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1029, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1030, '', '24', 'SET', 'Customers', 'id', '2013-12-17 09:00:15', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1031, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1032, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1033, '', '24', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1034, '', '18', 'SET', 'CustomerReservations', 'id', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1035, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1036, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1037, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1038, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1039, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1040, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1041, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1042, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1043, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1044, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1045, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1046, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1047, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1048, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1049, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1050, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1051, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 09:00:15', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1052, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1053, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1054, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1055, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1056, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1057, '', '2', 'SET', 'Reservation', 'adults', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1058, '', '3', 'SET', 'Reservation', 'children', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1059, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1060, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1061, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1062, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1063, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1064, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1065, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1066, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1067, '', '800.00', 'SET', 'Reservation', 'price_tb', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1068, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1069, '', '1800', 'SET', 'Reservation', 'price', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1070, '', '18', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1071, '', '', 'SET', 'Reservation', 'description', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1072, '', '28', 'SET', 'Reservation', 'id', '2013-12-17 09:00:15', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1073, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1074, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1075, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1076, '', '19', 'SET', 'CustomerReservations', 'id', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1077, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1078, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1079, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1080, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1081, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1082, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1083, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1084, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1085, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1086, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1087, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1088, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1089, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1090, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1091, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1092, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1093, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 10:06:57', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1094, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1095, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1096, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1097, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1098, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1099, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1100, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1101, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1102, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1103, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1104, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1105, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1106, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1107, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1108, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1109, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1110, '', '1000.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1111, '', '2200', 'SET', 'Reservation', 'price', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1112, '', '19', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1113, '', '', 'SET', 'Reservation', 'description', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1114, '', '29', 'SET', 'Reservation', 'id', '2013-12-17 10:06:57', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(1115, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1116, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1117, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1118, '', '20', 'SET', 'CustomerReservations', 'id', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1119, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1120, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1121, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1122, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1123, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1124, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1125, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1126, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1127, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1128, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1129, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1130, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1131, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1132, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1133, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1134, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1135, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 10:42:01', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1136, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1137, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1138, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1139, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1140, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1141, '', '2', 'SET', 'Reservation', 'adults', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1142, '', '', 'SET', 'Reservation', 'children', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1143, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1144, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1145, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1146, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1147, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1148, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1149, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1150, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1151, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1152, '', '850.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1153, '', '1900', 'SET', 'Reservation', 'price', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1154, '', '20', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1155, '', '', 'SET', 'Reservation', 'description', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1156, '', '30', 'SET', 'Reservation', 'id', '2013-12-17 10:42:02', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1157, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1158, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1159, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1160, '', '21', 'SET', 'CustomerReservations', 'id', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1161, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1162, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1163, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1164, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1165, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1166, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1167, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1168, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1169, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1170, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1171, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1172, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1173, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1174, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1175, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1176, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1177, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 10:47:16', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1178, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1179, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1180, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1181, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1182, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1183, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1184, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1185, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1186, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1187, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1188, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1189, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1190, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1191, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1192, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1193, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1194, '', '1000.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1195, '', '2200', 'SET', 'Reservation', 'price', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1196, '', '21', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1197, '', '', 'SET', 'Reservation', 'description', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1198, '', '31', 'SET', 'Reservation', 'id', '2013-12-17 10:47:16', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1199, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1200, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1201, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1202, '', '22', 'SET', 'CustomerReservations', 'id', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1203, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1204, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1205, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1206, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1207, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1208, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1209, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1210, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1211, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1212, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1213, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1214, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1215, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1216, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1217, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1218, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1219, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 10:51:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1220, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1221, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1222, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1223, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1224, '', '2013-12-21 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1225, '', '2', 'SET', 'Reservation', 'adults', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1226, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1227, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1228, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1229, '', '1', 'SET', 'Reservation', 'nights', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1230, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1231, '', '1', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1232, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1233, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1234, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1235, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1236, '', '850.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1237, '', '950', 'SET', 'Reservation', 'price', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1238, '', '22', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1239, '', '', 'SET', 'Reservation', 'description', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1240, '', '32', 'SET', 'Reservation', 'id', '2013-12-17 10:51:24', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1241, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1242, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1243, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1244, '', '23', 'SET', 'CustomerReservations', 'id', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1245, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1246, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1247, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1248, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1249, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1250, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1251, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1252, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1253, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1254, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1255, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1256, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1257, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1258, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1259, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1260, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1261, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 10:55:27', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1262, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1263, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1264, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1265, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1266, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1267, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1268, '', '', 'SET', 'Reservation', 'children', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1269, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1270, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1271, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1272, '', '3', 'SET', 'Reservation', 'totalpax', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1273, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1274, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1275, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1276, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1277, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1278, '', '1000.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1279, '', '2200', 'SET', 'Reservation', 'price', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1280, '', '23', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1281, '', '', 'SET', 'Reservation', 'description', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1282, '', '33', 'SET', 'Reservation', 'id', '2013-12-17 10:55:27', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(1283, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1284, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1285, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1286, '', '24', 'SET', 'CustomerReservations', 'id', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1287, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1288, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1289, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1290, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1291, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1292, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1293, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1294, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1295, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1296, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1297, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1298, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1299, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1300, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1301, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1302, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1303, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 11:59:57', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1304, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1305, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1306, '', '8', 'SET', 'Reservation', 'room_id', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1307, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1308, '', '2013-12-25 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1309, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1310, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1311, '', '2', 'SET', 'Reservation', 'pets', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1312, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1313, '', '5', 'SET', 'Reservation', 'nights', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1314, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1315, '', '5', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1316, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1317, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1318, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1319, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1320, '', '1350.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1321, '', '6750', 'SET', 'Reservation', 'price', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1322, '', '24', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1323, '', '', 'SET', 'Reservation', 'description', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1324, '', '34', 'SET', 'Reservation', 'id', '2013-12-17 11:59:58', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(1325, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1326, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1327, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1328, '', '25', 'SET', 'CustomerReservations', 'id', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1329, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1330, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1331, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1332, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1333, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1334, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1335, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1336, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1337, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1338, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1339, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1340, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1341, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1342, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1343, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1344, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1345, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 14:21:04', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(1346, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1347, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1348, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1349, '', '2013-12-25 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1350, '', '2013-12-28 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1351, '', '4', 'SET', 'Reservation', 'adults', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1352, '', '1', 'SET', 'Reservation', 'children', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1353, '', '4', 'SET', 'Reservation', 'pets', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1354, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1355, '', '3', 'SET', 'Reservation', 'nights', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1356, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1357, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1358, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1359, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1360, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1361, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1362, '', '1150.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1363, '', '4050', 'SET', 'Reservation', 'price', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1364, '', '25', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1365, '', '', 'SET', 'Reservation', 'description', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1366, '', '35', 'SET', 'Reservation', 'id', '2013-12-17 14:21:05', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(1367, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1368, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1369, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1370, '', '26', 'SET', 'CustomerReservations', 'id', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1371, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1372, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1373, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1374, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1375, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1376, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1377, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1378, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1379, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1380, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1381, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1382, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1383, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1384, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1385, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1386, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1387, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 14:31:04', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1388, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1389, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1390, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1391, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1392, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1393, '', '2', 'SET', 'Reservation', 'adults', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1394, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1395, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1396, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1397, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1398, '', '4', 'SET', 'Reservation', 'totalpax', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1399, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1400, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1401, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1402, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1403, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1404, '', '850.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1405, '', '1900', 'SET', 'Reservation', 'price', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1406, '', '26', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1407, '', '', 'SET', 'Reservation', 'description', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1408, '', '36', 'SET', 'Reservation', 'id', '2013-12-17 14:31:05', 1, '36');
INSERT INTO `tbl_audit_trail` VALUES(1409, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1410, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1411, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1412, '', '27', 'SET', 'CustomerReservations', 'id', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1413, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1414, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1415, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1416, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1417, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1418, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1419, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1420, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1421, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1422, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1423, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1424, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1425, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1426, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1427, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1428, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1429, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 14:40:15', 3, '27');
INSERT INTO `tbl_audit_trail` VALUES(1430, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1431, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1432, '', '8', 'SET', 'Reservation', 'room_id', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1433, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1434, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1435, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1436, '', '', 'SET', 'Reservation', 'children', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1437, '', '2', 'SET', 'Reservation', 'pets', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1438, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1439, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1440, '', '3', 'SET', 'Reservation', 'totalpax', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1441, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1442, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1443, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1444, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1445, '', '1100.00', 'SET', 'Reservation', 'price_tb', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1446, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1447, '', '2200', 'SET', 'Reservation', 'price', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1448, '', '27', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1449, '', '', 'SET', 'Reservation', 'description', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1450, '', '37', 'SET', 'Reservation', 'id', '2013-12-17 14:40:15', 3, '37');
INSERT INTO `tbl_audit_trail` VALUES(1451, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-17 14:46:23', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1452, '', 'cocoaventura@gmail.com', 'SET', 'Customers', 'email', '2013-12-17 14:46:23', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1453, '', 'cocoaventura@gmail.com', 'SET', 'Customers', 'alternative_email', '2013-12-17 14:46:23', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1454, '', 'Andrea ', 'SET', 'Customers', 'first_name', '2013-12-17 14:46:23', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1455, '', 'Ramírez', 'SET', 'Customers', 'last_name', '2013-12-17 14:46:23', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1456, '', '', 'SET', 'Customers', 'country', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1457, '', '', 'SET', 'Customers', 'state', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1458, '', '', 'SET', 'Customers', 'city', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1459, '', '', 'SET', 'Customers', 'how_find_us', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1460, '', '9-21-26-26', 'SET', 'Customers', 'home_phone', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1461, '', '', 'SET', 'Customers', 'work_phone', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1462, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1463, '', '25', 'SET', 'Customers', 'id', '2013-12-17 14:46:24', 3, '25');
INSERT INTO `tbl_audit_trail` VALUES(1464, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1465, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1466, '', '25', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1467, '', '28', 'SET', 'CustomerReservations', 'id', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1468, '', '', 'SET', 'CustomerReservations', 'email', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1469, '', '', 'SET', 'CustomerReservations', 'alternative_email', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1470, '', '', 'SET', 'CustomerReservations', 'first_name', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1471, '', '', 'SET', 'CustomerReservations', 'last_name', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1472, '', '', 'SET', 'CustomerReservations', 'country', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1473, '', '', 'SET', 'CustomerReservations', 'state', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1474, '', '', 'SET', 'CustomerReservations', 'city', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1475, '', '', 'SET', 'CustomerReservations', 'how_find_us', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1476, '', '', 'SET', 'CustomerReservations', 'home_phone', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1477, '', '', 'SET', 'CustomerReservations', 'work_phone', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1478, '', '', 'SET', 'CustomerReservations', 'cell_phone', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1479, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1480, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1481, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1482, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1483, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1484, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 14:46:24', 3, '28');
INSERT INTO `tbl_audit_trail` VALUES(1485, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1486, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1487, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1488, '', '2013-12-25 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1489, '', '2013-12-28 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1490, '', '5', 'SET', 'Reservation', 'adults', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1491, '', '', 'SET', 'Reservation', 'children', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1492, '', '0', 'SET', 'Reservation', 'pets', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1493, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1494, '', '3', 'SET', 'Reservation', 'nights', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1495, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1496, '', '3', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1497, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1498, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1499, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1500, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1501, '', '1300.00', 'SET', 'Reservation', 'price_ta', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1502, '', '3900', 'SET', 'Reservation', 'price', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1503, '', '28', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1504, '', '', 'SET', 'Reservation', 'description', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1505, '', '38', 'SET', 'Reservation', 'id', '2013-12-17 14:46:24', 3, '38');
INSERT INTO `tbl_audit_trail` VALUES(1506, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1507, '', 'lee_geing@hotmail.com', 'SET', 'Customers', 'email', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1508, '', 'chinuxe@gmail.com', 'SET', 'Customers', 'alternative_email', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1509, '', 'PRUEBA', 'SET', 'Customers', 'first_name', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1510, '', 'PRUEBA', 'SET', 'Customers', 'last_name', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1511, '', 'PRUEBA', 'SET', 'Customers', 'country', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1512, '', 'PRUEBA', 'SET', 'Customers', 'state', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1513, '', 'PRUEBA', 'SET', 'Customers', 'city', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1514, '', 'PRUEBA', 'SET', 'Customers', 'how_find_us', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1515, '', '9982389217', 'SET', 'Customers', 'home_phone', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1516, '', '', 'SET', 'Customers', 'work_phone', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1517, '', '', 'SET', 'Customers', 'cell_phone', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1518, '', '26', 'SET', 'Customers', 'id', '2013-12-17 15:12:48', 1, '26');
INSERT INTO `tbl_audit_trail` VALUES(1519, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1520, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1521, '', '26', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1522, '', '29', 'SET', 'CustomerReservations', 'id', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1523, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1524, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1525, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1526, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1527, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1528, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 15:12:48', 1, '29');
INSERT INTO `tbl_audit_trail` VALUES(1529, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1530, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1531, '', '2', 'SET', 'Reservation', 'room_id', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1532, '', '2013-12-18 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1533, '', '2013-12-20 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1534, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1535, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1536, '', '2', 'SET', 'Reservation', 'pets', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1537, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1538, '', '2', 'SET', 'Reservation', 'nights', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1539, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1540, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1541, '', '2', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1542, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1543, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1544, '', '800.00', 'SET', 'Reservation', 'price_tb', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1545, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1546, '', '1600', 'SET', 'Reservation', 'price', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1547, '', '29', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1548, '', '', 'SET', 'Reservation', 'description', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1549, '', '39', 'SET', 'Reservation', 'id', '2013-12-17 15:12:49', 1, '39');
INSERT INTO `tbl_audit_trail` VALUES(1550, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1551, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1552, '', '12', 'SET', 'CustomerReservations', 'customer_id', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1553, '', '30', 'SET', 'CustomerReservations', 'id', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1554, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1555, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1556, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1557, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1558, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1559, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-17 15:20:12', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(1560, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1561, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1562, '', '9', 'SET', 'Reservation', 'room_id', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1563, '', '2013-12-17 15:00', 'SET', 'Reservation', 'checkin', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1564, '', '2013-12-18 13:00', 'SET', 'Reservation', 'checkout', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1565, '', '3', 'SET', 'Reservation', 'adults', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1566, '', '2', 'SET', 'Reservation', 'children', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1567, '', '3', 'SET', 'Reservation', 'pets', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1568, '', '1', 'SET', 'Reservation', 'statux', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1569, '', '1', 'SET', 'Reservation', 'nights', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1570, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1571, '', '0', 'SET', 'Reservation', 'nigth_ta', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1572, '', '1', 'SET', 'Reservation', 'nigth_tb', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1573, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1574, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1575, '', '1100.00', 'SET', 'Reservation', 'price_tb', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1576, '', '0', 'SET', 'Reservation', 'price_ta', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1577, '', '1200', 'SET', 'Reservation', 'price', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1578, '', '30', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1579, '', '', 'SET', 'Reservation', 'description', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1580, '', '40', 'SET', 'Reservation', 'id', '2013-12-17 15:20:12', 4, '40');
INSERT INTO `tbl_audit_trail` VALUES(1581, 'ruthhh', 'ruth elena', 'CHANGE', 'Customers', 'first_name', '2013-12-17 15:23:19', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(1582, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1583, '', 'mrossy_76@live.com.mx', 'SET', 'Customers', 'email', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1584, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1585, '', 'Rocio', 'SET', 'Customers', 'first_name', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1586, '', 'Lopez', 'SET', 'Customers', 'last_name', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1587, '', 'Mexico', 'SET', 'Customers', 'country', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1588, '', 'Puebla', 'SET', 'Customers', 'state', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1589, '', 'puebla', 'SET', 'Customers', 'city', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1590, '', 'x internet', 'SET', 'Customers', 'how_find_us', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1591, '', '', 'SET', 'Customers', 'home_phone', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1592, '', '', 'SET', 'Customers', 'work_phone', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1593, '', '222-282-8692', 'SET', 'Customers', 'cell_phone', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1594, '', '27', 'SET', 'Customers', 'id', '2013-12-18 09:23:00', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(1595, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1596, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1597, '', '27', 'SET', 'CustomerReservations', 'customer_id', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1598, '', '31', 'SET', 'CustomerReservations', 'id', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1599, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1600, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1601, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1602, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1603, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1604, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-18 09:23:00', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(1605, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1606, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1607, '', '7', 'SET', 'Reservation', 'room_id', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1608, '', '2013-12-19 15:00', 'SET', 'Reservation', 'checkin', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1609, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1610, '', '5', 'SET', 'Reservation', 'adults', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1611, '', '', 'SET', 'Reservation', 'children', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1612, '', '0', 'SET', 'Reservation', 'pets', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1613, '', '1', 'SET', 'Reservation', 'statux', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1614, '', '3', 'SET', 'Reservation', 'nights', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1615, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1616, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1617, '', '1', 'SET', 'Reservation', 'nigth_tb', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1618, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1619, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1620, '', '1300.00', 'SET', 'Reservation', 'price_tb', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1621, '', '1650.00', 'SET', 'Reservation', 'price_ta', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1622, '', '4600', 'SET', 'Reservation', 'price', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1623, '', '31', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1624, '', '', 'SET', 'Reservation', 'description', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1625, '', '41', 'SET', 'Reservation', 'id', '2013-12-18 09:23:00', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(1626, '', '', 'CREATE', 'Customers', 'N/A', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1627, '', 'badjl0550@gmail.com', 'SET', 'Customers', 'email', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1628, '', '', 'SET', 'Customers', 'alternative_email', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1629, '', 'Jose Luis', 'SET', 'Customers', 'first_name', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1630, '', 'Badillo', 'SET', 'Customers', 'last_name', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1631, '', 'Mexico', 'SET', 'Customers', 'country', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1632, '', 'Favor de Proporcionar', 'SET', 'Customers', 'state', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1633, '', 'Favor de proporcionar', 'SET', 'Customers', 'city', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1634, '', 'x internetg', 'SET', 'Customers', 'how_find_us', '2013-12-18 09:40:55', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1635, '', '', 'SET', 'Customers', 'home_phone', '2013-12-18 09:40:56', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1636, '', '', 'SET', 'Customers', 'work_phone', '2013-12-18 09:40:56', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1637, '', 'Favor de Proporcionar ', 'SET', 'Customers', 'cell_phone', '2013-12-18 09:40:56', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1638, '', '28', 'SET', 'Customers', 'id', '2013-12-18 09:40:56', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(1639, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1640, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1641, '', '28', 'SET', 'CustomerReservations', 'customer_id', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1642, '', '32', 'SET', 'CustomerReservations', 'id', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1643, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1644, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1645, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1646, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1647, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1648, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-18 09:44:17', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(1649, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1650, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1651, '', '6', 'SET', 'Reservation', 'room_id', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1652, '', '2013-12-20 15:00', 'SET', 'Reservation', 'checkin', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1653, '', '2013-12-22 13:00', 'SET', 'Reservation', 'checkout', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1654, '', '2', 'SET', 'Reservation', 'adults', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1655, '', '', 'SET', 'Reservation', 'children', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1656, '', '0', 'SET', 'Reservation', 'pets', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1657, '', '1', 'SET', 'Reservation', 'statux', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1658, '', '2', 'SET', 'Reservation', 'nights', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1659, '', '2', 'SET', 'Reservation', 'totalpax', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1660, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1661, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1662, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1663, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1664, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1665, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1666, '', '2400', 'SET', 'Reservation', 'price', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1667, '', '32', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1668, '', '', 'SET', 'Reservation', 'description', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1669, '', '42', 'SET', 'Reservation', 'id', '2013-12-18 09:44:17', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(1670, '5', '7', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:02:37', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1671, '5', '7', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:06:40', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1672, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:27:14', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1673, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:27:14', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1674, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:27:14', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1675, '', '1', 'CHANGE', 'Prices', 'id', '2013-12-18 15:27:14', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1676, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:27:14', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1677, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:27:14', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1678, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:27:14', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1679, '', '2', 'CHANGE', 'Prices', 'id', '2013-12-18 15:27:14', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1680, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:27:14', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1681, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:27:14', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1682, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:27:14', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1683, '', '3', 'CHANGE', 'Prices', 'id', '2013-12-18 15:27:14', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1684, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:27:14', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1685, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:27:14', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1686, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:27:14', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1687, '', '4', 'CHANGE', 'Prices', 'id', '2013-12-18 15:27:14', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1688, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 15:27:14', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1689, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 15:27:14', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1690, '', '1500', 'SET', 'Prices', 'price', '2013-12-18 15:27:14', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1691, '', '89', 'SET', 'Prices', 'rate_id', '2013-12-18 15:27:14', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1692, '', '175', 'SET', 'Prices', 'id', '2013-12-18 15:27:14', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1693, '5', '7', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:29:04', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1694, '5', '7', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:29:25', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1695, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:33:53', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1696, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:34:40', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1697, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:34:40', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1698, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:34:40', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1699, '', '1', 'CHANGE', 'Prices', 'id', '2013-12-18 15:34:40', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1700, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:34:41', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1701, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:34:41', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1702, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:34:41', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1703, '', '2', 'CHANGE', 'Prices', 'id', '2013-12-18 15:34:41', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1704, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:34:41', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1705, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:34:41', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1706, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:34:41', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1707, '', '3', 'CHANGE', 'Prices', 'id', '2013-12-18 15:34:41', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1708, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:34:41', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1709, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:34:41', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1710, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:34:41', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1711, '', '4', 'CHANGE', 'Prices', 'id', '2013-12-18 15:34:41', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1712, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:34:41', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1713, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:34:41', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1714, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:34:41', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1715, '', '175', 'CHANGE', 'Prices', 'id', '2013-12-18 15:34:41', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1716, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 15:34:41', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1717, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 15:34:41', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1718, '', '1700', 'SET', 'Prices', 'price', '2013-12-18 15:34:41', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1719, '', '89', 'SET', 'Prices', 'rate_id', '2013-12-18 15:34:41', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1720, '', '176', 'SET', 'Prices', 'id', '2013-12-18 15:34:41', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1721, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 15:34:41', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1722, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 15:34:41', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1723, '', '1900', 'SET', 'Prices', 'price', '2013-12-18 15:34:41', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1724, '', '89', 'SET', 'Prices', 'rate_id', '2013-12-18 15:34:41', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1725, '', '177', 'SET', 'Prices', 'id', '2013-12-18 15:34:41', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1726, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:35:43', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1727, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:35:43', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1728, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:35:43', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1729, '', '5', 'CHANGE', 'Prices', 'id', '2013-12-18 15:35:43', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1730, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:35:43', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1731, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:35:43', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1732, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:35:43', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1733, '', '6', 'CHANGE', 'Prices', 'id', '2013-12-18 15:35:43', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1734, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:35:43', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1735, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:35:43', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1736, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:35:43', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1737, '', '7', 'CHANGE', 'Prices', 'id', '2013-12-18 15:35:43', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1738, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 15:35:43', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1739, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 15:35:43', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1740, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 15:35:43', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1741, '', '8', 'CHANGE', 'Prices', 'id', '2013-12-18 15:35:43', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1742, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 15:35:43', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1743, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 15:35:43', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1744, '', '1150', 'SET', 'Prices', 'price', '2013-12-18 15:35:43', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1745, '', '90', 'SET', 'Prices', 'rate_id', '2013-12-18 15:35:43', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1746, '', '178', 'SET', 'Prices', 'id', '2013-12-18 15:35:43', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1747, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 15:35:44', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1748, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 15:35:44', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1749, '', '1300', 'SET', 'Prices', 'price', '2013-12-18 15:35:44', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1750, '', '90', 'SET', 'Prices', 'rate_id', '2013-12-18 15:35:44', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1751, '', '179', 'SET', 'Prices', 'id', '2013-12-18 15:35:44', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1752, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 15:35:44', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1753, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 15:35:44', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1754, '', '1450', 'SET', 'Prices', 'price', '2013-12-18 15:35:44', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1755, '', '90', 'SET', 'Prices', 'rate_id', '2013-12-18 15:35:44', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1756, '', '180', 'SET', 'Prices', 'id', '2013-12-18 15:35:44', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1757, '7', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:40:12', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1758, '7', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:40:28', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1759, '7', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:40:44', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1760, '7', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:41:00', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1761, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:41:34', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1762, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:41:57', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1763, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:42:41', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1764, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:47:05', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(1765, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:52:06', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(1766, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:52:26', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(1767, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:52:44', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(1768, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:58:27', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(1769, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 15:59:56', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(1770, '5', '8', 'CHANGE', 'Rooms', 'capacity', '2013-12-18 16:00:15', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(1771, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1772, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:26', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1773, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1774, '', '1', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:26', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(1775, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1776, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:26', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1777, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1778, '', '2', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:26', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(1779, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1780, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:26', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1781, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1782, '', '3', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:26', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(1783, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1784, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:26', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1785, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1786, '', '4', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:26', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(1787, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1788, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:26', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1789, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1790, '', '175', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:26', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(1791, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1792, '', '1700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:26', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1793, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1794, '', '176', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:26', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(1795, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1796, '', '1900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:26', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1797, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1798, '', '177', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:26', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(1799, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:03:26', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(1800, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:03:26', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(1801, '', '850', 'SET', 'Prices', 'price', '2013-12-18 16:03:26', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(1802, '', '89', 'SET', 'Prices', 'rate_id', '2013-12-18 16:03:26', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(1803, '', '181', 'SET', 'Prices', 'id', '2013-12-18 16:03:26', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(1804, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1805, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:55', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1806, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1807, '', '5', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:55', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1808, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1809, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:55', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1810, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1811, '', '6', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:55', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1812, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1813, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:55', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1814, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1815, '', '7', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:55', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1816, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1817, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:55', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1818, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1819, '', '8', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:55', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1820, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1821, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:55', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1822, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1823, '', '178', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:55', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1824, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1825, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:55', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1826, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1827, '', '179', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:55', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1828, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1829, '', '1450.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:55', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1830, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1831, '', '180', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:55', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1832, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:03:55', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(1833, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:03:55', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(1834, '', '700', 'SET', 'Prices', 'price', '2013-12-18 16:03:55', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(1835, '', '90', 'SET', 'Prices', 'rate_id', '2013-12-18 16:03:55', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(1836, '', '182', 'SET', 'Prices', 'id', '2013-12-18 16:03:55', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(1837, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1838, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:56', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1839, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1840, '', '5', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:56', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(1841, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1842, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:56', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1843, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1844, '', '6', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:56', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(1845, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1846, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:56', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1847, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1848, '', '7', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:56', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(1849, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1850, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:56', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1851, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1852, '', '8', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:56', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(1853, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1854, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:56', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1855, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1856, '', '178', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:56', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(1857, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1858, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:56', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1859, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1860, '', '179', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:56', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(1861, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1862, '', '1450.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:03:56', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1863, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1864, '', '180', 'CHANGE', 'Prices', 'id', '2013-12-18 16:03:56', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(1865, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:03:56', 4, '183');
INSERT INTO `tbl_audit_trail` VALUES(1866, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:03:56', 4, '183');
INSERT INTO `tbl_audit_trail` VALUES(1867, '', '700', 'SET', 'Prices', 'price', '2013-12-18 16:03:56', 4, '183');
INSERT INTO `tbl_audit_trail` VALUES(1868, '', '90', 'SET', 'Prices', 'rate_id', '2013-12-18 16:03:56', 4, '183');
INSERT INTO `tbl_audit_trail` VALUES(1869, '', '183', 'SET', 'Prices', 'id', '2013-12-18 16:03:56', 4, '183');
INSERT INTO `tbl_audit_trail` VALUES(1870, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:05:32', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(1871, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:05:32', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(1872, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:05:32', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(1873, '', '9', 'CHANGE', 'Prices', 'id', '2013-12-18 16:05:32', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(1874, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:05:32', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(1875, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:05:32', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(1876, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:05:32', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(1877, '', '10', 'CHANGE', 'Prices', 'id', '2013-12-18 16:05:32', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(1878, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:05:32', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(1879, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:05:32', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(1880, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:05:32', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(1881, '', '11', 'CHANGE', 'Prices', 'id', '2013-12-18 16:05:32', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(1882, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:05:32', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(1883, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:05:32', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(1884, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:05:32', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(1885, '', '12', 'CHANGE', 'Prices', 'id', '2013-12-18 16:05:32', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(1886, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:05:32', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(1887, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:05:32', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(1888, '', '850', 'SET', 'Prices', 'price', '2013-12-18 16:05:32', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(1889, '', '91', 'SET', 'Prices', 'rate_id', '2013-12-18 16:05:32', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(1890, '', '184', 'SET', 'Prices', 'id', '2013-12-18 16:05:32', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(1891, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:05:32', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(1892, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 16:05:32', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(1893, '', '1500', 'SET', 'Prices', 'price', '2013-12-18 16:05:32', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(1894, '', '91', 'SET', 'Prices', 'rate_id', '2013-12-18 16:05:32', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(1895, '', '185', 'SET', 'Prices', 'id', '2013-12-18 16:05:32', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(1896, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:05:32', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(1897, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 16:05:32', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(1898, '', '1700', 'SET', 'Prices', 'price', '2013-12-18 16:05:32', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(1899, '', '91', 'SET', 'Prices', 'rate_id', '2013-12-18 16:05:32', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(1900, '', '186', 'SET', 'Prices', 'id', '2013-12-18 16:05:32', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(1901, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:05:32', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(1902, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 16:05:33', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(1903, '', '1900', 'SET', 'Prices', 'price', '2013-12-18 16:05:33', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(1904, '', '91', 'SET', 'Prices', 'rate_id', '2013-12-18 16:05:33', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(1905, '', '187', 'SET', 'Prices', 'id', '2013-12-18 16:05:33', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(1906, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(1907, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:06:59', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(1908, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(1909, '', '13', 'CHANGE', 'Prices', 'id', '2013-12-18 16:06:59', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(1910, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(1911, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:06:59', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(1912, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(1913, '', '14', 'CHANGE', 'Prices', 'id', '2013-12-18 16:06:59', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(1914, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(1915, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:06:59', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(1916, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(1917, '', '15', 'CHANGE', 'Prices', 'id', '2013-12-18 16:06:59', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(1918, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(1919, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:06:59', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(1920, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(1921, '', '16', 'CHANGE', 'Prices', 'id', '2013-12-18 16:06:59', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(1922, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:06:59', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(1923, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(1924, '', '1150', 'SET', 'Prices', 'price', '2013-12-18 16:06:59', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(1925, '', '92', 'SET', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(1926, '', '188', 'SET', 'Prices', 'id', '2013-12-18 16:06:59', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(1927, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:06:59', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(1928, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(1929, '', '1300', 'SET', 'Prices', 'price', '2013-12-18 16:06:59', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(1930, '', '92', 'SET', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(1931, '', '189', 'SET', 'Prices', 'id', '2013-12-18 16:06:59', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(1932, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:06:59', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(1933, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(1934, '', '1450', 'SET', 'Prices', 'price', '2013-12-18 16:06:59', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(1935, '', '92', 'SET', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(1936, '', '190', 'SET', 'Prices', 'id', '2013-12-18 16:06:59', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(1937, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:06:59', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(1938, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:06:59', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(1939, '', '700', 'SET', 'Prices', 'price', '2013-12-18 16:06:59', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(1940, '', '92', 'SET', 'Prices', 'rate_id', '2013-12-18 16:06:59', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(1941, '', '191', 'SET', 'Prices', 'id', '2013-12-18 16:06:59', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(1942, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(1943, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:08:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(1944, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(1945, '', '17', 'CHANGE', 'Prices', 'id', '2013-12-18 16:08:02', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(1946, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1947, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:08:02', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1948, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1949, '', '18', 'CHANGE', 'Prices', 'id', '2013-12-18 16:08:02', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(1950, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1951, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:08:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1952, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1953, '', '19', 'CHANGE', 'Prices', 'id', '2013-12-18 16:08:02', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(1954, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1955, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:08:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1956, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1957, '', '20', 'CHANGE', 'Prices', 'id', '2013-12-18 16:08:02', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(1958, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:08:02', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(1959, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(1960, '', '1500', 'SET', 'Prices', 'price', '2013-12-18 16:08:02', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(1961, '', '93', 'SET', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(1962, '', '192', 'SET', 'Prices', 'id', '2013-12-18 16:08:02', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(1963, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:08:02', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(1964, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(1965, '', '1700', 'SET', 'Prices', 'price', '2013-12-18 16:08:02', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(1966, '', '93', 'SET', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(1967, '', '193', 'SET', 'Prices', 'id', '2013-12-18 16:08:02', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(1968, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:08:02', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(1969, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(1970, '', '1900', 'SET', 'Prices', 'price', '2013-12-18 16:08:02', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(1971, '', '93', 'SET', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(1972, '', '194', 'SET', 'Prices', 'id', '2013-12-18 16:08:02', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(1973, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:08:02', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(1974, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:08:02', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(1975, '', '850', 'SET', 'Prices', 'price', '2013-12-18 16:08:02', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(1976, '', '93', 'SET', 'Prices', 'rate_id', '2013-12-18 16:08:02', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(1977, '', '195', 'SET', 'Prices', 'id', '2013-12-18 16:08:02', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(1978, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1979, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:10:20', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1980, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1981, '', '21', 'CHANGE', 'Prices', 'id', '2013-12-18 16:10:20', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(1982, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1983, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:10:20', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1984, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1985, '', '22', 'CHANGE', 'Prices', 'id', '2013-12-18 16:10:20', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(1986, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1987, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:10:20', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1988, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1989, '', '23', 'CHANGE', 'Prices', 'id', '2013-12-18 16:10:20', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(1990, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1991, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:10:20', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1992, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1993, '', '24', 'CHANGE', 'Prices', 'id', '2013-12-18 16:10:20', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(1994, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:10:20', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(1995, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(1996, '', '1150', 'SET', 'Prices', 'price', '2013-12-18 16:10:20', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(1997, '', '94', 'SET', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(1998, '', '196', 'SET', 'Prices', 'id', '2013-12-18 16:10:20', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(1999, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:10:20', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2000, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2001, '', '1300', 'SET', 'Prices', 'price', '2013-12-18 16:10:20', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2002, '', '94', 'SET', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2003, '', '197', 'SET', 'Prices', 'id', '2013-12-18 16:10:20', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2004, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:10:20', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2005, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2006, '', '1450', 'SET', 'Prices', 'price', '2013-12-18 16:10:20', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2007, '', '94', 'SET', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2008, '', '198', 'SET', 'Prices', 'id', '2013-12-18 16:10:20', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2009, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:10:20', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2010, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:10:20', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2011, '', '700', 'SET', 'Prices', 'price', '2013-12-18 16:10:20', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2012, '', '94', 'SET', 'Prices', 'rate_id', '2013-12-18 16:10:20', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2013, '', '199', 'SET', 'Prices', 'id', '2013-12-18 16:10:20', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2014, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2015, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:41:08', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2016, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2017, '', '25', 'CHANGE', 'Prices', 'id', '2013-12-18 16:41:08', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2018, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2019, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:41:08', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2020, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2021, '', '26', 'CHANGE', 'Prices', 'id', '2013-12-18 16:41:08', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2022, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2023, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:41:08', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2024, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2025, '', '27', 'CHANGE', 'Prices', 'id', '2013-12-18 16:41:08', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2026, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2027, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:41:08', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2028, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2029, '', '28', 'CHANGE', 'Prices', 'id', '2013-12-18 16:41:08', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2030, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:41:08', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2031, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2032, '', '1500', 'SET', 'Prices', 'price', '2013-12-18 16:41:08', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2033, '', '95', 'SET', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2034, '', '200', 'SET', 'Prices', 'id', '2013-12-18 16:41:08', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2035, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:41:08', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2036, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2037, '', '1700', 'SET', 'Prices', 'price', '2013-12-18 16:41:08', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2038, '', '95', 'SET', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2039, '', '201', 'SET', 'Prices', 'id', '2013-12-18 16:41:08', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2040, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:41:08', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2041, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2042, '', '1900', 'SET', 'Prices', 'price', '2013-12-18 16:41:08', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2043, '', '95', 'SET', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2044, '', '202', 'SET', 'Prices', 'id', '2013-12-18 16:41:08', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2045, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 16:41:08', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2046, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 16:41:08', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2047, '', '850', 'SET', 'Prices', 'price', '2013-12-18 16:41:08', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2048, '', '95', 'SET', 'Prices', 'rate_id', '2013-12-18 16:41:08', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2049, '', '203', 'SET', 'Prices', 'id', '2013-12-18 16:41:08', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2050, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:23', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(2051, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:23', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(2052, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:23', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(2053, '', '1', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:23', 4, '1');
INSERT INTO `tbl_audit_trail` VALUES(2054, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:23', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(2055, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:23', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(2056, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:23', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(2057, '', '2', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:23', 4, '2');
INSERT INTO `tbl_audit_trail` VALUES(2058, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:23', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(2059, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:23', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(2060, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:23', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(2061, '', '3', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:23', 4, '3');
INSERT INTO `tbl_audit_trail` VALUES(2062, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:23', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(2063, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:23', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(2064, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:23', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(2065, '', '4', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:23', 4, '4');
INSERT INTO `tbl_audit_trail` VALUES(2066, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:23', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(2067, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:23', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(2068, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:23', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(2069, '', '175', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:23', 4, '175');
INSERT INTO `tbl_audit_trail` VALUES(2070, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:23', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(2071, '', '1700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:23', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(2072, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:24', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(2073, '', '176', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:24', 4, '176');
INSERT INTO `tbl_audit_trail` VALUES(2074, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:24', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(2075, '', '1900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:24', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(2076, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:24', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(2077, '', '177', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:24', 4, '177');
INSERT INTO `tbl_audit_trail` VALUES(2078, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:24', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(2079, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:24', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(2080, '', '89', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:24', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(2081, '', '181', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:24', 4, '181');
INSERT INTO `tbl_audit_trail` VALUES(2082, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:58', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(2083, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:58', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(2084, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:58', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(2085, '', '5', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:58', 4, '5');
INSERT INTO `tbl_audit_trail` VALUES(2086, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:58', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(2087, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:59', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(2088, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:59', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(2089, '', '6', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:59', 4, '6');
INSERT INTO `tbl_audit_trail` VALUES(2090, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:59', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(2091, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:59', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(2092, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:59', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(2093, '', '7', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:59', 4, '7');
INSERT INTO `tbl_audit_trail` VALUES(2094, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:59', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(2095, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:59', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(2096, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:59', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(2097, '', '8', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:59', 4, '8');
INSERT INTO `tbl_audit_trail` VALUES(2098, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:59', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(2099, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:59', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(2100, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:59', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(2101, '', '178', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:59', 4, '178');
INSERT INTO `tbl_audit_trail` VALUES(2102, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:59', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(2103, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:59', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(2104, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:59', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(2105, '', '179', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:59', 4, '179');
INSERT INTO `tbl_audit_trail` VALUES(2106, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:59', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(2107, '', '1450.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:59', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(2108, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:59', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(2109, '', '180', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:59', 4, '180');
INSERT INTO `tbl_audit_trail` VALUES(2110, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-18 16:46:59', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(2111, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 16:46:59', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(2112, '', '90', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 16:46:59', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(2113, '', '182', 'CHANGE', 'Prices', 'id', '2013-12-18 16:46:59', 4, '182');
INSERT INTO `tbl_audit_trail` VALUES(2114, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(2115, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(2116, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(2117, '', '9', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '9');
INSERT INTO `tbl_audit_trail` VALUES(2118, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(2119, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(2120, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(2121, '', '10', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '10');
INSERT INTO `tbl_audit_trail` VALUES(2122, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(2123, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(2124, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(2125, '', '11', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '11');
INSERT INTO `tbl_audit_trail` VALUES(2126, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(2127, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(2128, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(2129, '', '12', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '12');
INSERT INTO `tbl_audit_trail` VALUES(2130, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(2131, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(2132, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(2133, '', '184', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '184');
INSERT INTO `tbl_audit_trail` VALUES(2134, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(2135, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(2136, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(2137, '', '185', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '185');
INSERT INTO `tbl_audit_trail` VALUES(2138, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(2139, '', '1700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(2140, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(2141, '', '186', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '186');
INSERT INTO `tbl_audit_trail` VALUES(2142, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:05:21', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(2143, '', '1900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:05:21', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(2144, '', '91', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:05:21', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(2145, '', '187', 'CHANGE', 'Prices', 'id', '2013-12-18 17:05:21', 4, '187');
INSERT INTO `tbl_audit_trail` VALUES(2146, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(2147, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(2148, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(2149, '', '13', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '13');
INSERT INTO `tbl_audit_trail` VALUES(2150, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(2151, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(2152, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(2153, '', '14', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '14');
INSERT INTO `tbl_audit_trail` VALUES(2154, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(2155, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(2156, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(2157, '', '15', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '15');
INSERT INTO `tbl_audit_trail` VALUES(2158, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(2159, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(2160, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(2161, '', '16', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '16');
INSERT INTO `tbl_audit_trail` VALUES(2162, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(2163, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(2164, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(2165, '', '188', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '188');
INSERT INTO `tbl_audit_trail` VALUES(2166, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(2167, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(2168, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(2169, '', '189', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '189');
INSERT INTO `tbl_audit_trail` VALUES(2170, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(2171, '', '1450.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(2172, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(2173, '', '190', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '190');
INSERT INTO `tbl_audit_trail` VALUES(2174, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:09:45', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(2175, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:09:45', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(2176, '', '92', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:09:45', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(2177, '', '191', 'CHANGE', 'Prices', 'id', '2013-12-18 17:09:45', 4, '191');
INSERT INTO `tbl_audit_trail` VALUES(2178, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:04', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(2179, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:04', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(2180, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:04', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(2181, '', '17', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:04', 4, '17');
INSERT INTO `tbl_audit_trail` VALUES(2182, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:04', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(2183, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:04', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(2184, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:04', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(2185, '', '18', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:04', 4, '18');
INSERT INTO `tbl_audit_trail` VALUES(2186, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:04', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(2187, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:04', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(2188, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:04', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(2189, '', '19', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:04', 4, '19');
INSERT INTO `tbl_audit_trail` VALUES(2190, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:04', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(2191, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:04', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(2192, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:04', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(2193, '', '20', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:04', 4, '20');
INSERT INTO `tbl_audit_trail` VALUES(2194, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:04', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(2195, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:04', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(2196, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:04', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(2197, '', '192', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:04', 4, '192');
INSERT INTO `tbl_audit_trail` VALUES(2198, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:05', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(2199, '', '1700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:05', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(2200, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:05', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(2201, '', '193', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:05', 4, '193');
INSERT INTO `tbl_audit_trail` VALUES(2202, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:05', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(2203, '', '1900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:05', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(2204, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:05', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(2205, '', '194', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:05', 4, '194');
INSERT INTO `tbl_audit_trail` VALUES(2206, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:05', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(2207, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:05', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(2208, '', '93', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:05', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(2209, '', '195', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:05', 4, '195');
INSERT INTO `tbl_audit_trail` VALUES(2210, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:24', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(2211, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:24', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(2212, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:24', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(2213, '', '21', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:24', 4, '21');
INSERT INTO `tbl_audit_trail` VALUES(2214, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(2215, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(2216, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(2217, '', '22', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:24', 4, '22');
INSERT INTO `tbl_audit_trail` VALUES(2218, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:24', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(2219, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:24', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(2220, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:24', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(2221, '', '23', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:24', 4, '23');
INSERT INTO `tbl_audit_trail` VALUES(2222, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:24', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(2223, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:24', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(2224, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:24', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(2225, '', '24', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:24', 4, '24');
INSERT INTO `tbl_audit_trail` VALUES(2226, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:24', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(2227, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:24', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(2228, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:24', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(2229, '', '196', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:24', 4, '196');
INSERT INTO `tbl_audit_trail` VALUES(2230, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:24', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2231, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:24', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2232, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:24', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2233, '', '197', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:24', 4, '197');
INSERT INTO `tbl_audit_trail` VALUES(2234, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:24', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2235, '', '1450.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:24', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2236, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:24', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2237, '', '198', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:25', 4, '198');
INSERT INTO `tbl_audit_trail` VALUES(2238, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:25', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2239, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:25', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2240, '', '94', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:25', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2241, '', '199', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:25', 4, '199');
INSERT INTO `tbl_audit_trail` VALUES(2242, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2243, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2244, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2245, '', '25', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '25');
INSERT INTO `tbl_audit_trail` VALUES(2246, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2247, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2248, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2249, '', '26', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '26');
INSERT INTO `tbl_audit_trail` VALUES(2250, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2251, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2252, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2253, '', '27', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '27');
INSERT INTO `tbl_audit_trail` VALUES(2254, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2255, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2256, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2257, '', '28', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '28');
INSERT INTO `tbl_audit_trail` VALUES(2258, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2259, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2260, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2261, '', '200', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '200');
INSERT INTO `tbl_audit_trail` VALUES(2262, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2263, '', '1700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2264, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2265, '', '201', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '201');
INSERT INTO `tbl_audit_trail` VALUES(2266, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2267, '', '1900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2268, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2269, '', '202', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '202');
INSERT INTO `tbl_audit_trail` VALUES(2270, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:17:53', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2271, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:17:53', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2272, '', '95', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:17:53', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2273, '', '203', 'CHANGE', 'Prices', 'id', '2013-12-18 17:17:53', 4, '203');
INSERT INTO `tbl_audit_trail` VALUES(2274, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(2275, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:19:11', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(2276, '', '96', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(2277, '', '29', 'CHANGE', 'Prices', 'id', '2013-12-18 17:19:11', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(2278, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(2279, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:19:11', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(2280, '', '96', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(2281, '', '30', 'CHANGE', 'Prices', 'id', '2013-12-18 17:19:11', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(2282, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(2283, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:19:11', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(2284, '', '96', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(2285, '', '31', 'CHANGE', 'Prices', 'id', '2013-12-18 17:19:11', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(2286, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(2287, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:19:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(2288, '', '96', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(2289, '', '32', 'CHANGE', 'Prices', 'id', '2013-12-18 17:19:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(2290, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:19:11', 4, '204');
INSERT INTO `tbl_audit_trail` VALUES(2291, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '204');
INSERT INTO `tbl_audit_trail` VALUES(2292, '', '1150', 'SET', 'Prices', 'price', '2013-12-18 17:19:11', 4, '204');
INSERT INTO `tbl_audit_trail` VALUES(2293, '', '96', 'SET', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '204');
INSERT INTO `tbl_audit_trail` VALUES(2294, '', '204', 'SET', 'Prices', 'id', '2013-12-18 17:19:11', 4, '204');
INSERT INTO `tbl_audit_trail` VALUES(2295, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:19:11', 4, '205');
INSERT INTO `tbl_audit_trail` VALUES(2296, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '205');
INSERT INTO `tbl_audit_trail` VALUES(2297, '', '1300', 'SET', 'Prices', 'price', '2013-12-18 17:19:11', 4, '205');
INSERT INTO `tbl_audit_trail` VALUES(2298, '', '96', 'SET', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '205');
INSERT INTO `tbl_audit_trail` VALUES(2299, '', '205', 'SET', 'Prices', 'id', '2013-12-18 17:19:11', 4, '205');
INSERT INTO `tbl_audit_trail` VALUES(2300, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:19:11', 4, '206');
INSERT INTO `tbl_audit_trail` VALUES(2301, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '206');
INSERT INTO `tbl_audit_trail` VALUES(2302, '', '1450', 'SET', 'Prices', 'price', '2013-12-18 17:19:11', 4, '206');
INSERT INTO `tbl_audit_trail` VALUES(2303, '', '96', 'SET', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '206');
INSERT INTO `tbl_audit_trail` VALUES(2304, '', '206', 'SET', 'Prices', 'id', '2013-12-18 17:19:11', 4, '206');
INSERT INTO `tbl_audit_trail` VALUES(2305, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:19:11', 4, '207');
INSERT INTO `tbl_audit_trail` VALUES(2306, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 17:19:11', 4, '207');
INSERT INTO `tbl_audit_trail` VALUES(2307, '', '700', 'SET', 'Prices', 'price', '2013-12-18 17:19:11', 4, '207');
INSERT INTO `tbl_audit_trail` VALUES(2308, '', '96', 'SET', 'Prices', 'rate_id', '2013-12-18 17:19:11', 4, '207');
INSERT INTO `tbl_audit_trail` VALUES(2309, '', '207', 'SET', 'Prices', 'id', '2013-12-18 17:19:11', 4, '207');
INSERT INTO `tbl_audit_trail` VALUES(2310, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(2311, '', '850.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:20:15', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(2312, '', '98', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(2313, '', '34', 'CHANGE', 'Prices', 'id', '2013-12-18 17:20:15', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(2314, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(2315, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:20:15', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(2316, '', '98', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(2317, '', '35', 'CHANGE', 'Prices', 'id', '2013-12-18 17:20:15', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(2318, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(2319, '', '1150.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:20:15', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(2320, '', '98', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(2321, '', '36', 'CHANGE', 'Prices', 'id', '2013-12-18 17:20:15', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(2322, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(2323, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:20:15', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(2324, '', '98', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(2325, '', '37', 'CHANGE', 'Prices', 'id', '2013-12-18 17:20:15', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(2326, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:20:15', 4, '208');
INSERT INTO `tbl_audit_trail` VALUES(2327, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '208');
INSERT INTO `tbl_audit_trail` VALUES(2328, '', '1500', 'SET', 'Prices', 'price', '2013-12-18 17:20:15', 4, '208');
INSERT INTO `tbl_audit_trail` VALUES(2329, '', '98', 'SET', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '208');
INSERT INTO `tbl_audit_trail` VALUES(2330, '', '208', 'SET', 'Prices', 'id', '2013-12-18 17:20:15', 4, '208');
INSERT INTO `tbl_audit_trail` VALUES(2331, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:20:15', 4, '209');
INSERT INTO `tbl_audit_trail` VALUES(2332, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '209');
INSERT INTO `tbl_audit_trail` VALUES(2333, '', '1700', 'SET', 'Prices', 'price', '2013-12-18 17:20:15', 4, '209');
INSERT INTO `tbl_audit_trail` VALUES(2334, '', '98', 'SET', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '209');
INSERT INTO `tbl_audit_trail` VALUES(2335, '', '209', 'SET', 'Prices', 'id', '2013-12-18 17:20:15', 4, '209');
INSERT INTO `tbl_audit_trail` VALUES(2336, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:20:15', 4, '210');
INSERT INTO `tbl_audit_trail` VALUES(2337, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '210');
INSERT INTO `tbl_audit_trail` VALUES(2338, '', '1900', 'SET', 'Prices', 'price', '2013-12-18 17:20:15', 4, '210');
INSERT INTO `tbl_audit_trail` VALUES(2339, '', '98', 'SET', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '210');
INSERT INTO `tbl_audit_trail` VALUES(2340, '', '210', 'SET', 'Prices', 'id', '2013-12-18 17:20:15', 4, '210');
INSERT INTO `tbl_audit_trail` VALUES(2341, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:20:15', 4, '211');
INSERT INTO `tbl_audit_trail` VALUES(2342, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 17:20:15', 4, '211');
INSERT INTO `tbl_audit_trail` VALUES(2343, '', '850', 'SET', 'Prices', 'price', '2013-12-18 17:20:15', 4, '211');
INSERT INTO `tbl_audit_trail` VALUES(2344, '', '98', 'SET', 'Prices', 'rate_id', '2013-12-18 17:20:15', 4, '211');
INSERT INTO `tbl_audit_trail` VALUES(2345, '', '211', 'SET', 'Prices', 'id', '2013-12-18 17:20:15', 4, '211');
INSERT INTO `tbl_audit_trail` VALUES(2346, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(2347, '', '700.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:21:29', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(2348, '', '100', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(2349, '', '41', 'CHANGE', 'Prices', 'id', '2013-12-18 17:21:29', 4, '41');
INSERT INTO `tbl_audit_trail` VALUES(2350, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(2351, '', '800.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:21:29', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(2352, '', '100', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(2353, '', '42', 'CHANGE', 'Prices', 'id', '2013-12-18 17:21:29', 4, '42');
INSERT INTO `tbl_audit_trail` VALUES(2354, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(2355, '', '900.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:21:29', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(2356, '', '100', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(2357, '', '43', 'CHANGE', 'Prices', 'id', '2013-12-18 17:21:29', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(2358, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(2359, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:21:29', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(2360, '', '100', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(2361, '', '44', 'CHANGE', 'Prices', 'id', '2013-12-18 17:21:29', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(2362, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:21:29', 4, '212');
INSERT INTO `tbl_audit_trail` VALUES(2363, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '212');
INSERT INTO `tbl_audit_trail` VALUES(2364, '', '1150', 'SET', 'Prices', 'price', '2013-12-18 17:21:29', 4, '212');
INSERT INTO `tbl_audit_trail` VALUES(2365, '', '100', 'SET', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '212');
INSERT INTO `tbl_audit_trail` VALUES(2366, '', '212', 'SET', 'Prices', 'id', '2013-12-18 17:21:29', 4, '212');
INSERT INTO `tbl_audit_trail` VALUES(2367, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:21:29', 4, '213');
INSERT INTO `tbl_audit_trail` VALUES(2368, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '213');
INSERT INTO `tbl_audit_trail` VALUES(2369, '', '1300', 'SET', 'Prices', 'price', '2013-12-18 17:21:29', 4, '213');
INSERT INTO `tbl_audit_trail` VALUES(2370, '', '100', 'SET', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '213');
INSERT INTO `tbl_audit_trail` VALUES(2371, '', '213', 'SET', 'Prices', 'id', '2013-12-18 17:21:29', 4, '213');
INSERT INTO `tbl_audit_trail` VALUES(2372, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:21:29', 4, '214');
INSERT INTO `tbl_audit_trail` VALUES(2373, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '214');
INSERT INTO `tbl_audit_trail` VALUES(2374, '', '1450', 'SET', 'Prices', 'price', '2013-12-18 17:21:29', 4, '214');
INSERT INTO `tbl_audit_trail` VALUES(2375, '', '100', 'SET', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '214');
INSERT INTO `tbl_audit_trail` VALUES(2376, '', '214', 'SET', 'Prices', 'id', '2013-12-18 17:21:29', 4, '214');
INSERT INTO `tbl_audit_trail` VALUES(2377, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:21:29', 4, '215');
INSERT INTO `tbl_audit_trail` VALUES(2378, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 17:21:29', 4, '215');
INSERT INTO `tbl_audit_trail` VALUES(2379, '', '700', 'SET', 'Prices', 'price', '2013-12-18 17:21:29', 4, '215');
INSERT INTO `tbl_audit_trail` VALUES(2380, '', '100', 'SET', 'Prices', 'rate_id', '2013-12-18 17:21:29', 4, '215');
INSERT INTO `tbl_audit_trail` VALUES(2381, '', '215', 'SET', 'Prices', 'id', '2013-12-18 17:21:29', 4, '215');
INSERT INTO `tbl_audit_trail` VALUES(2382, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(2383, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:22:45', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(2384, '', '101', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(2385, '', '45', 'CHANGE', 'Prices', 'id', '2013-12-18 17:22:45', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(2386, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(2387, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:22:45', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(2388, '', '101', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(2389, '', '46', 'CHANGE', 'Prices', 'id', '2013-12-18 17:22:45', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(2390, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(2391, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:22:45', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(2392, '', '101', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(2393, '', '47', 'CHANGE', 'Prices', 'id', '2013-12-18 17:22:45', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(2394, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(2395, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-18 17:22:45', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(2396, '', '101', 'CHANGE', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(2397, '', '48', 'CHANGE', 'Prices', 'id', '2013-12-18 17:22:45', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(2398, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:22:45', 4, '216');
INSERT INTO `tbl_audit_trail` VALUES(2399, '', '6', 'SET', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '216');
INSERT INTO `tbl_audit_trail` VALUES(2400, '', '1850', 'SET', 'Prices', 'price', '2013-12-18 17:22:45', 4, '216');
INSERT INTO `tbl_audit_trail` VALUES(2401, '', '101', 'SET', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '216');
INSERT INTO `tbl_audit_trail` VALUES(2402, '', '216', 'SET', 'Prices', 'id', '2013-12-18 17:22:45', 4, '216');
INSERT INTO `tbl_audit_trail` VALUES(2403, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:22:45', 4, '217');
INSERT INTO `tbl_audit_trail` VALUES(2404, '', '7', 'SET', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '217');
INSERT INTO `tbl_audit_trail` VALUES(2405, '', '2050', 'SET', 'Prices', 'price', '2013-12-18 17:22:45', 4, '217');
INSERT INTO `tbl_audit_trail` VALUES(2406, '', '101', 'SET', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '217');
INSERT INTO `tbl_audit_trail` VALUES(2407, '', '217', 'SET', 'Prices', 'id', '2013-12-18 17:22:45', 4, '217');
INSERT INTO `tbl_audit_trail` VALUES(2408, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:22:45', 4, '218');
INSERT INTO `tbl_audit_trail` VALUES(2409, '', '8', 'SET', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '218');
INSERT INTO `tbl_audit_trail` VALUES(2410, '', '2250', 'SET', 'Prices', 'price', '2013-12-18 17:22:45', 4, '218');
INSERT INTO `tbl_audit_trail` VALUES(2411, '', '101', 'SET', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '218');
INSERT INTO `tbl_audit_trail` VALUES(2412, '', '218', 'SET', 'Prices', 'id', '2013-12-18 17:22:45', 4, '218');
INSERT INTO `tbl_audit_trail` VALUES(2413, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-18 17:22:45', 4, '219');
INSERT INTO `tbl_audit_trail` VALUES(2414, '', '1', 'SET', 'Prices', 'pax', '2013-12-18 17:22:45', 4, '219');
INSERT INTO `tbl_audit_trail` VALUES(2415, '', '1200', 'SET', 'Prices', 'price', '2013-12-18 17:22:45', 4, '219');
INSERT INTO `tbl_audit_trail` VALUES(2416, '', '101', 'SET', 'Prices', 'rate_id', '2013-12-18 17:22:45', 4, '219');
INSERT INTO `tbl_audit_trail` VALUES(2417, '', '219', 'SET', 'Prices', 'id', '2013-12-18 17:22:45', 4, '219');
INSERT INTO `tbl_audit_trail` VALUES(2418, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(2419, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:19:20', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(2420, '', '102', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(2421, '', '49', 'CHANGE', 'Prices', 'id', '2013-12-20 15:19:20', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(2422, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(2423, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:19:20', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(2424, '', '102', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(2425, '', '50', 'CHANGE', 'Prices', 'id', '2013-12-20 15:19:20', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(2426, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(2427, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:19:20', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(2428, '', '102', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(2429, '', '51', 'CHANGE', 'Prices', 'id', '2013-12-20 15:19:20', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(2430, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(2431, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:19:20', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(2432, '', '102', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(2433, '', '52', 'CHANGE', 'Prices', 'id', '2013-12-20 15:19:20', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(2434, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:19:20', 4, '220');
INSERT INTO `tbl_audit_trail` VALUES(2435, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '220');
INSERT INTO `tbl_audit_trail` VALUES(2436, '', '1450', 'SET', 'Prices', 'price', '2013-12-20 15:19:20', 4, '220');
INSERT INTO `tbl_audit_trail` VALUES(2437, '', '102', 'SET', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '220');
INSERT INTO `tbl_audit_trail` VALUES(2438, '', '220', 'SET', 'Prices', 'id', '2013-12-20 15:19:20', 4, '220');
INSERT INTO `tbl_audit_trail` VALUES(2439, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:19:20', 4, '221');
INSERT INTO `tbl_audit_trail` VALUES(2440, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '221');
INSERT INTO `tbl_audit_trail` VALUES(2441, '', '1600', 'SET', 'Prices', 'price', '2013-12-20 15:19:20', 4, '221');
INSERT INTO `tbl_audit_trail` VALUES(2442, '', '102', 'SET', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '221');
INSERT INTO `tbl_audit_trail` VALUES(2443, '', '221', 'SET', 'Prices', 'id', '2013-12-20 15:19:20', 4, '221');
INSERT INTO `tbl_audit_trail` VALUES(2444, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:19:20', 4, '222');
INSERT INTO `tbl_audit_trail` VALUES(2445, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '222');
INSERT INTO `tbl_audit_trail` VALUES(2446, '', '1750', 'SET', 'Prices', 'price', '2013-12-20 15:19:20', 4, '222');
INSERT INTO `tbl_audit_trail` VALUES(2447, '', '102', 'SET', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '222');
INSERT INTO `tbl_audit_trail` VALUES(2448, '', '222', 'SET', 'Prices', 'id', '2013-12-20 15:19:20', 4, '222');
INSERT INTO `tbl_audit_trail` VALUES(2449, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:19:20', 4, '223');
INSERT INTO `tbl_audit_trail` VALUES(2450, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 15:19:20', 4, '223');
INSERT INTO `tbl_audit_trail` VALUES(2451, '', '1000', 'SET', 'Prices', 'price', '2013-12-20 15:19:20', 4, '223');
INSERT INTO `tbl_audit_trail` VALUES(2452, '', '102', 'SET', 'Prices', 'rate_id', '2013-12-20 15:19:20', 4, '223');
INSERT INTO `tbl_audit_trail` VALUES(2453, '', '223', 'SET', 'Prices', 'id', '2013-12-20 15:19:20', 4, '223');
INSERT INTO `tbl_audit_trail` VALUES(2454, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:38:34', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(2455, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:38:34', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(2456, '', '103', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:38:34', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(2457, '', '53', 'CHANGE', 'Prices', 'id', '2013-12-20 15:38:34', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(2458, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:38:34', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(2459, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:38:34', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(2460, '', '103', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:38:34', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(2461, '', '54', 'CHANGE', 'Prices', 'id', '2013-12-20 15:38:34', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(2462, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:38:34', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(2463, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:38:34', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(2464, '', '103', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:38:34', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(2465, '', '55', 'CHANGE', 'Prices', 'id', '2013-12-20 15:38:34', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(2466, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:38:34', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(2467, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:38:34', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(2468, '', '103', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:38:34', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(2469, '', '56', 'CHANGE', 'Prices', 'id', '2013-12-20 15:38:34', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(2470, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:38:35', 4, '224');
INSERT INTO `tbl_audit_trail` VALUES(2471, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 15:38:35', 4, '224');
INSERT INTO `tbl_audit_trail` VALUES(2472, '', '1850', 'SET', 'Prices', 'price', '2013-12-20 15:38:35', 4, '224');
INSERT INTO `tbl_audit_trail` VALUES(2473, '', '103', 'SET', 'Prices', 'rate_id', '2013-12-20 15:38:35', 4, '224');
INSERT INTO `tbl_audit_trail` VALUES(2474, '', '224', 'SET', 'Prices', 'id', '2013-12-20 15:38:35', 4, '224');
INSERT INTO `tbl_audit_trail` VALUES(2475, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:38:35', 4, '225');
INSERT INTO `tbl_audit_trail` VALUES(2476, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 15:38:35', 4, '225');
INSERT INTO `tbl_audit_trail` VALUES(2477, '', '2050', 'SET', 'Prices', 'price', '2013-12-20 15:38:35', 4, '225');
INSERT INTO `tbl_audit_trail` VALUES(2478, '', '103', 'SET', 'Prices', 'rate_id', '2013-12-20 15:38:35', 4, '225');
INSERT INTO `tbl_audit_trail` VALUES(2479, '', '225', 'SET', 'Prices', 'id', '2013-12-20 15:38:35', 4, '225');
INSERT INTO `tbl_audit_trail` VALUES(2480, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:38:35', 4, '226');
INSERT INTO `tbl_audit_trail` VALUES(2481, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 15:38:35', 4, '226');
INSERT INTO `tbl_audit_trail` VALUES(2482, '', '2250', 'SET', 'Prices', 'price', '2013-12-20 15:38:35', 4, '226');
INSERT INTO `tbl_audit_trail` VALUES(2483, '', '103', 'SET', 'Prices', 'rate_id', '2013-12-20 15:38:35', 4, '226');
INSERT INTO `tbl_audit_trail` VALUES(2484, '', '226', 'SET', 'Prices', 'id', '2013-12-20 15:38:35', 4, '226');
INSERT INTO `tbl_audit_trail` VALUES(2485, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:38:35', 4, '227');
INSERT INTO `tbl_audit_trail` VALUES(2486, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 15:38:35', 4, '227');
INSERT INTO `tbl_audit_trail` VALUES(2487, '', '1200', 'SET', 'Prices', 'price', '2013-12-20 15:38:35', 4, '227');
INSERT INTO `tbl_audit_trail` VALUES(2488, '', '103', 'SET', 'Prices', 'rate_id', '2013-12-20 15:38:35', 4, '227');
INSERT INTO `tbl_audit_trail` VALUES(2489, '', '227', 'SET', 'Prices', 'id', '2013-12-20 15:38:35', 4, '227');
INSERT INTO `tbl_audit_trail` VALUES(2490, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(2491, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:39:30', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(2492, '', '104', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(2493, '', '57', 'CHANGE', 'Prices', 'id', '2013-12-20 15:39:30', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(2494, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(2495, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:39:30', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(2496, '', '104', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(2497, '', '58', 'CHANGE', 'Prices', 'id', '2013-12-20 15:39:30', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(2498, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(2499, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:39:30', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(2500, '', '104', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(2501, '', '59', 'CHANGE', 'Prices', 'id', '2013-12-20 15:39:30', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(2502, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '60');
INSERT INTO `tbl_audit_trail` VALUES(2503, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:39:30', 4, '60');
INSERT INTO `tbl_audit_trail` VALUES(2504, '', '104', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '60');
INSERT INTO `tbl_audit_trail` VALUES(2505, '', '60', 'CHANGE', 'Prices', 'id', '2013-12-20 15:39:30', 4, '60');
INSERT INTO `tbl_audit_trail` VALUES(2506, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:39:30', 4, '228');
INSERT INTO `tbl_audit_trail` VALUES(2507, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '228');
INSERT INTO `tbl_audit_trail` VALUES(2508, '', '1450', 'SET', 'Prices', 'price', '2013-12-20 15:39:30', 4, '228');
INSERT INTO `tbl_audit_trail` VALUES(2509, '', '104', 'SET', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '228');
INSERT INTO `tbl_audit_trail` VALUES(2510, '', '228', 'SET', 'Prices', 'id', '2013-12-20 15:39:30', 4, '228');
INSERT INTO `tbl_audit_trail` VALUES(2511, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:39:30', 4, '229');
INSERT INTO `tbl_audit_trail` VALUES(2512, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '229');
INSERT INTO `tbl_audit_trail` VALUES(2513, '', '1600', 'SET', 'Prices', 'price', '2013-12-20 15:39:30', 4, '229');
INSERT INTO `tbl_audit_trail` VALUES(2514, '', '104', 'SET', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '229');
INSERT INTO `tbl_audit_trail` VALUES(2515, '', '229', 'SET', 'Prices', 'id', '2013-12-20 15:39:30', 4, '229');
INSERT INTO `tbl_audit_trail` VALUES(2516, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:39:30', 4, '230');
INSERT INTO `tbl_audit_trail` VALUES(2517, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '230');
INSERT INTO `tbl_audit_trail` VALUES(2518, '', '1750', 'SET', 'Prices', 'price', '2013-12-20 15:39:30', 4, '230');
INSERT INTO `tbl_audit_trail` VALUES(2519, '', '104', 'SET', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '230');
INSERT INTO `tbl_audit_trail` VALUES(2520, '', '230', 'SET', 'Prices', 'id', '2013-12-20 15:39:30', 4, '230');
INSERT INTO `tbl_audit_trail` VALUES(2521, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:39:30', 4, '231');
INSERT INTO `tbl_audit_trail` VALUES(2522, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 15:39:30', 4, '231');
INSERT INTO `tbl_audit_trail` VALUES(2523, '', '1000', 'SET', 'Prices', 'price', '2013-12-20 15:39:30', 4, '231');
INSERT INTO `tbl_audit_trail` VALUES(2524, '', '104', 'SET', 'Prices', 'rate_id', '2013-12-20 15:39:30', 4, '231');
INSERT INTO `tbl_audit_trail` VALUES(2525, '', '231', 'SET', 'Prices', 'id', '2013-12-20 15:39:30', 4, '231');
INSERT INTO `tbl_audit_trail` VALUES(2526, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:40:40', 4, '61');
INSERT INTO `tbl_audit_trail` VALUES(2527, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:40:40', 4, '61');
INSERT INTO `tbl_audit_trail` VALUES(2528, '', '105', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:40:40', 4, '61');
INSERT INTO `tbl_audit_trail` VALUES(2529, '', '61', 'CHANGE', 'Prices', 'id', '2013-12-20 15:40:40', 4, '61');
INSERT INTO `tbl_audit_trail` VALUES(2530, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:40:40', 4, '62');
INSERT INTO `tbl_audit_trail` VALUES(2531, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:40:40', 4, '62');
INSERT INTO `tbl_audit_trail` VALUES(2532, '', '105', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:40:40', 4, '62');
INSERT INTO `tbl_audit_trail` VALUES(2533, '', '62', 'CHANGE', 'Prices', 'id', '2013-12-20 15:40:40', 4, '62');
INSERT INTO `tbl_audit_trail` VALUES(2534, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:40:40', 4, '63');
INSERT INTO `tbl_audit_trail` VALUES(2535, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:40:40', 4, '63');
INSERT INTO `tbl_audit_trail` VALUES(2536, '', '105', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:40:40', 4, '63');
INSERT INTO `tbl_audit_trail` VALUES(2537, '', '63', 'CHANGE', 'Prices', 'id', '2013-12-20 15:40:40', 4, '63');
INSERT INTO `tbl_audit_trail` VALUES(2538, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:40:40', 4, '64');
INSERT INTO `tbl_audit_trail` VALUES(2539, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:40:40', 4, '64');
INSERT INTO `tbl_audit_trail` VALUES(2540, '', '105', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:40:40', 4, '64');
INSERT INTO `tbl_audit_trail` VALUES(2541, '', '64', 'CHANGE', 'Prices', 'id', '2013-12-20 15:40:40', 4, '64');
INSERT INTO `tbl_audit_trail` VALUES(2542, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:40:40', 4, '232');
INSERT INTO `tbl_audit_trail` VALUES(2543, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 15:40:40', 4, '232');
INSERT INTO `tbl_audit_trail` VALUES(2544, '', '1850', 'SET', 'Prices', 'price', '2013-12-20 15:40:40', 4, '232');
INSERT INTO `tbl_audit_trail` VALUES(2545, '', '105', 'SET', 'Prices', 'rate_id', '2013-12-20 15:40:40', 4, '232');
INSERT INTO `tbl_audit_trail` VALUES(2546, '', '232', 'SET', 'Prices', 'id', '2013-12-20 15:40:40', 4, '232');
INSERT INTO `tbl_audit_trail` VALUES(2547, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:40:40', 4, '233');
INSERT INTO `tbl_audit_trail` VALUES(2548, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 15:40:40', 4, '233');
INSERT INTO `tbl_audit_trail` VALUES(2549, '', '2050', 'SET', 'Prices', 'price', '2013-12-20 15:40:40', 4, '233');
INSERT INTO `tbl_audit_trail` VALUES(2550, '', '105', 'SET', 'Prices', 'rate_id', '2013-12-20 15:40:40', 4, '233');
INSERT INTO `tbl_audit_trail` VALUES(2551, '', '233', 'SET', 'Prices', 'id', '2013-12-20 15:40:40', 4, '233');
INSERT INTO `tbl_audit_trail` VALUES(2552, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:40:40', 4, '234');
INSERT INTO `tbl_audit_trail` VALUES(2553, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 15:40:41', 4, '234');
INSERT INTO `tbl_audit_trail` VALUES(2554, '', '2250', 'SET', 'Prices', 'price', '2013-12-20 15:40:41', 4, '234');
INSERT INTO `tbl_audit_trail` VALUES(2555, '', '105', 'SET', 'Prices', 'rate_id', '2013-12-20 15:40:41', 4, '234');
INSERT INTO `tbl_audit_trail` VALUES(2556, '', '234', 'SET', 'Prices', 'id', '2013-12-20 15:40:41', 4, '234');
INSERT INTO `tbl_audit_trail` VALUES(2557, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:40:41', 4, '235');
INSERT INTO `tbl_audit_trail` VALUES(2558, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 15:40:41', 4, '235');
INSERT INTO `tbl_audit_trail` VALUES(2559, '', '1200', 'SET', 'Prices', 'price', '2013-12-20 15:40:41', 4, '235');
INSERT INTO `tbl_audit_trail` VALUES(2560, '', '105', 'SET', 'Prices', 'rate_id', '2013-12-20 15:40:41', 4, '235');
INSERT INTO `tbl_audit_trail` VALUES(2561, '', '235', 'SET', 'Prices', 'id', '2013-12-20 15:40:41', 4, '235');
INSERT INTO `tbl_audit_trail` VALUES(2562, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:42', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2563, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:42', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2564, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:42', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2565, '', '65', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:42', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2566, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:42', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2567, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:42', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2568, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:42', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2569, '', '66', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:42', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2570, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:43', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2571, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:43', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2572, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:43', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2573, '', '67', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:43', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2574, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:43', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2575, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:43', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2576, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:43', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2577, '', '68', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:43', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2578, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:43', 4, '236');
INSERT INTO `tbl_audit_trail` VALUES(2579, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 15:41:43', 4, '236');
INSERT INTO `tbl_audit_trail` VALUES(2580, '', '1450', 'SET', 'Prices', 'price', '2013-12-20 15:41:43', 4, '236');
INSERT INTO `tbl_audit_trail` VALUES(2581, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:43', 4, '236');
INSERT INTO `tbl_audit_trail` VALUES(2582, '', '236', 'SET', 'Prices', 'id', '2013-12-20 15:41:43', 4, '236');
INSERT INTO `tbl_audit_trail` VALUES(2583, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:43', 4, '237');
INSERT INTO `tbl_audit_trail` VALUES(2584, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 15:41:43', 4, '237');
INSERT INTO `tbl_audit_trail` VALUES(2585, '', '1600', 'SET', 'Prices', 'price', '2013-12-20 15:41:43', 4, '237');
INSERT INTO `tbl_audit_trail` VALUES(2586, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:43', 4, '237');
INSERT INTO `tbl_audit_trail` VALUES(2587, '', '237', 'SET', 'Prices', 'id', '2013-12-20 15:41:43', 4, '237');
INSERT INTO `tbl_audit_trail` VALUES(2588, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:43', 4, '238');
INSERT INTO `tbl_audit_trail` VALUES(2589, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 15:41:43', 4, '238');
INSERT INTO `tbl_audit_trail` VALUES(2590, '', '1750', 'SET', 'Prices', 'price', '2013-12-20 15:41:43', 4, '238');
INSERT INTO `tbl_audit_trail` VALUES(2591, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:43', 4, '238');
INSERT INTO `tbl_audit_trail` VALUES(2592, '', '238', 'SET', 'Prices', 'id', '2013-12-20 15:41:43', 4, '238');
INSERT INTO `tbl_audit_trail` VALUES(2593, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:43', 4, '239');
INSERT INTO `tbl_audit_trail` VALUES(2594, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 15:41:43', 4, '239');
INSERT INTO `tbl_audit_trail` VALUES(2595, '', '1000', 'SET', 'Prices', 'price', '2013-12-20 15:41:43', 4, '239');
INSERT INTO `tbl_audit_trail` VALUES(2596, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:43', 4, '239');
INSERT INTO `tbl_audit_trail` VALUES(2597, '', '239', 'SET', 'Prices', 'id', '2013-12-20 15:41:43', 4, '239');
INSERT INTO `tbl_audit_trail` VALUES(2598, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2599, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:46', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2600, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2601, '', '65', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:46', 4, '65');
INSERT INTO `tbl_audit_trail` VALUES(2602, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2603, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:46', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2604, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2605, '', '66', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:46', 4, '66');
INSERT INTO `tbl_audit_trail` VALUES(2606, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2607, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:46', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2608, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2609, '', '67', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:46', 4, '67');
INSERT INTO `tbl_audit_trail` VALUES(2610, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2611, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-20 15:41:46', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2612, '', '106', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2613, '', '68', 'CHANGE', 'Prices', 'id', '2013-12-20 15:41:46', 4, '68');
INSERT INTO `tbl_audit_trail` VALUES(2614, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:46', 4, '240');
INSERT INTO `tbl_audit_trail` VALUES(2615, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '240');
INSERT INTO `tbl_audit_trail` VALUES(2616, '', '1450', 'SET', 'Prices', 'price', '2013-12-20 15:41:46', 4, '240');
INSERT INTO `tbl_audit_trail` VALUES(2617, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '240');
INSERT INTO `tbl_audit_trail` VALUES(2618, '', '240', 'SET', 'Prices', 'id', '2013-12-20 15:41:46', 4, '240');
INSERT INTO `tbl_audit_trail` VALUES(2619, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:46', 4, '241');
INSERT INTO `tbl_audit_trail` VALUES(2620, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '241');
INSERT INTO `tbl_audit_trail` VALUES(2621, '', '1600', 'SET', 'Prices', 'price', '2013-12-20 15:41:46', 4, '241');
INSERT INTO `tbl_audit_trail` VALUES(2622, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '241');
INSERT INTO `tbl_audit_trail` VALUES(2623, '', '241', 'SET', 'Prices', 'id', '2013-12-20 15:41:46', 4, '241');
INSERT INTO `tbl_audit_trail` VALUES(2624, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:46', 4, '242');
INSERT INTO `tbl_audit_trail` VALUES(2625, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '242');
INSERT INTO `tbl_audit_trail` VALUES(2626, '', '1750', 'SET', 'Prices', 'price', '2013-12-20 15:41:46', 4, '242');
INSERT INTO `tbl_audit_trail` VALUES(2627, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '242');
INSERT INTO `tbl_audit_trail` VALUES(2628, '', '242', 'SET', 'Prices', 'id', '2013-12-20 15:41:46', 4, '242');
INSERT INTO `tbl_audit_trail` VALUES(2629, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 15:41:46', 4, '243');
INSERT INTO `tbl_audit_trail` VALUES(2630, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 15:41:46', 4, '243');
INSERT INTO `tbl_audit_trail` VALUES(2631, '', '1000', 'SET', 'Prices', 'price', '2013-12-20 15:41:46', 4, '243');
INSERT INTO `tbl_audit_trail` VALUES(2632, '', '106', 'SET', 'Prices', 'rate_id', '2013-12-20 15:41:46', 4, '243');
INSERT INTO `tbl_audit_trail` VALUES(2633, '', '243', 'SET', 'Prices', 'id', '2013-12-20 15:41:46', 4, '243');
INSERT INTO `tbl_audit_trail` VALUES(2634, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:15:23', 4, '69');
INSERT INTO `tbl_audit_trail` VALUES(2635, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:15:23', 4, '69');
INSERT INTO `tbl_audit_trail` VALUES(2636, '', '107', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:15:23', 4, '69');
INSERT INTO `tbl_audit_trail` VALUES(2637, '', '69', 'CHANGE', 'Prices', 'id', '2013-12-20 16:15:23', 4, '69');
INSERT INTO `tbl_audit_trail` VALUES(2638, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:15:23', 4, '70');
INSERT INTO `tbl_audit_trail` VALUES(2639, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:15:23', 4, '70');
INSERT INTO `tbl_audit_trail` VALUES(2640, '', '107', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:15:23', 4, '70');
INSERT INTO `tbl_audit_trail` VALUES(2641, '', '70', 'CHANGE', 'Prices', 'id', '2013-12-20 16:15:23', 4, '70');
INSERT INTO `tbl_audit_trail` VALUES(2642, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:15:23', 4, '71');
INSERT INTO `tbl_audit_trail` VALUES(2643, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:15:23', 4, '71');
INSERT INTO `tbl_audit_trail` VALUES(2644, '', '107', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:15:23', 4, '71');
INSERT INTO `tbl_audit_trail` VALUES(2645, '', '71', 'CHANGE', 'Prices', 'id', '2013-12-20 16:15:23', 4, '71');
INSERT INTO `tbl_audit_trail` VALUES(2646, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:15:23', 4, '72');
INSERT INTO `tbl_audit_trail` VALUES(2647, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:15:24', 4, '72');
INSERT INTO `tbl_audit_trail` VALUES(2648, '', '107', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:15:24', 4, '72');
INSERT INTO `tbl_audit_trail` VALUES(2649, '', '72', 'CHANGE', 'Prices', 'id', '2013-12-20 16:15:24', 4, '72');
INSERT INTO `tbl_audit_trail` VALUES(2650, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:15:24', 4, '244');
INSERT INTO `tbl_audit_trail` VALUES(2651, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 16:15:24', 4, '244');
INSERT INTO `tbl_audit_trail` VALUES(2652, '', '1850', 'SET', 'Prices', 'price', '2013-12-20 16:15:24', 4, '244');
INSERT INTO `tbl_audit_trail` VALUES(2653, '', '107', 'SET', 'Prices', 'rate_id', '2013-12-20 16:15:24', 4, '244');
INSERT INTO `tbl_audit_trail` VALUES(2654, '', '244', 'SET', 'Prices', 'id', '2013-12-20 16:15:24', 4, '244');
INSERT INTO `tbl_audit_trail` VALUES(2655, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:15:24', 4, '245');
INSERT INTO `tbl_audit_trail` VALUES(2656, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 16:15:24', 4, '245');
INSERT INTO `tbl_audit_trail` VALUES(2657, '', '2050', 'SET', 'Prices', 'price', '2013-12-20 16:15:24', 4, '245');
INSERT INTO `tbl_audit_trail` VALUES(2658, '', '107', 'SET', 'Prices', 'rate_id', '2013-12-20 16:15:24', 4, '245');
INSERT INTO `tbl_audit_trail` VALUES(2659, '', '245', 'SET', 'Prices', 'id', '2013-12-20 16:15:24', 4, '245');
INSERT INTO `tbl_audit_trail` VALUES(2660, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:15:24', 4, '246');
INSERT INTO `tbl_audit_trail` VALUES(2661, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 16:15:24', 4, '246');
INSERT INTO `tbl_audit_trail` VALUES(2662, '', '2250', 'SET', 'Prices', 'price', '2013-12-20 16:15:24', 4, '246');
INSERT INTO `tbl_audit_trail` VALUES(2663, '', '107', 'SET', 'Prices', 'rate_id', '2013-12-20 16:15:24', 4, '246');
INSERT INTO `tbl_audit_trail` VALUES(2664, '', '246', 'SET', 'Prices', 'id', '2013-12-20 16:15:24', 4, '246');
INSERT INTO `tbl_audit_trail` VALUES(2665, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:15:24', 4, '247');
INSERT INTO `tbl_audit_trail` VALUES(2666, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 16:15:24', 4, '247');
INSERT INTO `tbl_audit_trail` VALUES(2667, '', '1200', 'SET', 'Prices', 'price', '2013-12-20 16:15:24', 4, '247');
INSERT INTO `tbl_audit_trail` VALUES(2668, '', '107', 'SET', 'Prices', 'rate_id', '2013-12-20 16:15:24', 4, '247');
INSERT INTO `tbl_audit_trail` VALUES(2669, '', '247', 'SET', 'Prices', 'id', '2013-12-20 16:15:24', 4, '247');
INSERT INTO `tbl_audit_trail` VALUES(2670, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:23:06', 4, '73');
INSERT INTO `tbl_audit_trail` VALUES(2671, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:23:06', 4, '73');
INSERT INTO `tbl_audit_trail` VALUES(2672, '', '108', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:23:06', 4, '73');
INSERT INTO `tbl_audit_trail` VALUES(2673, '', '73', 'CHANGE', 'Prices', 'id', '2013-12-20 16:23:06', 4, '73');
INSERT INTO `tbl_audit_trail` VALUES(2674, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:23:06', 4, '74');
INSERT INTO `tbl_audit_trail` VALUES(2675, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:23:06', 4, '74');
INSERT INTO `tbl_audit_trail` VALUES(2676, '', '108', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:23:06', 4, '74');
INSERT INTO `tbl_audit_trail` VALUES(2677, '', '74', 'CHANGE', 'Prices', 'id', '2013-12-20 16:23:06', 4, '74');
INSERT INTO `tbl_audit_trail` VALUES(2678, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:23:06', 4, '75');
INSERT INTO `tbl_audit_trail` VALUES(2679, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:23:06', 4, '75');
INSERT INTO `tbl_audit_trail` VALUES(2680, '', '108', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:23:06', 4, '75');
INSERT INTO `tbl_audit_trail` VALUES(2681, '', '75', 'CHANGE', 'Prices', 'id', '2013-12-20 16:23:06', 4, '75');
INSERT INTO `tbl_audit_trail` VALUES(2682, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 16:23:06', 4, '76');
INSERT INTO `tbl_audit_trail` VALUES(2683, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-20 16:23:06', 4, '76');
INSERT INTO `tbl_audit_trail` VALUES(2684, '', '108', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 16:23:06', 4, '76');
INSERT INTO `tbl_audit_trail` VALUES(2685, '', '76', 'CHANGE', 'Prices', 'id', '2013-12-20 16:23:06', 4, '76');
INSERT INTO `tbl_audit_trail` VALUES(2686, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:23:06', 4, '248');
INSERT INTO `tbl_audit_trail` VALUES(2687, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 16:23:06', 4, '248');
INSERT INTO `tbl_audit_trail` VALUES(2688, '', '1450', 'SET', 'Prices', 'price', '2013-12-20 16:23:06', 4, '248');
INSERT INTO `tbl_audit_trail` VALUES(2689, '', '108', 'SET', 'Prices', 'rate_id', '2013-12-20 16:23:06', 4, '248');
INSERT INTO `tbl_audit_trail` VALUES(2690, '', '248', 'SET', 'Prices', 'id', '2013-12-20 16:23:06', 4, '248');
INSERT INTO `tbl_audit_trail` VALUES(2691, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:23:06', 4, '249');
INSERT INTO `tbl_audit_trail` VALUES(2692, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 16:23:07', 4, '249');
INSERT INTO `tbl_audit_trail` VALUES(2693, '', '1600', 'SET', 'Prices', 'price', '2013-12-20 16:23:07', 4, '249');
INSERT INTO `tbl_audit_trail` VALUES(2694, '', '108', 'SET', 'Prices', 'rate_id', '2013-12-20 16:23:07', 4, '249');
INSERT INTO `tbl_audit_trail` VALUES(2695, '', '249', 'SET', 'Prices', 'id', '2013-12-20 16:23:07', 4, '249');
INSERT INTO `tbl_audit_trail` VALUES(2696, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:23:07', 4, '250');
INSERT INTO `tbl_audit_trail` VALUES(2697, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 16:23:07', 4, '250');
INSERT INTO `tbl_audit_trail` VALUES(2698, '', '1750', 'SET', 'Prices', 'price', '2013-12-20 16:23:07', 4, '250');
INSERT INTO `tbl_audit_trail` VALUES(2699, '', '108', 'SET', 'Prices', 'rate_id', '2013-12-20 16:23:07', 4, '250');
INSERT INTO `tbl_audit_trail` VALUES(2700, '', '250', 'SET', 'Prices', 'id', '2013-12-20 16:23:07', 4, '250');
INSERT INTO `tbl_audit_trail` VALUES(2701, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 16:23:07', 4, '251');
INSERT INTO `tbl_audit_trail` VALUES(2702, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 16:23:07', 4, '251');
INSERT INTO `tbl_audit_trail` VALUES(2703, '', '1000', 'SET', 'Prices', 'price', '2013-12-20 16:23:07', 4, '251');
INSERT INTO `tbl_audit_trail` VALUES(2704, '', '108', 'SET', 'Prices', 'rate_id', '2013-12-20 16:23:07', 4, '251');
INSERT INTO `tbl_audit_trail` VALUES(2705, '', '251', 'SET', 'Prices', 'id', '2013-12-20 16:23:07', 4, '251');
INSERT INTO `tbl_audit_trail` VALUES(2706, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '77');
INSERT INTO `tbl_audit_trail` VALUES(2707, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:04:55', 4, '77');
INSERT INTO `tbl_audit_trail` VALUES(2708, '', '109', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '77');
INSERT INTO `tbl_audit_trail` VALUES(2709, '', '77', 'CHANGE', 'Prices', 'id', '2013-12-20 17:04:55', 4, '77');
INSERT INTO `tbl_audit_trail` VALUES(2710, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '78');
INSERT INTO `tbl_audit_trail` VALUES(2711, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:04:55', 4, '78');
INSERT INTO `tbl_audit_trail` VALUES(2712, '', '109', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '78');
INSERT INTO `tbl_audit_trail` VALUES(2713, '', '78', 'CHANGE', 'Prices', 'id', '2013-12-20 17:04:55', 4, '78');
INSERT INTO `tbl_audit_trail` VALUES(2714, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '79');
INSERT INTO `tbl_audit_trail` VALUES(2715, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:04:55', 4, '79');
INSERT INTO `tbl_audit_trail` VALUES(2716, '', '109', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '79');
INSERT INTO `tbl_audit_trail` VALUES(2717, '', '79', 'CHANGE', 'Prices', 'id', '2013-12-20 17:04:55', 4, '79');
INSERT INTO `tbl_audit_trail` VALUES(2718, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '80');
INSERT INTO `tbl_audit_trail` VALUES(2719, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:04:55', 4, '80');
INSERT INTO `tbl_audit_trail` VALUES(2720, '', '109', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '80');
INSERT INTO `tbl_audit_trail` VALUES(2721, '', '80', 'CHANGE', 'Prices', 'id', '2013-12-20 17:04:55', 4, '80');
INSERT INTO `tbl_audit_trail` VALUES(2722, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:04:55', 4, '252');
INSERT INTO `tbl_audit_trail` VALUES(2723, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '252');
INSERT INTO `tbl_audit_trail` VALUES(2724, '', '1850', 'SET', 'Prices', 'price', '2013-12-20 17:04:55', 4, '252');
INSERT INTO `tbl_audit_trail` VALUES(2725, '', '109', 'SET', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '252');
INSERT INTO `tbl_audit_trail` VALUES(2726, '', '252', 'SET', 'Prices', 'id', '2013-12-20 17:04:55', 4, '252');
INSERT INTO `tbl_audit_trail` VALUES(2727, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:04:55', 4, '253');
INSERT INTO `tbl_audit_trail` VALUES(2728, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '253');
INSERT INTO `tbl_audit_trail` VALUES(2729, '', '2050', 'SET', 'Prices', 'price', '2013-12-20 17:04:55', 4, '253');
INSERT INTO `tbl_audit_trail` VALUES(2730, '', '109', 'SET', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '253');
INSERT INTO `tbl_audit_trail` VALUES(2731, '', '253', 'SET', 'Prices', 'id', '2013-12-20 17:04:55', 4, '253');
INSERT INTO `tbl_audit_trail` VALUES(2732, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:04:55', 4, '254');
INSERT INTO `tbl_audit_trail` VALUES(2733, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '254');
INSERT INTO `tbl_audit_trail` VALUES(2734, '', '2250', 'SET', 'Prices', 'price', '2013-12-20 17:04:55', 4, '254');
INSERT INTO `tbl_audit_trail` VALUES(2735, '', '109', 'SET', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '254');
INSERT INTO `tbl_audit_trail` VALUES(2736, '', '254', 'SET', 'Prices', 'id', '2013-12-20 17:04:55', 4, '254');
INSERT INTO `tbl_audit_trail` VALUES(2737, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:04:55', 4, '255');
INSERT INTO `tbl_audit_trail` VALUES(2738, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 17:04:55', 4, '255');
INSERT INTO `tbl_audit_trail` VALUES(2739, '', '1200', 'SET', 'Prices', 'price', '2013-12-20 17:04:55', 4, '255');
INSERT INTO `tbl_audit_trail` VALUES(2740, '', '109', 'SET', 'Prices', 'rate_id', '2013-12-20 17:04:55', 4, '255');
INSERT INTO `tbl_audit_trail` VALUES(2741, '', '255', 'SET', 'Prices', 'id', '2013-12-20 17:04:55', 4, '255');
INSERT INTO `tbl_audit_trail` VALUES(2742, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '81');
INSERT INTO `tbl_audit_trail` VALUES(2743, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:05:34', 4, '81');
INSERT INTO `tbl_audit_trail` VALUES(2744, '', '110', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '81');
INSERT INTO `tbl_audit_trail` VALUES(2745, '', '81', 'CHANGE', 'Prices', 'id', '2013-12-20 17:05:34', 4, '81');
INSERT INTO `tbl_audit_trail` VALUES(2746, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '82');
INSERT INTO `tbl_audit_trail` VALUES(2747, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:05:34', 4, '82');
INSERT INTO `tbl_audit_trail` VALUES(2748, '', '110', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '82');
INSERT INTO `tbl_audit_trail` VALUES(2749, '', '82', 'CHANGE', 'Prices', 'id', '2013-12-20 17:05:34', 4, '82');
INSERT INTO `tbl_audit_trail` VALUES(2750, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '83');
INSERT INTO `tbl_audit_trail` VALUES(2751, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:05:34', 4, '83');
INSERT INTO `tbl_audit_trail` VALUES(2752, '', '110', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '83');
INSERT INTO `tbl_audit_trail` VALUES(2753, '', '83', 'CHANGE', 'Prices', 'id', '2013-12-20 17:05:34', 4, '83');
INSERT INTO `tbl_audit_trail` VALUES(2754, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '84');
INSERT INTO `tbl_audit_trail` VALUES(2755, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:05:34', 4, '84');
INSERT INTO `tbl_audit_trail` VALUES(2756, '', '110', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '84');
INSERT INTO `tbl_audit_trail` VALUES(2757, '', '84', 'CHANGE', 'Prices', 'id', '2013-12-20 17:05:34', 4, '84');
INSERT INTO `tbl_audit_trail` VALUES(2758, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:05:34', 4, '256');
INSERT INTO `tbl_audit_trail` VALUES(2759, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '256');
INSERT INTO `tbl_audit_trail` VALUES(2760, '', '1450', 'SET', 'Prices', 'price', '2013-12-20 17:05:34', 4, '256');
INSERT INTO `tbl_audit_trail` VALUES(2761, '', '110', 'SET', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '256');
INSERT INTO `tbl_audit_trail` VALUES(2762, '', '256', 'SET', 'Prices', 'id', '2013-12-20 17:05:34', 4, '256');
INSERT INTO `tbl_audit_trail` VALUES(2763, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:05:34', 4, '257');
INSERT INTO `tbl_audit_trail` VALUES(2764, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '257');
INSERT INTO `tbl_audit_trail` VALUES(2765, '', '1600', 'SET', 'Prices', 'price', '2013-12-20 17:05:34', 4, '257');
INSERT INTO `tbl_audit_trail` VALUES(2766, '', '110', 'SET', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '257');
INSERT INTO `tbl_audit_trail` VALUES(2767, '', '257', 'SET', 'Prices', 'id', '2013-12-20 17:05:34', 4, '257');
INSERT INTO `tbl_audit_trail` VALUES(2768, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:05:34', 4, '258');
INSERT INTO `tbl_audit_trail` VALUES(2769, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '258');
INSERT INTO `tbl_audit_trail` VALUES(2770, '', '1750', 'SET', 'Prices', 'price', '2013-12-20 17:05:34', 4, '258');
INSERT INTO `tbl_audit_trail` VALUES(2771, '', '110', 'SET', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '258');
INSERT INTO `tbl_audit_trail` VALUES(2772, '', '258', 'SET', 'Prices', 'id', '2013-12-20 17:05:34', 4, '258');
INSERT INTO `tbl_audit_trail` VALUES(2773, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:05:34', 4, '259');
INSERT INTO `tbl_audit_trail` VALUES(2774, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 17:05:34', 4, '259');
INSERT INTO `tbl_audit_trail` VALUES(2775, '', '1000.', 'SET', 'Prices', 'price', '2013-12-20 17:05:34', 4, '259');
INSERT INTO `tbl_audit_trail` VALUES(2776, '', '110', 'SET', 'Prices', 'rate_id', '2013-12-20 17:05:34', 4, '259');
INSERT INTO `tbl_audit_trail` VALUES(2777, '', '259', 'SET', 'Prices', 'id', '2013-12-20 17:05:34', 4, '259');
INSERT INTO `tbl_audit_trail` VALUES(2778, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '85');
INSERT INTO `tbl_audit_trail` VALUES(2779, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:32:58', 4, '85');
INSERT INTO `tbl_audit_trail` VALUES(2780, '', '111', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '85');
INSERT INTO `tbl_audit_trail` VALUES(2781, '', '85', 'CHANGE', 'Prices', 'id', '2013-12-20 17:32:58', 4, '85');
INSERT INTO `tbl_audit_trail` VALUES(2782, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '86');
INSERT INTO `tbl_audit_trail` VALUES(2783, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:32:58', 4, '86');
INSERT INTO `tbl_audit_trail` VALUES(2784, '', '111', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '86');
INSERT INTO `tbl_audit_trail` VALUES(2785, '', '86', 'CHANGE', 'Prices', 'id', '2013-12-20 17:32:58', 4, '86');
INSERT INTO `tbl_audit_trail` VALUES(2786, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '87');
INSERT INTO `tbl_audit_trail` VALUES(2787, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:32:58', 4, '87');
INSERT INTO `tbl_audit_trail` VALUES(2788, '', '111', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '87');
INSERT INTO `tbl_audit_trail` VALUES(2789, '', '87', 'CHANGE', 'Prices', 'id', '2013-12-20 17:32:58', 4, '87');
INSERT INTO `tbl_audit_trail` VALUES(2790, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '88');
INSERT INTO `tbl_audit_trail` VALUES(2791, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:32:58', 4, '88');
INSERT INTO `tbl_audit_trail` VALUES(2792, '', '111', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '88');
INSERT INTO `tbl_audit_trail` VALUES(2793, '', '88', 'CHANGE', 'Prices', 'id', '2013-12-20 17:32:58', 4, '88');
INSERT INTO `tbl_audit_trail` VALUES(2794, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:32:58', 4, '260');
INSERT INTO `tbl_audit_trail` VALUES(2795, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '260');
INSERT INTO `tbl_audit_trail` VALUES(2796, '', '1850', 'SET', 'Prices', 'price', '2013-12-20 17:32:58', 4, '260');
INSERT INTO `tbl_audit_trail` VALUES(2797, '', '111', 'SET', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '260');
INSERT INTO `tbl_audit_trail` VALUES(2798, '', '260', 'SET', 'Prices', 'id', '2013-12-20 17:32:58', 4, '260');
INSERT INTO `tbl_audit_trail` VALUES(2799, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:32:58', 4, '261');
INSERT INTO `tbl_audit_trail` VALUES(2800, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '261');
INSERT INTO `tbl_audit_trail` VALUES(2801, '', '2050', 'SET', 'Prices', 'price', '2013-12-20 17:32:58', 4, '261');
INSERT INTO `tbl_audit_trail` VALUES(2802, '', '111', 'SET', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '261');
INSERT INTO `tbl_audit_trail` VALUES(2803, '', '261', 'SET', 'Prices', 'id', '2013-12-20 17:32:58', 4, '261');
INSERT INTO `tbl_audit_trail` VALUES(2804, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:32:58', 4, '262');
INSERT INTO `tbl_audit_trail` VALUES(2805, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '262');
INSERT INTO `tbl_audit_trail` VALUES(2806, '', '2250', 'SET', 'Prices', 'price', '2013-12-20 17:32:58', 4, '262');
INSERT INTO `tbl_audit_trail` VALUES(2807, '', '111', 'SET', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '262');
INSERT INTO `tbl_audit_trail` VALUES(2808, '', '262', 'SET', 'Prices', 'id', '2013-12-20 17:32:58', 4, '262');
INSERT INTO `tbl_audit_trail` VALUES(2809, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:32:58', 4, '263');
INSERT INTO `tbl_audit_trail` VALUES(2810, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 17:32:58', 4, '263');
INSERT INTO `tbl_audit_trail` VALUES(2811, '', '1200', 'SET', 'Prices', 'price', '2013-12-20 17:32:58', 4, '263');
INSERT INTO `tbl_audit_trail` VALUES(2812, '', '111', 'SET', 'Prices', 'rate_id', '2013-12-20 17:32:58', 4, '263');
INSERT INTO `tbl_audit_trail` VALUES(2813, '', '263', 'SET', 'Prices', 'id', '2013-12-20 17:32:58', 4, '263');
INSERT INTO `tbl_audit_trail` VALUES(2814, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '89');
INSERT INTO `tbl_audit_trail` VALUES(2815, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:33:53', 4, '89');
INSERT INTO `tbl_audit_trail` VALUES(2816, '', '112', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '89');
INSERT INTO `tbl_audit_trail` VALUES(2817, '', '89', 'CHANGE', 'Prices', 'id', '2013-12-20 17:33:53', 4, '89');
INSERT INTO `tbl_audit_trail` VALUES(2818, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '90');
INSERT INTO `tbl_audit_trail` VALUES(2819, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:33:53', 4, '90');
INSERT INTO `tbl_audit_trail` VALUES(2820, '', '112', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '90');
INSERT INTO `tbl_audit_trail` VALUES(2821, '', '90', 'CHANGE', 'Prices', 'id', '2013-12-20 17:33:53', 4, '90');
INSERT INTO `tbl_audit_trail` VALUES(2822, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '91');
INSERT INTO `tbl_audit_trail` VALUES(2823, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:33:53', 4, '91');
INSERT INTO `tbl_audit_trail` VALUES(2824, '', '112', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '91');
INSERT INTO `tbl_audit_trail` VALUES(2825, '', '91', 'CHANGE', 'Prices', 'id', '2013-12-20 17:33:53', 4, '91');
INSERT INTO `tbl_audit_trail` VALUES(2826, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '92');
INSERT INTO `tbl_audit_trail` VALUES(2827, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:33:53', 4, '92');
INSERT INTO `tbl_audit_trail` VALUES(2828, '', '112', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '92');
INSERT INTO `tbl_audit_trail` VALUES(2829, '', '92', 'CHANGE', 'Prices', 'id', '2013-12-20 17:33:53', 4, '92');
INSERT INTO `tbl_audit_trail` VALUES(2830, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:33:53', 4, '264');
INSERT INTO `tbl_audit_trail` VALUES(2831, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '264');
INSERT INTO `tbl_audit_trail` VALUES(2832, '', '1450', 'SET', 'Prices', 'price', '2013-12-20 17:33:53', 4, '264');
INSERT INTO `tbl_audit_trail` VALUES(2833, '', '112', 'SET', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '264');
INSERT INTO `tbl_audit_trail` VALUES(2834, '', '264', 'SET', 'Prices', 'id', '2013-12-20 17:33:53', 4, '264');
INSERT INTO `tbl_audit_trail` VALUES(2835, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:33:53', 4, '265');
INSERT INTO `tbl_audit_trail` VALUES(2836, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '265');
INSERT INTO `tbl_audit_trail` VALUES(2837, '', '1600', 'SET', 'Prices', 'price', '2013-12-20 17:33:53', 4, '265');
INSERT INTO `tbl_audit_trail` VALUES(2838, '', '112', 'SET', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '265');
INSERT INTO `tbl_audit_trail` VALUES(2839, '', '265', 'SET', 'Prices', 'id', '2013-12-20 17:33:53', 4, '265');
INSERT INTO `tbl_audit_trail` VALUES(2840, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:33:53', 4, '266');
INSERT INTO `tbl_audit_trail` VALUES(2841, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '266');
INSERT INTO `tbl_audit_trail` VALUES(2842, '', '1750', 'SET', 'Prices', 'price', '2013-12-20 17:33:53', 4, '266');
INSERT INTO `tbl_audit_trail` VALUES(2843, '', '112', 'SET', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '266');
INSERT INTO `tbl_audit_trail` VALUES(2844, '', '266', 'SET', 'Prices', 'id', '2013-12-20 17:33:53', 4, '266');
INSERT INTO `tbl_audit_trail` VALUES(2845, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:33:53', 4, '267');
INSERT INTO `tbl_audit_trail` VALUES(2846, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 17:33:53', 4, '267');
INSERT INTO `tbl_audit_trail` VALUES(2847, '', '1000', 'SET', 'Prices', 'price', '2013-12-20 17:33:53', 4, '267');
INSERT INTO `tbl_audit_trail` VALUES(2848, '', '112', 'SET', 'Prices', 'rate_id', '2013-12-20 17:33:53', 4, '267');
INSERT INTO `tbl_audit_trail` VALUES(2849, '', '267', 'SET', 'Prices', 'id', '2013-12-20 17:33:53', 4, '267');
INSERT INTO `tbl_audit_trail` VALUES(2850, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '93');
INSERT INTO `tbl_audit_trail` VALUES(2851, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:34:36', 4, '93');
INSERT INTO `tbl_audit_trail` VALUES(2852, '', '113', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '93');
INSERT INTO `tbl_audit_trail` VALUES(2853, '', '93', 'CHANGE', 'Prices', 'id', '2013-12-20 17:34:36', 4, '93');
INSERT INTO `tbl_audit_trail` VALUES(2854, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '94');
INSERT INTO `tbl_audit_trail` VALUES(2855, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:34:36', 4, '94');
INSERT INTO `tbl_audit_trail` VALUES(2856, '', '113', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '94');
INSERT INTO `tbl_audit_trail` VALUES(2857, '', '94', 'CHANGE', 'Prices', 'id', '2013-12-20 17:34:36', 4, '94');
INSERT INTO `tbl_audit_trail` VALUES(2858, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '95');
INSERT INTO `tbl_audit_trail` VALUES(2859, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:34:36', 4, '95');
INSERT INTO `tbl_audit_trail` VALUES(2860, '', '113', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '95');
INSERT INTO `tbl_audit_trail` VALUES(2861, '', '95', 'CHANGE', 'Prices', 'id', '2013-12-20 17:34:36', 4, '95');
INSERT INTO `tbl_audit_trail` VALUES(2862, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '96');
INSERT INTO `tbl_audit_trail` VALUES(2863, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-20 17:34:36', 4, '96');
INSERT INTO `tbl_audit_trail` VALUES(2864, '', '113', 'CHANGE', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '96');
INSERT INTO `tbl_audit_trail` VALUES(2865, '', '96', 'CHANGE', 'Prices', 'id', '2013-12-20 17:34:36', 4, '96');
INSERT INTO `tbl_audit_trail` VALUES(2866, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:34:36', 4, '268');
INSERT INTO `tbl_audit_trail` VALUES(2867, '', '6', 'SET', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '268');
INSERT INTO `tbl_audit_trail` VALUES(2868, '', '1850', 'SET', 'Prices', 'price', '2013-12-20 17:34:36', 4, '268');
INSERT INTO `tbl_audit_trail` VALUES(2869, '', '113', 'SET', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '268');
INSERT INTO `tbl_audit_trail` VALUES(2870, '', '268', 'SET', 'Prices', 'id', '2013-12-20 17:34:36', 4, '268');
INSERT INTO `tbl_audit_trail` VALUES(2871, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:34:36', 4, '269');
INSERT INTO `tbl_audit_trail` VALUES(2872, '', '7', 'SET', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '269');
INSERT INTO `tbl_audit_trail` VALUES(2873, '', '2050', 'SET', 'Prices', 'price', '2013-12-20 17:34:36', 4, '269');
INSERT INTO `tbl_audit_trail` VALUES(2874, '', '113', 'SET', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '269');
INSERT INTO `tbl_audit_trail` VALUES(2875, '', '269', 'SET', 'Prices', 'id', '2013-12-20 17:34:36', 4, '269');
INSERT INTO `tbl_audit_trail` VALUES(2876, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:34:36', 4, '270');
INSERT INTO `tbl_audit_trail` VALUES(2877, '', '8', 'SET', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '270');
INSERT INTO `tbl_audit_trail` VALUES(2878, '', '2250', 'SET', 'Prices', 'price', '2013-12-20 17:34:36', 4, '270');
INSERT INTO `tbl_audit_trail` VALUES(2879, '', '113', 'SET', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '270');
INSERT INTO `tbl_audit_trail` VALUES(2880, '', '270', 'SET', 'Prices', 'id', '2013-12-20 17:34:36', 4, '270');
INSERT INTO `tbl_audit_trail` VALUES(2881, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-20 17:34:36', 4, '271');
INSERT INTO `tbl_audit_trail` VALUES(2882, '', '1', 'SET', 'Prices', 'pax', '2013-12-20 17:34:36', 4, '271');
INSERT INTO `tbl_audit_trail` VALUES(2883, '', '1200', 'SET', 'Prices', 'price', '2013-12-20 17:34:36', 4, '271');
INSERT INTO `tbl_audit_trail` VALUES(2884, '', '113', 'SET', 'Prices', 'rate_id', '2013-12-20 17:34:36', 4, '271');
INSERT INTO `tbl_audit_trail` VALUES(2885, '', '271', 'SET', 'Prices', 'id', '2013-12-20 17:34:37', 4, '271');
INSERT INTO `tbl_audit_trail` VALUES(2886, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2887, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:18:39', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2888, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2889, '', '105', 'CHANGE', 'Prices', 'id', '2013-12-21 12:18:39', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2890, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2891, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:18:39', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2892, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2893, '', '106', 'CHANGE', 'Prices', 'id', '2013-12-21 12:18:39', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2894, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(2895, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:18:39', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(2896, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(2897, '', '107', 'CHANGE', 'Prices', 'id', '2013-12-21 12:18:39', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(2898, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(2899, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:18:39', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(2900, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(2901, '', '108', 'CHANGE', 'Prices', 'id', '2013-12-21 12:18:39', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(2902, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:18:39', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(2903, '', '6', 'SET', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(2904, '', '1450', 'SET', 'Prices', 'price', '2013-12-21 12:18:39', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(2905, '', '116', 'SET', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(2906, '', '272', 'SET', 'Prices', 'id', '2013-12-21 12:18:39', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(2907, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:18:39', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(2908, '', '7', 'SET', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(2909, '', '1600', 'SET', 'Prices', 'price', '2013-12-21 12:18:39', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(2910, '', '116', 'SET', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(2911, '', '273', 'SET', 'Prices', 'id', '2013-12-21 12:18:39', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(2912, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:18:39', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(2913, '', '8', 'SET', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(2914, '', '1750', 'SET', 'Prices', 'price', '2013-12-21 12:18:39', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(2915, '', '116', 'SET', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(2916, '', '274', 'SET', 'Prices', 'id', '2013-12-21 12:18:39', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(2917, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:18:39', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(2918, '', '1', 'SET', 'Prices', 'pax', '2013-12-21 12:18:39', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(2919, '', '1000', 'SET', 'Prices', 'price', '2013-12-21 12:18:39', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(2920, '', '116', 'SET', 'Prices', 'rate_id', '2013-12-21 12:18:39', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(2921, '', '275', 'SET', 'Prices', 'id', '2013-12-21 12:18:39', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(2922, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2923, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:20:19', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2924, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2925, '', '101', 'CHANGE', 'Prices', 'id', '2013-12-21 12:20:19', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2926, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2927, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:20:19', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2928, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2929, '', '102', 'CHANGE', 'Prices', 'id', '2013-12-21 12:20:19', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2930, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2931, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:20:19', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2932, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2933, '', '103', 'CHANGE', 'Prices', 'id', '2013-12-21 12:20:19', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2934, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2935, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:20:19', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2936, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2937, '', '104', 'CHANGE', 'Prices', 'id', '2013-12-21 12:20:19', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2938, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:20:19', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2939, '', '6', 'SET', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2940, '', '1850', 'SET', 'Prices', 'price', '2013-12-21 12:20:19', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2941, '', '115', 'SET', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2942, '', '276', 'SET', 'Prices', 'id', '2013-12-21 12:20:19', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2943, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:20:19', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2944, '', '7', 'SET', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2945, '', '2050', 'SET', 'Prices', 'price', '2013-12-21 12:20:19', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2946, '', '115', 'SET', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2947, '', '277', 'SET', 'Prices', 'id', '2013-12-21 12:20:19', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2948, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:20:19', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2949, '', '8', 'SET', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2950, '', '2250', 'SET', 'Prices', 'price', '2013-12-21 12:20:19', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2951, '', '115', 'SET', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2952, '', '278', 'SET', 'Prices', 'id', '2013-12-21 12:20:19', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2953, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:20:19', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2954, '', '1', 'SET', 'Prices', 'pax', '2013-12-21 12:20:19', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2955, '', '1200', 'SET', 'Prices', 'price', '2013-12-21 12:20:19', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2956, '', '115', 'SET', 'Prices', 'rate_id', '2013-12-21 12:20:19', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2957, '', '279', 'SET', 'Prices', 'id', '2013-12-21 12:20:19', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2958, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2959, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2960, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2961, '', '101', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '101');
INSERT INTO `tbl_audit_trail` VALUES(2962, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2963, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2964, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2965, '', '102', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '102');
INSERT INTO `tbl_audit_trail` VALUES(2966, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2967, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2968, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2969, '', '103', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '103');
INSERT INTO `tbl_audit_trail` VALUES(2970, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2971, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2972, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2973, '', '104', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '104');
INSERT INTO `tbl_audit_trail` VALUES(2974, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2975, '', '1850.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2976, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2977, '', '276', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '276');
INSERT INTO `tbl_audit_trail` VALUES(2978, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2979, '', '2050.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2980, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2981, '', '277', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '277');
INSERT INTO `tbl_audit_trail` VALUES(2982, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2983, '', '2250.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2984, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2985, '', '278', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '278');
INSERT INTO `tbl_audit_trail` VALUES(2986, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:14', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2987, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:14', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2988, '', '115', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:14', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2989, '', '279', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:14', 4, '279');
INSERT INTO `tbl_audit_trail` VALUES(2990, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:42', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2991, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2992, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2993, '', '105', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(2994, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:43', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2995, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2996, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2997, '', '106', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(2998, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:43', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(2999, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(3000, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(3001, '', '107', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(3002, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:43', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3003, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3004, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3005, '', '108', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3006, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:43', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3007, '', '1450.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3008, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3009, '', '272', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3010, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:43', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3011, '', '1600.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3012, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3013, '', '273', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3014, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:43', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3015, '', '1750.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3016, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3017, '', '274', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3018, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:21:43', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3019, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:21:43', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3020, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:21:43', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3021, '', '275', 'CHANGE', 'Prices', 'id', '2013-12-21 12:21:43', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3022, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(3023, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(3024, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(3025, '', '105', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '105');
INSERT INTO `tbl_audit_trail` VALUES(3026, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(3027, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(3028, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(3029, '', '106', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '106');
INSERT INTO `tbl_audit_trail` VALUES(3030, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(3031, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(3032, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(3033, '', '107', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '107');
INSERT INTO `tbl_audit_trail` VALUES(3034, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3035, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3036, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3037, '', '108', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '108');
INSERT INTO `tbl_audit_trail` VALUES(3038, '', '6', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3039, '', '1450.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3040, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3041, '', '272', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '272');
INSERT INTO `tbl_audit_trail` VALUES(3042, '', '7', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3043, '', '1600.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3044, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3045, '', '273', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '273');
INSERT INTO `tbl_audit_trail` VALUES(3046, '', '8', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3047, '', '1750.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3048, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3049, '', '274', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '274');
INSERT INTO `tbl_audit_trail` VALUES(3050, '', '1', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:22:11', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3051, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:22:11', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3052, '', '116', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:22:11', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3053, '', '275', 'CHANGE', 'Prices', 'id', '2013-12-21 12:22:11', 4, '275');
INSERT INTO `tbl_audit_trail` VALUES(3054, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:02', 4, '109');
INSERT INTO `tbl_audit_trail` VALUES(3055, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:02', 4, '109');
INSERT INTO `tbl_audit_trail` VALUES(3056, '', '117', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:02', 4, '109');
INSERT INTO `tbl_audit_trail` VALUES(3057, '', '109', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:02', 4, '109');
INSERT INTO `tbl_audit_trail` VALUES(3058, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:02', 4, '110');
INSERT INTO `tbl_audit_trail` VALUES(3059, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:02', 4, '110');
INSERT INTO `tbl_audit_trail` VALUES(3060, '', '117', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:02', 4, '110');
INSERT INTO `tbl_audit_trail` VALUES(3061, '', '110', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:02', 4, '110');
INSERT INTO `tbl_audit_trail` VALUES(3062, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:02', 4, '111');
INSERT INTO `tbl_audit_trail` VALUES(3063, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:02', 4, '111');
INSERT INTO `tbl_audit_trail` VALUES(3064, '', '117', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:02', 4, '111');
INSERT INTO `tbl_audit_trail` VALUES(3065, '', '111', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:02', 4, '111');
INSERT INTO `tbl_audit_trail` VALUES(3066, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:02', 4, '112');
INSERT INTO `tbl_audit_trail` VALUES(3067, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:03', 4, '112');
INSERT INTO `tbl_audit_trail` VALUES(3068, '', '117', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:03', 4, '112');
INSERT INTO `tbl_audit_trail` VALUES(3069, '', '112', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:03', 4, '112');
INSERT INTO `tbl_audit_trail` VALUES(3070, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:03', 4, '280');
INSERT INTO `tbl_audit_trail` VALUES(3071, '', '6', 'SET', 'Prices', 'pax', '2013-12-21 12:23:03', 4, '280');
INSERT INTO `tbl_audit_trail` VALUES(3072, '', '1850', 'SET', 'Prices', 'price', '2013-12-21 12:23:03', 4, '280');
INSERT INTO `tbl_audit_trail` VALUES(3073, '', '117', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:03', 4, '280');
INSERT INTO `tbl_audit_trail` VALUES(3074, '', '280', 'SET', 'Prices', 'id', '2013-12-21 12:23:03', 4, '280');
INSERT INTO `tbl_audit_trail` VALUES(3075, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:03', 4, '281');
INSERT INTO `tbl_audit_trail` VALUES(3076, '', '7', 'SET', 'Prices', 'pax', '2013-12-21 12:23:03', 4, '281');
INSERT INTO `tbl_audit_trail` VALUES(3077, '', '2050', 'SET', 'Prices', 'price', '2013-12-21 12:23:03', 4, '281');
INSERT INTO `tbl_audit_trail` VALUES(3078, '', '117', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:03', 4, '281');
INSERT INTO `tbl_audit_trail` VALUES(3079, '', '281', 'SET', 'Prices', 'id', '2013-12-21 12:23:03', 4, '281');
INSERT INTO `tbl_audit_trail` VALUES(3080, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:03', 4, '282');
INSERT INTO `tbl_audit_trail` VALUES(3081, '', '8', 'SET', 'Prices', 'pax', '2013-12-21 12:23:03', 4, '282');
INSERT INTO `tbl_audit_trail` VALUES(3082, '', '2250', 'SET', 'Prices', 'price', '2013-12-21 12:23:03', 4, '282');
INSERT INTO `tbl_audit_trail` VALUES(3083, '', '117', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:03', 4, '282');
INSERT INTO `tbl_audit_trail` VALUES(3084, '', '282', 'SET', 'Prices', 'id', '2013-12-21 12:23:03', 4, '282');
INSERT INTO `tbl_audit_trail` VALUES(3085, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:03', 4, '283');
INSERT INTO `tbl_audit_trail` VALUES(3086, '', '1', 'SET', 'Prices', 'pax', '2013-12-21 12:23:03', 4, '283');
INSERT INTO `tbl_audit_trail` VALUES(3087, '', '1200', 'SET', 'Prices', 'price', '2013-12-21 12:23:03', 4, '283');
INSERT INTO `tbl_audit_trail` VALUES(3088, '', '117', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:03', 4, '283');
INSERT INTO `tbl_audit_trail` VALUES(3089, '', '283', 'SET', 'Prices', 'id', '2013-12-21 12:23:03', 4, '283');
INSERT INTO `tbl_audit_trail` VALUES(3090, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '113');
INSERT INTO `tbl_audit_trail` VALUES(3091, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:59', 4, '113');
INSERT INTO `tbl_audit_trail` VALUES(3092, '', '118', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '113');
INSERT INTO `tbl_audit_trail` VALUES(3093, '', '113', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:59', 4, '113');
INSERT INTO `tbl_audit_trail` VALUES(3094, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '114');
INSERT INTO `tbl_audit_trail` VALUES(3095, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:59', 4, '114');
INSERT INTO `tbl_audit_trail` VALUES(3096, '', '118', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '114');
INSERT INTO `tbl_audit_trail` VALUES(3097, '', '114', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:59', 4, '114');
INSERT INTO `tbl_audit_trail` VALUES(3098, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '115');
INSERT INTO `tbl_audit_trail` VALUES(3099, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:59', 4, '115');
INSERT INTO `tbl_audit_trail` VALUES(3100, '', '118', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '115');
INSERT INTO `tbl_audit_trail` VALUES(3101, '', '115', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:59', 4, '115');
INSERT INTO `tbl_audit_trail` VALUES(3102, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '116');
INSERT INTO `tbl_audit_trail` VALUES(3103, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:23:59', 4, '116');
INSERT INTO `tbl_audit_trail` VALUES(3104, '', '118', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '116');
INSERT INTO `tbl_audit_trail` VALUES(3105, '', '116', 'CHANGE', 'Prices', 'id', '2013-12-21 12:23:59', 4, '116');
INSERT INTO `tbl_audit_trail` VALUES(3106, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:59', 4, '284');
INSERT INTO `tbl_audit_trail` VALUES(3107, '', '6', 'SET', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '284');
INSERT INTO `tbl_audit_trail` VALUES(3108, '', '1450', 'SET', 'Prices', 'price', '2013-12-21 12:23:59', 4, '284');
INSERT INTO `tbl_audit_trail` VALUES(3109, '', '118', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '284');
INSERT INTO `tbl_audit_trail` VALUES(3110, '', '284', 'SET', 'Prices', 'id', '2013-12-21 12:23:59', 4, '284');
INSERT INTO `tbl_audit_trail` VALUES(3111, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:59', 4, '285');
INSERT INTO `tbl_audit_trail` VALUES(3112, '', '7', 'SET', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '285');
INSERT INTO `tbl_audit_trail` VALUES(3113, '', '1600', 'SET', 'Prices', 'price', '2013-12-21 12:23:59', 4, '285');
INSERT INTO `tbl_audit_trail` VALUES(3114, '', '118', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '285');
INSERT INTO `tbl_audit_trail` VALUES(3115, '', '285', 'SET', 'Prices', 'id', '2013-12-21 12:23:59', 4, '285');
INSERT INTO `tbl_audit_trail` VALUES(3116, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:59', 4, '286');
INSERT INTO `tbl_audit_trail` VALUES(3117, '', '8', 'SET', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '286');
INSERT INTO `tbl_audit_trail` VALUES(3118, '', '1750', 'SET', 'Prices', 'price', '2013-12-21 12:23:59', 4, '286');
INSERT INTO `tbl_audit_trail` VALUES(3119, '', '118', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '286');
INSERT INTO `tbl_audit_trail` VALUES(3120, '', '286', 'SET', 'Prices', 'id', '2013-12-21 12:23:59', 4, '286');
INSERT INTO `tbl_audit_trail` VALUES(3121, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:23:59', 4, '287');
INSERT INTO `tbl_audit_trail` VALUES(3122, '', '1', 'SET', 'Prices', 'pax', '2013-12-21 12:23:59', 4, '287');
INSERT INTO `tbl_audit_trail` VALUES(3123, '', '1000', 'SET', 'Prices', 'price', '2013-12-21 12:23:59', 4, '287');
INSERT INTO `tbl_audit_trail` VALUES(3124, '', '118', 'SET', 'Prices', 'rate_id', '2013-12-21 12:23:59', 4, '287');
INSERT INTO `tbl_audit_trail` VALUES(3125, '', '287', 'SET', 'Prices', 'id', '2013-12-21 12:23:59', 4, '287');
INSERT INTO `tbl_audit_trail` VALUES(3126, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '117');
INSERT INTO `tbl_audit_trail` VALUES(3127, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:24:59', 4, '117');
INSERT INTO `tbl_audit_trail` VALUES(3128, '', '119', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '117');
INSERT INTO `tbl_audit_trail` VALUES(3129, '', '117', 'CHANGE', 'Prices', 'id', '2013-12-21 12:24:59', 4, '117');
INSERT INTO `tbl_audit_trail` VALUES(3130, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '118');
INSERT INTO `tbl_audit_trail` VALUES(3131, '', '1350.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:24:59', 4, '118');
INSERT INTO `tbl_audit_trail` VALUES(3132, '', '119', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '118');
INSERT INTO `tbl_audit_trail` VALUES(3133, '', '118', 'CHANGE', 'Prices', 'id', '2013-12-21 12:24:59', 4, '118');
INSERT INTO `tbl_audit_trail` VALUES(3134, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '119');
INSERT INTO `tbl_audit_trail` VALUES(3135, '', '1500.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:24:59', 4, '119');
INSERT INTO `tbl_audit_trail` VALUES(3136, '', '119', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '119');
INSERT INTO `tbl_audit_trail` VALUES(3137, '', '119', 'CHANGE', 'Prices', 'id', '2013-12-21 12:24:59', 4, '119');
INSERT INTO `tbl_audit_trail` VALUES(3138, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '120');
INSERT INTO `tbl_audit_trail` VALUES(3139, '', '1650.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:24:59', 4, '120');
INSERT INTO `tbl_audit_trail` VALUES(3140, '', '119', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '120');
INSERT INTO `tbl_audit_trail` VALUES(3141, '', '120', 'CHANGE', 'Prices', 'id', '2013-12-21 12:24:59', 4, '120');
INSERT INTO `tbl_audit_trail` VALUES(3142, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:24:59', 4, '288');
INSERT INTO `tbl_audit_trail` VALUES(3143, '', '6', 'SET', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '288');
INSERT INTO `tbl_audit_trail` VALUES(3144, '', '1850', 'SET', 'Prices', 'price', '2013-12-21 12:24:59', 4, '288');
INSERT INTO `tbl_audit_trail` VALUES(3145, '', '119', 'SET', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '288');
INSERT INTO `tbl_audit_trail` VALUES(3146, '', '288', 'SET', 'Prices', 'id', '2013-12-21 12:24:59', 4, '288');
INSERT INTO `tbl_audit_trail` VALUES(3147, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:24:59', 4, '289');
INSERT INTO `tbl_audit_trail` VALUES(3148, '', '7', 'SET', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '289');
INSERT INTO `tbl_audit_trail` VALUES(3149, '', '2050', 'SET', 'Prices', 'price', '2013-12-21 12:24:59', 4, '289');
INSERT INTO `tbl_audit_trail` VALUES(3150, '', '119', 'SET', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '289');
INSERT INTO `tbl_audit_trail` VALUES(3151, '', '289', 'SET', 'Prices', 'id', '2013-12-21 12:24:59', 4, '289');
INSERT INTO `tbl_audit_trail` VALUES(3152, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:24:59', 4, '290');
INSERT INTO `tbl_audit_trail` VALUES(3153, '', '8', 'SET', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '290');
INSERT INTO `tbl_audit_trail` VALUES(3154, '', '2250', 'SET', 'Prices', 'price', '2013-12-21 12:24:59', 4, '290');
INSERT INTO `tbl_audit_trail` VALUES(3155, '', '119', 'SET', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '290');
INSERT INTO `tbl_audit_trail` VALUES(3156, '', '290', 'SET', 'Prices', 'id', '2013-12-21 12:24:59', 4, '290');
INSERT INTO `tbl_audit_trail` VALUES(3157, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:24:59', 4, '291');
INSERT INTO `tbl_audit_trail` VALUES(3158, '', '1', 'SET', 'Prices', 'pax', '2013-12-21 12:24:59', 4, '291');
INSERT INTO `tbl_audit_trail` VALUES(3159, '', '1200', 'SET', 'Prices', 'price', '2013-12-21 12:24:59', 4, '291');
INSERT INTO `tbl_audit_trail` VALUES(3160, '', '119', 'SET', 'Prices', 'rate_id', '2013-12-21 12:24:59', 4, '291');
INSERT INTO `tbl_audit_trail` VALUES(3161, '', '291', 'SET', 'Prices', 'id', '2013-12-21 12:24:59', 4, '291');
INSERT INTO `tbl_audit_trail` VALUES(3162, '', '2', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:25:50', 4, '121');
INSERT INTO `tbl_audit_trail` VALUES(3163, '', '1000.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:25:50', 4, '121');
INSERT INTO `tbl_audit_trail` VALUES(3164, '', '120', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:25:50', 4, '121');
INSERT INTO `tbl_audit_trail` VALUES(3165, '', '121', 'CHANGE', 'Prices', 'id', '2013-12-21 12:25:50', 4, '121');
INSERT INTO `tbl_audit_trail` VALUES(3166, '', '3', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:25:50', 4, '122');
INSERT INTO `tbl_audit_trail` VALUES(3167, '', '1100.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:25:50', 4, '122');
INSERT INTO `tbl_audit_trail` VALUES(3168, '', '120', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:25:50', 4, '122');
INSERT INTO `tbl_audit_trail` VALUES(3169, '', '122', 'CHANGE', 'Prices', 'id', '2013-12-21 12:25:50', 4, '122');
INSERT INTO `tbl_audit_trail` VALUES(3170, '', '4', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:25:50', 4, '123');
INSERT INTO `tbl_audit_trail` VALUES(3171, '', '1200.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:25:50', 4, '123');
INSERT INTO `tbl_audit_trail` VALUES(3172, '', '120', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:25:50', 4, '123');
INSERT INTO `tbl_audit_trail` VALUES(3173, '', '123', 'CHANGE', 'Prices', 'id', '2013-12-21 12:25:50', 4, '123');
INSERT INTO `tbl_audit_trail` VALUES(3174, '', '5', 'CHANGE', 'Prices', 'pax', '2013-12-21 12:25:50', 4, '124');
INSERT INTO `tbl_audit_trail` VALUES(3175, '', '1300.00', 'CHANGE', 'Prices', 'price', '2013-12-21 12:25:50', 4, '124');
INSERT INTO `tbl_audit_trail` VALUES(3176, '', '120', 'CHANGE', 'Prices', 'rate_id', '2013-12-21 12:25:50', 4, '124');
INSERT INTO `tbl_audit_trail` VALUES(3177, '', '124', 'CHANGE', 'Prices', 'id', '2013-12-21 12:25:50', 4, '124');
INSERT INTO `tbl_audit_trail` VALUES(3178, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:25:50', 4, '292');
INSERT INTO `tbl_audit_trail` VALUES(3179, '', '6', 'SET', 'Prices', 'pax', '2013-12-21 12:25:50', 4, '292');
INSERT INTO `tbl_audit_trail` VALUES(3180, '', '1450', 'SET', 'Prices', 'price', '2013-12-21 12:25:50', 4, '292');
INSERT INTO `tbl_audit_trail` VALUES(3181, '', '120', 'SET', 'Prices', 'rate_id', '2013-12-21 12:25:50', 4, '292');
INSERT INTO `tbl_audit_trail` VALUES(3182, '', '292', 'SET', 'Prices', 'id', '2013-12-21 12:25:50', 4, '292');
INSERT INTO `tbl_audit_trail` VALUES(3183, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:25:50', 4, '293');
INSERT INTO `tbl_audit_trail` VALUES(3184, '', '7', 'SET', 'Prices', 'pax', '2013-12-21 12:25:50', 4, '293');
INSERT INTO `tbl_audit_trail` VALUES(3185, '', '1600', 'SET', 'Prices', 'price', '2013-12-21 12:25:51', 4, '293');
INSERT INTO `tbl_audit_trail` VALUES(3186, '', '120', 'SET', 'Prices', 'rate_id', '2013-12-21 12:25:51', 4, '293');
INSERT INTO `tbl_audit_trail` VALUES(3187, '', '293', 'SET', 'Prices', 'id', '2013-12-21 12:25:51', 4, '293');
INSERT INTO `tbl_audit_trail` VALUES(3188, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:25:51', 4, '294');
INSERT INTO `tbl_audit_trail` VALUES(3189, '', '8', 'SET', 'Prices', 'pax', '2013-12-21 12:25:51', 4, '294');
INSERT INTO `tbl_audit_trail` VALUES(3190, '', '1750', 'SET', 'Prices', 'price', '2013-12-21 12:25:51', 4, '294');
INSERT INTO `tbl_audit_trail` VALUES(3191, '', '120', 'SET', 'Prices', 'rate_id', '2013-12-21 12:25:51', 4, '294');
INSERT INTO `tbl_audit_trail` VALUES(3192, '', '294', 'SET', 'Prices', 'id', '2013-12-21 12:25:51', 4, '294');
INSERT INTO `tbl_audit_trail` VALUES(3193, '', '', 'CREATE', 'Prices', 'N/A', '2013-12-21 12:25:51', 4, '295');
INSERT INTO `tbl_audit_trail` VALUES(3194, '', '1', 'SET', 'Prices', 'pax', '2013-12-21 12:25:51', 4, '295');
INSERT INTO `tbl_audit_trail` VALUES(3195, '', '1000', 'SET', 'Prices', 'price', '2013-12-21 12:25:51', 4, '295');
INSERT INTO `tbl_audit_trail` VALUES(3196, '', '120', 'SET', 'Prices', 'rate_id', '2013-12-21 12:25:51', 4, '295');
INSERT INTO `tbl_audit_trail` VALUES(3197, '', '295', 'SET', 'Prices', 'id', '2013-12-21 12:25:51', 4, '295');
INSERT INTO `tbl_audit_trail` VALUES(3198, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2013-12-21 12:40:43', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3199, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2013-12-21 12:40:43', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3200, '', '18', 'SET', 'CustomerReservations', 'customer_id', '2013-12-21 12:40:43', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3201, '', '33', 'SET', 'CustomerReservations', 'id', '2013-12-21 12:40:43', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3202, '', '', 'SET', 'CustomerReservations', 'subtotal', '2013-12-21 12:40:44', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3203, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2013-12-21 12:40:44', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3204, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2013-12-21 12:40:44', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3205, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2013-12-21 12:40:44', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3206, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2013-12-21 12:40:44', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3207, '', '', 'SET', 'CustomerReservations', 'grand_total', '2013-12-21 12:40:44', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3208, '', '', 'CREATE', 'Reservation', 'N/A', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3209, '', '', 'SET', 'Reservation', 'children', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3210, '', '2', 'SET', 'Reservation', 'pets', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3211, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3212, '', '1', 'SET', 'Reservation', 'room_id', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3213, '', '2013-12-21 15:00', 'SET', 'Reservation', 'checkin', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3214, '', '2013-12-23 13:00', 'SET', 'Reservation', 'checkout', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3215, '', '5', 'SET', 'Reservation', 'adults', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3216, '', '1', 'SET', 'Reservation', 'statux', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3217, '', '2', 'SET', 'Reservation', 'nights', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3218, '', '5', 'SET', 'Reservation', 'totalpax', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3219, '', '2', 'SET', 'Reservation', 'nigth_ta', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3220, '', '0', 'SET', 'Reservation', 'nigth_tb', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3221, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3222, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3223, '', '0', 'SET', 'Reservation', 'price_tb', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3224, '', '1300.00', 'SET', 'Reservation', 'price_ta', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3225, '', '2600', 'SET', 'Reservation', 'price', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3226, '', '33', 'SET', 'Reservation', 'customer_reservation_id', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3227, '', '', 'SET', 'Reservation', 'description', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3228, '', '43', 'SET', 'Reservation', 'id', '2013-12-21 12:40:44', 4, '43');
INSERT INTO `tbl_audit_trail` VALUES(3229, '', '', 'CREATE', 'Customers', 'N/A', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3230, '', 'venus_iki@hotmail.com', 'SET', 'Customers', 'email', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3231, '', '', 'SET', 'Customers', 'alternative_email', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3232, '', 'Mirsha Itzel', 'SET', 'Customers', 'first_name', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3233, '', 'Figueroa Sánchez', 'SET', 'Customers', 'last_name', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3234, '', 'Mexico', 'SET', 'Customers', 'country', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3235, '', 'Veracruz', 'SET', 'Customers', 'state', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3236, '', 'Xalapa', 'SET', 'Customers', 'city', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3237, '', 'Zonaturistica', 'SET', 'Customers', 'how_find_us', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3238, '', '(228) 9794-145', 'SET', 'Customers', 'home_phone', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3239, '', '', 'SET', 'Customers', 'work_phone', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3240, '', '(228) 9794-145', 'SET', 'Customers', 'cell_phone', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3241, '', '29', 'SET', 'Customers', 'id', '2014-01-03 08:12:42', 4, '29');
INSERT INTO `tbl_audit_trail` VALUES(3242, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3243, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3244, '', '29', 'SET', 'CustomerReservations', 'customer_id', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3245, '', '34', 'SET', 'CustomerReservations', 'id', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3246, '', '', 'SET', 'CustomerReservations', 'subtotal', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3247, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3248, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3249, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3250, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3251, '', '', 'SET', 'CustomerReservations', 'grand_total', '2014-01-03 08:12:42', 4, '34');
INSERT INTO `tbl_audit_trail` VALUES(3252, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3253, '', '', 'SET', 'Reservation', 'children', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3254, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3255, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3256, '', '6', 'SET', 'Reservation', 'room_id', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3257, '', '2014-02-14 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3258, '', '2014-02-21 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3259, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3260, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3261, '', '7', 'SET', 'Reservation', 'nights', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3262, '', '2', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3263, '', '0', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3264, '', '7', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3265, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3266, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3267, '', '1000.00', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3268, '', '0', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3269, '', '7000', 'SET', 'Reservation', 'price', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3270, '', '34', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3271, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3272, '', '44', 'SET', 'Reservation', 'id', '2014-01-03 08:12:42', 4, '44');
INSERT INTO `tbl_audit_trail` VALUES(3273, '', '', 'CREATE', 'Customers', 'N/A', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3274, '', 'cmonsivaisc@yahoo.com.mx', 'SET', 'Customers', 'email', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3275, '', '', 'SET', 'Customers', 'alternative_email', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3276, '', 'Carmen', 'SET', 'Customers', 'first_name', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3277, '', 'Monsivais', 'SET', 'Customers', 'last_name', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3278, '', 'Mexico', 'SET', 'Customers', 'country', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3279, '', 'Coahuila', 'SET', 'Customers', 'state', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3280, '', 'Saltillo', 'SET', 'Customers', 'city', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3281, '', 'Zona turistica', 'SET', 'Customers', 'how_find_us', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3282, '', '(844) 1457-053', 'SET', 'Customers', 'home_phone', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3283, '', '', 'SET', 'Customers', 'work_phone', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3284, '', '(844) 1457-053', 'SET', 'Customers', 'cell_phone', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3285, '', '30', 'SET', 'Customers', 'id', '2014-01-03 08:27:54', 4, '30');
INSERT INTO `tbl_audit_trail` VALUES(3286, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2014-01-03 08:27:54', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3287, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2014-01-03 08:27:54', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3288, '', '30', 'SET', 'CustomerReservations', 'customer_id', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3289, '', '35', 'SET', 'CustomerReservations', 'id', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3290, '', '', 'SET', 'CustomerReservations', 'subtotal', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3291, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3292, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3293, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3294, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3295, '', '', 'SET', 'CustomerReservations', 'grand_total', '2014-01-03 08:27:55', 4, '35');
INSERT INTO `tbl_audit_trail` VALUES(3296, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3297, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3298, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3299, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3300, '', '6', 'SET', 'Reservation', 'room_id', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3301, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3302, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3303, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3304, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3305, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3306, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3307, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3308, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3309, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3310, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3311, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3312, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3313, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3314, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3315, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3316, '', '45', 'SET', 'Reservation', 'id', '2014-01-03 08:27:55', 4, '45');
INSERT INTO `tbl_audit_trail` VALUES(3317, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3318, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3319, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3320, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3321, '', '7', 'SET', 'Reservation', 'room_id', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3322, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3323, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3324, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3325, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3326, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3327, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3328, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3329, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3330, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3331, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:27:55', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3332, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:27:56', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3333, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:27:56', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3334, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:27:56', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3335, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:27:56', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3336, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:27:56', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3337, '', '46', 'SET', 'Reservation', 'id', '2014-01-03 08:27:56', 4, '46');
INSERT INTO `tbl_audit_trail` VALUES(3338, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3339, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3340, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3341, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3342, '', '8', 'SET', 'Reservation', 'room_id', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3343, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3344, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3345, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3346, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3347, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3348, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3349, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3350, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3351, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3352, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3353, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3354, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3355, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3356, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3357, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3358, '', '47', 'SET', 'Reservation', 'id', '2014-01-03 08:27:56', 4, '47');
INSERT INTO `tbl_audit_trail` VALUES(3359, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3360, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3361, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3362, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3363, '', '9', 'SET', 'Reservation', 'room_id', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3364, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3365, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3366, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3367, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:27:56', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3368, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3369, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3370, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3371, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3372, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3373, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3374, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3375, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3376, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3377, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3378, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3379, '', '48', 'SET', 'Reservation', 'id', '2014-01-03 08:27:57', 4, '48');
INSERT INTO `tbl_audit_trail` VALUES(3380, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3381, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3382, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3383, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3384, '', '10', 'SET', 'Reservation', 'room_id', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3385, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3386, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3387, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3388, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3389, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3390, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3391, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:27:57', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3392, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3393, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3394, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3395, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3396, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3397, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3398, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3399, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3400, '', '49', 'SET', 'Reservation', 'id', '2014-01-03 08:27:58', 4, '49');
INSERT INTO `tbl_audit_trail` VALUES(3401, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3402, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3403, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3404, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3405, '', '11', 'SET', 'Reservation', 'room_id', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3406, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3407, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3408, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:27:58', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3409, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3410, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3411, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3412, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3413, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3414, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3415, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3416, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3417, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3418, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3419, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3420, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3421, '', '50', 'SET', 'Reservation', 'id', '2014-01-03 08:27:59', 4, '50');
INSERT INTO `tbl_audit_trail` VALUES(3422, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3423, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3424, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3425, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3426, '', '12', 'SET', 'Reservation', 'room_id', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3427, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3428, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3429, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3430, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3431, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3432, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3433, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3434, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3435, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3436, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3437, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3438, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3439, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3440, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3441, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3442, '', '51', 'SET', 'Reservation', 'id', '2014-01-03 08:27:59', 4, '51');
INSERT INTO `tbl_audit_trail` VALUES(3443, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:27:59', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3444, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:27:59', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3445, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:27:59', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3446, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3447, '', '13', 'SET', 'Reservation', 'room_id', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3448, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3449, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3450, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3451, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3452, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3453, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3454, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3455, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3456, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3457, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3458, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3459, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3460, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3461, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3462, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3463, '', '52', 'SET', 'Reservation', 'id', '2014-01-03 08:28:00', 4, '52');
INSERT INTO `tbl_audit_trail` VALUES(3464, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3465, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3466, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3467, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3468, '', '14', 'SET', 'Reservation', 'room_id', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3469, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3470, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3471, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3472, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3473, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3474, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3475, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3476, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3477, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3478, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3479, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3480, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3481, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3482, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3483, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3484, '', '53', 'SET', 'Reservation', 'id', '2014-01-03 08:28:00', 4, '53');
INSERT INTO `tbl_audit_trail` VALUES(3485, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3486, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3487, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3488, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3489, '', '15', 'SET', 'Reservation', 'room_id', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3490, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3491, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3492, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3493, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3494, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3495, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3496, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3497, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3498, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3499, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3500, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3501, '', '1200.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3502, '', '4800', 'SET', 'Reservation', 'price', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3503, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3504, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3505, '', '54', 'SET', 'Reservation', 'id', '2014-01-03 08:28:00', 4, '54');
INSERT INTO `tbl_audit_trail` VALUES(3506, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3507, '', '2', 'SET', 'Reservation', 'children', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3508, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3509, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3510, '', '4', 'SET', 'Reservation', 'room_id', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3511, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3512, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3513, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3514, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3515, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3516, '', '4', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3517, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3518, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3519, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3520, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3521, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3522, '', '850.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3523, '', '3400', 'SET', 'Reservation', 'price', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3524, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:28:00', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3525, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:28:01', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3526, '', '55', 'SET', 'Reservation', 'id', '2014-01-03 08:28:01', 4, '55');
INSERT INTO `tbl_audit_trail` VALUES(3527, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3528, '', '', 'SET', 'Reservation', 'children', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3529, '', '0', 'SET', 'Reservation', 'pets', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3530, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3531, '', '5', 'SET', 'Reservation', 'room_id', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3532, '', '2014-07-19 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3533, '', '2014-07-23 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3534, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3535, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3536, '', '4', 'SET', 'Reservation', 'nights', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3537, '', '2', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3538, '', '4', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3539, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3540, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3541, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3542, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3543, '', '850.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3544, '', '3400', 'SET', 'Reservation', 'price', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3545, '', '35', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3546, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3547, '', '56', 'SET', 'Reservation', 'id', '2014-01-03 08:28:01', 4, '56');
INSERT INTO `tbl_audit_trail` VALUES(3548, '', '', 'CREATE', 'Customers', 'N/A', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3549, '', 'andii_2905@hotmail.com', 'SET', 'Customers', 'email', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3550, '', '', 'SET', 'Customers', 'alternative_email', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3551, '', 'andrea', 'SET', 'Customers', 'first_name', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3552, '', 'hiller', 'SET', 'Customers', 'last_name', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3553, '', 'Mexico', 'SET', 'Customers', 'country', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3554, '', 'Veracruz', 'SET', 'Customers', 'state', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3555, '', 'veracruz', 'SET', 'Customers', 'city', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3556, '', 'internet', 'SET', 'Customers', 'how_find_us', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3557, '', '', 'SET', 'Customers', 'home_phone', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3558, '', '', 'SET', 'Customers', 'work_phone', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3559, '', '2291012857', 'SET', 'Customers', 'cell_phone', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3560, '', '31', 'SET', 'Customers', 'id', '2014-01-03 08:36:39', 4, '31');
INSERT INTO `tbl_audit_trail` VALUES(3561, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3562, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3563, '', '31', 'SET', 'CustomerReservations', 'customer_id', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3564, '', '36', 'SET', 'CustomerReservations', 'id', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3565, '', '', 'SET', 'CustomerReservations', 'subtotal', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3566, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3567, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3568, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3569, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3570, '', '', 'SET', 'CustomerReservations', 'grand_total', '2014-01-03 08:36:39', 4, '36');
INSERT INTO `tbl_audit_trail` VALUES(3571, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3572, '', '', 'SET', 'Reservation', 'children', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3573, '', '2', 'SET', 'Reservation', 'pets', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3574, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3575, '', '6', 'SET', 'Reservation', 'room_id', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3576, '', '2014-01-03 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3577, '', '2014-01-06 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3578, '', '5', 'SET', 'Reservation', 'adults', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3579, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3580, '', '3', 'SET', 'Reservation', 'nights', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3581, '', '5', 'SET', 'Reservation', 'totalpax', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3582, '', '3', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3583, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3584, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3585, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3586, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3587, '', '1650.00', 'SET', 'Reservation', 'price_ta', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3588, '', '4950', 'SET', 'Reservation', 'price', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3589, '', '36', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3590, '', '', 'SET', 'Reservation', 'description', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3591, '', '57', 'SET', 'Reservation', 'id', '2014-01-03 08:36:40', 4, '57');
INSERT INTO `tbl_audit_trail` VALUES(3592, '', '', 'CREATE', 'Customers', 'N/A', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3593, '', 'machisi29@hotmail.com', 'SET', 'Customers', 'email', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3594, '', '', 'SET', 'Customers', 'alternative_email', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3595, '', 'EDGAR', 'SET', 'Customers', 'first_name', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3596, '', '', 'SET', 'Customers', 'last_name', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3597, '', '', 'SET', 'Customers', 'country', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3598, '', '', 'SET', 'Customers', 'state', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3599, '', '', 'SET', 'Customers', 'city', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3600, '', '', 'SET', 'Customers', 'how_find_us', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3601, '', '', 'SET', 'Customers', 'home_phone', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3602, '', '', 'SET', 'Customers', 'work_phone', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3603, '', '', 'SET', 'Customers', 'cell_phone', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3604, '', '32', 'SET', 'Customers', 'id', '2014-01-03 09:33:11', 4, '32');
INSERT INTO `tbl_audit_trail` VALUES(3605, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3606, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3607, '', '32', 'SET', 'CustomerReservations', 'customer_id', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3608, '', '37', 'SET', 'CustomerReservations', 'id', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3609, '', '', 'SET', 'CustomerReservations', 'subtotal', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3610, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3611, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3612, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3613, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3614, '', '', 'SET', 'CustomerReservations', 'grand_total', '2014-01-03 09:33:12', 4, '37');
INSERT INTO `tbl_audit_trail` VALUES(3615, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3616, '', '', 'SET', 'Reservation', 'children', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3617, '', '2', 'SET', 'Reservation', 'pets', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3618, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3619, '', '6', 'SET', 'Reservation', 'room_id', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3620, '', '2014-03-24 15:00', 'SET', 'Reservation', 'checkin', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3621, '', '2014-03-27 13:00', 'SET', 'Reservation', 'checkout', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3622, '', '2', 'SET', 'Reservation', 'adults', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3623, '', '1', 'SET', 'Reservation', 'statux', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3624, '', '3', 'SET', 'Reservation', 'nights', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3625, '', '2', 'SET', 'Reservation', 'totalpax', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3626, '', '0', 'SET', 'Reservation', 'nigth_ta', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3627, '', '3', 'SET', 'Reservation', 'nigth_tb', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3628, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3629, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3630, '', '1000.00', 'SET', 'Reservation', 'price_tb', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3631, '', '0', 'SET', 'Reservation', 'price_ta', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3632, '', '3000', 'SET', 'Reservation', 'price', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3633, '', '37', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3634, '', '', 'SET', 'Reservation', 'description', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3635, '', '58', 'SET', 'Reservation', 'id', '2014-01-03 09:33:12', 4, '58');
INSERT INTO `tbl_audit_trail` VALUES(3636, '', '', 'CREATE', 'Customers', 'N/A', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3637, '', 'gelos_samy@hotmail.com', 'SET', 'Customers', 'email', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3638, '', '', 'SET', 'Customers', 'alternative_email', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3639, '', 'Maria de los Angeles', 'SET', 'Customers', 'first_name', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3640, '', 'Sanchez', 'SET', 'Customers', 'last_name', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3641, '', 'Mexico', 'SET', 'Customers', 'country', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3642, '', 'Puebla', 'SET', 'Customers', 'state', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3643, '', 'Tepeaca', 'SET', 'Customers', 'city', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3644, '', 'Zona TUristica', 'SET', 'Customers', 'how_find_us', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3645, '', '(01223) 2751-988', 'SET', 'Customers', 'home_phone', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3646, '', '', 'SET', 'Customers', 'work_phone', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3647, '', '(01 223) 275 1988', 'SET', 'Customers', 'cell_phone', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3648, '', '33', 'SET', 'Customers', 'id', '2014-01-06 08:21:34', 4, '33');
INSERT INTO `tbl_audit_trail` VALUES(3649, '', '', 'CREATE', 'CustomerReservations', 'N/A', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3650, '', '1', 'SET', 'CustomerReservations', 'see_discount', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3651, '', '33', 'SET', 'CustomerReservations', 'customer_id', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3652, '', '38', 'SET', 'CustomerReservations', 'id', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3653, '', '', 'SET', 'CustomerReservations', 'subtotal', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3654, '', '', 'SET', 'CustomerReservations', 'cabana_discount', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3655, '', '', 'SET', 'CustomerReservations', 'tent_discount', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3656, '', '', 'SET', 'CustomerReservations', 'camped_discount', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3657, '', '', 'SET', 'CustomerReservations', 'day_pass_discount', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3658, '', '', 'SET', 'CustomerReservations', 'grand_total', '2014-01-06 08:21:34', 4, '38');
INSERT INTO `tbl_audit_trail` VALUES(3659, '', '', 'CREATE', 'Reservation', 'N/A', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3660, '', '', 'SET', 'Reservation', 'children', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3661, '', '0', 'SET', 'Reservation', 'pets', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3662, '', 'CABANA', 'SET', 'Reservation', 'type_reservation', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3663, '', '6', 'SET', 'Reservation', 'room_id', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3664, '', '2014-02-01 15:00', 'SET', 'Reservation', 'checkin', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3665, '', '2014-02-03 13:00', 'SET', 'Reservation', 'checkout', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3666, '', '3', 'SET', 'Reservation', 'adults', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3667, '', '1', 'SET', 'Reservation', 'statux', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3668, '', '2', 'SET', 'Reservation', 'nights', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3669, '', '3', 'SET', 'Reservation', 'totalpax', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3670, '', '2', 'SET', 'Reservation', 'nigth_ta', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3671, '', '0', 'SET', 'Reservation', 'nigth_tb', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3672, '', '0', 'SET', 'Reservation', 'price_early_checkin', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3673, '', '0', 'SET', 'Reservation', 'price_late_checkout', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3674, '', '0', 'SET', 'Reservation', 'price_tb', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3675, '', '1350.00', 'SET', 'Reservation', 'price_ta', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3676, '', '2700', 'SET', 'Reservation', 'price', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3677, '', '38', 'SET', 'Reservation', 'customer_reservation_id', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3678, '', '', 'SET', 'Reservation', 'description', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3679, '', '59', 'SET', 'Reservation', 'id', '2014-01-06 08:21:34', 4, '59');
INSERT INTO `tbl_audit_trail` VALUES(3680, 'Francisca', 'Franciscaa', 'CHANGE', 'Customers', 'first_name', '2014-01-08 16:57:00', 1, '9');
INSERT INTO `tbl_audit_trail` VALUES(3681, '', 'eventos.cocoaventura@gmail.com', 'CHANGE', 'Customers', 'alternative_email', '2014-01-08 17:16:38', 1, '7');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `type_reservation`
--

CREATE TABLE `type_reservation` (
  `id` int(11) NOT NULL auto_increment,
  `tipe` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `type_reservation`
--

INSERT INTO `type_reservation` VALUES(1, 'Pax');
INSERT INTO `type_reservation` VALUES(2, 'Room');

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `cruge_authassignment`
--
ALTER TABLE `cruge_authassignment`
  ADD CONSTRAINT `fk_cruge_authassignment_cruge_authitem1` FOREIGN KEY (`itemname`) REFERENCES `cruge_authitem` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cruge_authassignment_user` FOREIGN KEY (`userid`) REFERENCES `cruge_user` (`iduser`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cruge_fieldvalue`
--
ALTER TABLE `cruge_fieldvalue`
  ADD CONSTRAINT `fk_cruge_fieldvalue_cruge_field1` FOREIGN KEY (`idfield`) REFERENCES `cruge_field` (`idfield`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cruge_fieldvalue_cruge_user1` FOREIGN KEY (`iduser`) REFERENCES `cruge_user` (`iduser`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Filtros para la tabla `labels_format`
--
ALTER TABLE `labels_format`
  ADD CONSTRAINT `fk_labels_format_budget_format1` FOREIGN KEY (`budget_format_id`) REFERENCES `budget_format` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_labels_format_labels1` FOREIGN KEY (`label_id`) REFERENCES `labels` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `prices`
--
ALTER TABLE `prices`
  ADD CONSTRAINT `fk_prices_rates1` FOREIGN KEY (`rate_id`) REFERENCES `rates` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `rates`
--
ALTER TABLE `rates`
  ADD CONSTRAINT `fk_rates_rooms` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rates_type_reservation1` FOREIGN KEY (`type_reservation_id`) REFERENCES `type_reservation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `fk_reservation_rooms1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `fk_rooms_rooms_type1` FOREIGN KEY (`room_type_id`) REFERENCES `rooms_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
